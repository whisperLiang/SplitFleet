"""Capture torch backward execution and autograd graph metadata.

This module installs backward/grad wrappers, walks grad_fn graphs, records hook
events, and exposes Trace/Recording backward helpers.
"""

from __future__ import annotations

import contextlib
import inspect
import os
import re
import time
import weakref
from collections import OrderedDict, deque
from collections.abc import Sequence
from dataclasses import replace
from typing import Any, Callable, Iterator, Literal, cast

import torch

from ... import _state
from ...utils._torch_compat import get_accumulate_grad_class

from ..._deprecations import MISSING, MissingType
from ...quantities import Bytes, Duration
from ..._state import pause_logging
from ...data_classes.func_call_location import FuncCallLocation
from ...data_classes.op import _dtype_or_none, _memory_or_none, _shape_or_none
from ...data_classes.grad_fn import GradFn
from ...data_classes.grad_fn_call import GradFnCall
from ...data_classes.backward_pass import BackwardPass
from ...errors import ConfigurationError
from ...utils.introspection import _get_code_qualname, _get_col_offset
from ...ir.events import (
    BackwardPassEnd,
    BackwardPassStart,
    GradFnDiscovered,
    GradFnFired,
    OpGradObserved,
)
from ._tl import get_tensor_label
from .tensor_tracking import _ensure_backward_event_stream
from .escape_detection import expected_original_call

_BACKWARD_GRAD_FN_REGISTRY: dict[int, weakref.ReferenceType[Any]] = {}
_ORIGINAL_AUTOGRAD_BACKWARD: Callable[..., Any] | None = None
_ORIGINAL_AUTOGRAD_GRAD: Callable[..., Any] | None = None
_AUTOGRAD_WRAPPERS_INSTALLED = False
_TORCHLENS_PKG_DIR = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
_INFERENCE_ONLY_BACKWARD_ERROR = (
    "Cannot run log_backward on a trace captured with inference_only=True: the autograd "
    "graph was discarded during capture. Re-capture without inference_only (optionally with "
    "backward_ready=True) to enable deferred backward."
)
_CHUNKED_FORWARD_BACKWARD_ERROR = (
    "Cannot run log_backward on a trace captured with chunk_size: chunked forward capture "
    "concatenates forward payloads across independent sub-batches and does not retain a "
    "single full-batch autograd graph. Re-capture without chunk_size to enable deferred backward."
)


def _ensure_not_inference_only_backward(trace: Any) -> None:
    """Reject deferred backward capture for inference-only traces.

    Parameters
    ----------
    trace:
        Trace receiving backward metadata.

    Raises
    ------
    ConfigurationError
        If the trace was captured with ``inference_only=True``.
    """

    if getattr(trace, "inference_only", False):
        raise ConfigurationError(_INFERENCE_ONLY_BACKWARD_ERROR)


def _ensure_not_chunked_forward_backward(trace: Any) -> None:
    """Reject deferred backward capture for chunked-forward traces.

    Parameters
    ----------
    trace:
        Trace receiving backward metadata.

    Raises
    ------
    ConfigurationError
        If the trace was captured with ``chunk_size``.
    """

    if getattr(trace, "chunked_forward", False):
        raise ConfigurationError(_CHUNKED_FORWARD_BACKWARD_ERROR)


def _capture_backward_call_context(trace: Any) -> FuncCallLocation | None:
    """Return the first non-TorchLens caller location for a backward API call.

    Parameters
    ----------
    trace:
        Trace whose source-loading preference controls lazy source context.

    Returns
    -------
    FuncCallLocation | None
        User-visible call-site location, or ``None`` if no external frame is found.
    """

    frame = inspect.currentframe()
    if frame is None:
        return None
    frame = frame.f_back
    while frame is not None:
        filename = os.path.abspath(frame.f_code.co_filename)
        if not filename.startswith(_TORCHLENS_PKG_DIR):
            source_loading_enabled = bool(getattr(trace, "save_code_context", False))
            func_name = frame.f_code.co_name
            return FuncCallLocation(
                file=frame.f_code.co_filename,
                line_number=frame.f_lineno,
                func_name=func_name,
                num_context_lines_requested=int(getattr(trace, "num_context_lines", 7)),
                _frame_func_obj=(
                    frame.f_locals.get(func_name) or frame.f_globals.get(func_name)
                    if source_loading_enabled
                    else None
                ),
                code_firstlineno=frame.f_code.co_firstlineno,
                func_qualname=_get_code_qualname(frame),
                col_offset=_get_col_offset(frame),
                source_loading_enabled=source_loading_enabled,
            )
        frame = frame.f_back
    return None


def _strong_grad_fn_refs(trace: Any) -> list[Any]:
    """Return the trace-owned grad-fn strong-reference list.

    Parameters
    ----------
    trace:
        Trace that owns runtime autograd node references.

    Returns
    -------
    list[Any]
        Mutable list holding grad-fn wrapper objects for the trace lifetime.
    """

    return trace.__dict__.setdefault("_backward_gradfn_refs", [])


def _forward_op_count_at_backward_trigger(trace: Any) -> int | None:
    """Return the number of forward ops created when a backward trigger starts.

    Parameters
    ----------
    trace:
        Trace being backward-captured.

    Returns
    -------
    int | None
        Active forward op count when available, otherwise the highest finalized
        layer ``step_index``. ``None`` means no structural count is available.
    """

    from ...capture import projections

    active_state = getattr(projections, "_active_recording_state", None)
    if active_state is not None and getattr(active_state, "runtime_trace", None) is trace:
        return max(0, int(active_state.step_index) - 1)

    step_indices = [
        int(step_index)
        for layer in getattr(trace, "layer_list", ())
        if isinstance((step_index := getattr(layer, "step_index", None)), int) and step_index > 0
    ]
    if step_indices:
        return max(step_indices)
    raw_count = getattr(trace, "_layer_counter", None)
    return raw_count if isinstance(raw_count, int) else None


def _active_forward_op_count_at_trigger() -> int | None:
    """Return active forward op count before autograd graph walking.

    Returns
    -------
    int | None
        Last forward ``step_index`` that exists before the active autograd
        trigger's graph walk, or ``None`` when no forward capture is active.
    """

    from ...capture import projections

    active_state = getattr(projections, "_active_recording_state", None)
    if active_state is None:
        return None
    return max(0, int(active_state.step_index) - 1)


def _register_forward_grad_fn(trace: Any, grad_fn_handle: Any, _raw_label: str | None) -> None:
    """Register a pinned forward grad-fn object for later autograd triggers.

    Parameters
    ----------
    trace:
        Trace that recorded the forward operation.
    grad_fn_handle:
        Live PyTorch autograd node wrapper from the operation output.
    _raw_label:
        Raw TorchLens op label associated with the output tensor, if known.

    Returns
    -------
    None
        The process registry and trace strong-ref set are updated in place.
    """

    if grad_fn_handle is None:
        return
    refs = _strong_grad_fn_refs(trace)
    refs.append(grad_fn_handle)
    grad_fn_object_id = id(grad_fn_handle)
    _BACKWARD_GRAD_FN_REGISTRY[grad_fn_object_id] = weakref.ref(trace)


def _purge_trace_from_backward_registry(trace: Any) -> None:
    """Remove every registry key currently owned by ``trace``.

    Parameters
    ----------
    trace:
        Trace being cleaned up or disarmed.

    Returns
    -------
    None
        Matching process-registry entries are removed.
    """

    stale_ids = [
        grad_fn_object_id
        for grad_fn_object_id, trace_ref in _BACKWARD_GRAD_FN_REGISTRY.items()
        if trace_ref() is trace or trace_ref() is None
    ]
    for grad_fn_object_id in stale_ids:
        _BACKWARD_GRAD_FN_REGISTRY.pop(grad_fn_object_id, None)


def _close_implicit_backward_pass_if_open(trace: Any) -> None:
    """Close an implicit backward bracket at a synchronization point.

    Parameters
    ----------
    trace:
        Trace that may have an orphan tensor-hook bracket open.

    Returns
    -------
    None
        An implicit ``BackwardPassEnd`` is appended when needed.
    """

    if not getattr(trace, "_implicit_backward_pass_open", False):
        return
    pass_index = getattr(trace, "_active_backward_pass_index", None)
    if pass_index is None:
        return
    events = _ensure_backward_event_stream(trace)
    events.append_backward(
        BackwardPassEnd(
            pass_index=int(pass_index),
            duration=None,
            peak_memory=None,
            status="ok",
            order_attribution_coverage=None,
        )
    )
    trace.num_backward_passes = max(int(getattr(trace, "num_backward_passes", 0)), int(pass_index))
    trace.__dict__.pop("_active_backward_pass_index", None)
    _clear_pending_accumulate_grad_records(trace)
    trace._implicit_backward_pass_open = False
    _materialize_backward_projections(trace)


def _root_tensors(value: Any) -> tuple[torch.Tensor, ...]:
    """Flatten autograd root arguments into tensors.

    Parameters
    ----------
    value:
        Tensor or nested sequence passed to an autograd engine entry.

    Returns
    -------
    tuple[torch.Tensor, ...]
        Tensor roots in left-to-right order.
    """

    if isinstance(value, torch.Tensor):
        return (value,)
    if isinstance(value, Sequence) and not isinstance(value, (str, bytes)):
        tensors: list[torch.Tensor] = []
        for item in value:
            tensors.extend(_root_tensors(item))
        return tuple(tensors)
    return ()


def _traces_for_roots(roots: Any) -> tuple[Any, ...]:
    """Find live traces whose pinned grad-fn ids appear under ``roots``.

    Parameters
    ----------
    roots:
        Tensor or nested tensor sequence passed to an autograd entry point.

    Returns
    -------
    tuple[Any, ...]
        Matched traces in discovery order, without duplicates.
    """

    if not _BACKWARD_GRAD_FN_REGISTRY:
        return ()
    matched: list[Any] = []
    matched_ids: set[int] = set()
    stale_ids: list[int] = []
    queue: deque[Any] = deque(
        root.grad_fn for root in _root_tensors(roots) if root.grad_fn is not None
    )
    seen: set[int] = set()
    while queue:
        grad_fn_handle = queue.popleft()
        grad_fn_object_id = id(grad_fn_handle)
        if grad_fn_object_id in seen:
            continue
        seen.add(grad_fn_object_id)
        trace_ref = _BACKWARD_GRAD_FN_REGISTRY.get(grad_fn_object_id)
        if trace_ref is not None:
            trace = trace_ref()
            if trace is None or not hasattr(trace, "layer_list"):
                stale_ids.append(grad_fn_object_id)
            elif id(trace) not in matched_ids and not getattr(
                trace, "_tl_backward_triggers_disarmed", False
            ):
                matched.append(trace)
                matched_ids.add(id(trace))
        queue.extend(_iter_next_grad_fns(grad_fn_handle))
    for stale_id in stale_ids:
        _BACKWARD_GRAD_FN_REGISTRY.pop(stale_id, None)
    return tuple(matched)


def _autograd_roots_from_call(
    args: tuple[Any, ...],
    kwargs: dict[str, Any],
    root_kwarg: str,
) -> Any:
    """Return root tensors from an autograd wrapper call.

    Parameters
    ----------
    args:
        Positional arguments passed to the wrapped function.
    kwargs:
        Keyword arguments passed to the wrapped function.
    root_kwarg:
        Keyword name that carries roots for this autograd entry.

    Returns
    -------
    Any
        Original root argument object, or ``None`` when absent.
    """

    if args:
        return args[0]
    return kwargs.get(root_kwarg)


def _first_root_tensor(roots: Any) -> torch.Tensor | None:
    """Return the first tensor in an autograd root object.

    Parameters
    ----------
    roots:
        Tensor or nested sequence of tensors.

    Returns
    -------
    torch.Tensor | None
        First tensor root, if one exists.
    """

    tensors = _root_tensors(roots)
    return tensors[0] if tensors else None


def _root_forward_op_count(trace: Any, roots: Any) -> int | None:
    """Return the highest forward ``step_index`` among autograd root tensors.

    Parameters
    ----------
    trace:
        Trace that owns the root tensors.
    roots:
        Tensor or nested tensor sequence passed to an autograd entry point.

    Returns
    -------
    int | None
        Highest resolved root forward position, or ``None`` when no root label
        can be resolved.
    """

    root_steps = [
        step_index
        for root in _root_tensors(roots)
        if (step_index := _root_tensor_step_index(trace, root)) is not None
    ]
    return max(root_steps) if root_steps else None


def _root_tensor_step_index(trace: Any, root: torch.Tensor) -> int | None:
    """Return a TorchLens ``step_index`` for an autograd root tensor.

    Parameters
    ----------
    trace:
        Trace that owns the root tensor.
    root:
        Root tensor passed to an autograd entry point.

    Returns
    -------
    int | None
        Root layer ``step_index`` when resolvable.
    """

    label = get_tensor_label(root)
    if label is None:
        return None
    lookup_labels = (getattr(trace, "_raw_to_final_layer_labels", {}).get(label, label), label)
    layer_lookup = getattr(trace, "layer_dict_all_keys", {})
    for lookup_label in lookup_labels:
        layer = layer_lookup.get(lookup_label)
        step_index = getattr(layer, "step_index", None)
        if isinstance(step_index, int):
            return step_index
    raw_match = re.search(r"_(\d+)_raw$", label)
    if raw_match is not None:
        return int(raw_match.group(1))
    final_match = re.search(r"_[1-9]\d*_(\d+)(?::[1-9]\d*)?$", label)
    if final_match is not None:
        return int(final_match.group(1))
    return None


def _grad_fn_is_custom(grad_fn_handle: Any) -> bool:
    """Return whether a grad_fn_handle appears to come from user/custom autograd code.

    Parameters
    ----------
    grad_fn_handle:
        Autograd function object.

    Returns
    -------
    bool
        True when the type's module path is outside PyTorch's built-in autograd
        and nn namespaces.
    """
    class_module = type(grad_fn_handle).__module__
    if class_module == "torch.autograd.function":
        return True
    builtin_prefixes = ("torch.autograd", "torch.nn", "torch", "builtins")
    return not class_module.startswith(builtin_prefixes)


def _safe_source_file_and_line(obj: Any) -> tuple[str | None, int | None]:
    """Return source file and first line for an object when introspection works.

    Parameters
    ----------
    obj:
        Object to inspect.

    Returns
    -------
    tuple[str | None, int | None]
        Source file and line, or ``(None, None)`` when unavailable.
    """

    try:
        source_file = inspect.getsourcefile(obj) or inspect.getfile(obj)
        source_line = inspect.getsourcelines(obj)[1]
    except (OSError, TypeError):
        return None, None
    return source_file, source_line


def _safe_signature(obj: Any) -> str | None:
    """Return an inspect signature string when available.

    Parameters
    ----------
    obj:
        Callable object to inspect.

    Returns
    -------
    str | None
        Signature string, or ``None`` when unavailable.
    """

    try:
        return str(inspect.signature(obj))
    except (TypeError, ValueError):
        return None


def _grad_fn_source_metadata(grad_fn_cls: type[Any]) -> dict[str, Any]:
    """Return best-effort source metadata for a grad-fn class.

    Parameters
    ----------
    grad_fn_cls:
        Runtime class of the autograd grad-fn object.

    Returns
    -------
    dict[str, Any]
        Keyword arguments accepted by ``GradFn`` for source metadata fields.
    """

    class_source_file, class_source_line = _safe_source_file_and_line(grad_fn_cls)
    init_method = getattr(grad_fn_cls, "__init__", None)
    forward_method = getattr(grad_fn_cls, "forward", None)
    backward_method = getattr(grad_fn_cls, "backward", None)
    init_source_file, init_source_line = _safe_source_file_and_line(init_method)
    forward_source_file, forward_source_line = _safe_source_file_and_line(forward_method)
    backward_source_file, backward_source_line = _safe_source_file_and_line(backward_method)
    return {
        "class_source_file": class_source_file,
        "class_source_line": class_source_line,
        "class_docstring": grad_fn_cls.__doc__,
        "init_source_file": init_source_file,
        "init_source_line": init_source_line,
        "init_signature": _safe_signature(init_method),
        "init_docstring": getattr(init_method, "__doc__", None),
        "forward_source_file": forward_source_file,
        "forward_source_line": forward_source_line,
        "forward_signature": _safe_signature(forward_method),
        "forward_docstring": getattr(forward_method, "__doc__", None),
        "backward_source_file": backward_source_file,
        "backward_source_line": backward_source_line,
        "backward_signature": _safe_signature(backward_method),
        "backward_docstring": getattr(backward_method, "__doc__", None),
    }


def _iter_next_grad_fns(grad_fn_handle: Any) -> Iterator[Any]:
    """Yield non-null child grad_fns from ``grad_fn_handle.next_functions``.

    Parameters
    ----------
    grad_fn_handle:
        Autograd function object.

    Yields
    ------
    Any
        Reachable child grad_fn_handle object.
    """
    for next_fn, _input_num in getattr(grad_fn_handle, "next_functions", ()):
        if next_fn is not None:
            yield next_fn


def _selected_for_grad_save(trace: Any, layer_label: str | None) -> bool:
    """Return whether a forward layer's grad should be saved.

    Parameters
    ----------
    trace:
        Trace being updated.
    layer_label:
        Final layer label, or ``None`` for intervening grad_fns.

    Returns
    -------
    bool
        True if this layer is selected by the trace's gradient-retention policy.
    """
    if layer_label is None:
        return False
    selection = getattr(trace, "_grad_op_nums_to_save", "all")
    if selection == "all":
        return True
    if selection in [None, "none", []]:
        return False
    return trace.layer_dict_all_keys[layer_label].raw_index in selection


def _sync_grad_fn_graph_relations(trace: Any) -> None:
    """Populate backward-oriented GradFn graph relation labels.

    Parameters
    ----------
    trace:
        Trace whose ``grad_fn_logs`` should be synchronized.
    """

    id_to_label = {
        grad_fn_object_id: grad_fn.label
        for grad_fn_object_id, grad_fn in trace.grad_fn_logs.items()
    }
    child_map: dict[str, list[str]] = {}
    parent_map: dict[str, list[str]] = {
        grad_fn.label: [] for grad_fn in trace.grad_fn_logs.values()
    }

    for grad_fn in trace.grad_fn_logs.values():
        children = [
            id_to_label[next_grad_fn_id]
            for next_grad_fn_id in grad_fn.next_grad_fn_ids
            if next_grad_fn_id in id_to_label
        ]
        child_map[grad_fn.label] = children
        for child_label in children:
            if grad_fn.label not in parent_map[child_label]:
                parent_map[child_label].append(grad_fn.label)

    for grad_fn in trace.grad_fn_logs.values():
        grad_fn.children = child_map[grad_fn.label]
        grad_fn.parents = parent_map[grad_fn.label]
        sibling_labels: list[str] = []
        for parent_label in grad_fn.parents:
            for sibling_label in child_map.get(parent_label, []):
                if sibling_label != grad_fn.label and sibling_label not in sibling_labels:
                    sibling_labels.append(sibling_label)
        grad_fn.siblings = sibling_labels

        co_parent_labels: list[str] = []
        for child_label in grad_fn.children:
            for co_parent_label in parent_map.get(child_label, []):
                if co_parent_label != grad_fn.label and co_parent_label not in co_parent_labels:
                    co_parent_labels.append(co_parent_label)
        grad_fn.co_parents = co_parent_labels


def _param_module_address(trace: Any, param_ref: object | None) -> str | None:
    """Return the owning module address for a parameter reference.

    Parameters
    ----------
    trace:
        Trace containing parameter logs.
    param_ref:
        Parameter address recorded on an ``AccumulateGrad`` discovery event.

    Returns
    -------
    str | None
        Owning module address, or ``None`` when the parameter is unknown.
    """

    if not isinstance(param_ref, str):
        return None
    param_logs = getattr(trace, "param_logs", {})
    if param_ref not in param_logs:
        return None
    param_log = param_logs[param_ref]
    return None if param_log is None else getattr(param_log, "module_address", None)


def _op_module_address(trace: Any, op_label: str | None) -> str | None:
    """Return the containing module address for a paired forward op label.

    Parameters
    ----------
    trace:
        Trace containing op logs.
    op_label:
        Forward op label paired to a grad-fn record.

    Returns
    -------
    str | None
        Module address for the paired op, if known.
    """

    if op_label is None or op_label not in getattr(trace, "layer_dict_all_keys", {}):
        return None
    op = trace.layer_dict_all_keys[op_label]
    module_address = getattr(op, "module_address", None)
    if module_address is not None:
        return cast(str, module_address)
    atomic_module_address = getattr(op, "atomic_module_address", None)
    if atomic_module_address is not None:
        return cast(str, atomic_module_address)
    output_module_calls = list(getattr(op, "output_of_module_calls", []) or [])
    if output_module_calls:
        return str(output_module_calls[-1]).rsplit(":", 1)[0]
    module_calls = list(getattr(op, "modules", []) or [])
    if not module_calls:
        return None
    return str(module_calls[-1]).rsplit(":", 1)[0]


def _resolve_op_grad_event_label(trace: Any, op_label: str) -> str:
    """Return the final lookup label for an ``OpGradObserved`` event.

    Parameters
    ----------
    trace:
        Trace that owns the event.
    op_label:
        Raw or final op label stored on the event.

    Returns
    -------
    str
        Final lookup label when postprocess mappings know it; otherwise the
        original label.
    """

    raw_to_final_layer = getattr(trace, "_raw_to_final_layer_labels", {})
    if isinstance(raw_to_final_layer, dict) and op_label in raw_to_final_layer:
        return str(raw_to_final_layer[op_label])
    raw_to_final_op = getattr(trace, "_raw_to_final_op_labels", {})
    if isinstance(raw_to_final_op, dict) and op_label in raw_to_final_op:
        return str(raw_to_final_op[op_label])
    return op_label


def _op_raw_index(trace: Any, grad_fn_record: GradFn) -> int | None:
    """Return the forward raw index backing a grad-fn's module attribution.

    Parameters
    ----------
    trace:
        Trace containing op logs.
    grad_fn_record:
        GradFn whose attributed op position should be inspected.

    Returns
    -------
    int | None
        Forward raw index, or ``None`` for parameter-only and unresolved records.
    """

    op_label = grad_fn_record.op_label
    if op_label is None or op_label not in getattr(trace, "layer_dict_all_keys", {}):
        return None
    return int(getattr(trace.layer_dict_all_keys[op_label], "raw_index"))


def _post_forward_grad_fn_ids(grad_fn_logs: dict[int, GradFn]) -> set[int]:
    """Return loss-construction grad-fn ids before the first op-anchored node.

    Parameters
    ----------
    grad_fn_logs:
        Projected GradFn records in backward discovery order.

    Returns
    -------
    set[int]
        Unpaired, non-creator-attributed ids that should not receive inferred
        module containment.
    """

    op_steps = [
        grad_fn_record.step_index
        for grad_fn_record in grad_fn_logs.values()
        if grad_fn_record.has_op
    ]
    if not op_steps:
        return set()
    first_op_step = min(op_steps)
    return {
        object_id
        for object_id, grad_fn_record in grad_fn_logs.items()
        if (
            grad_fn_record.step_index < first_op_step
            and not grad_fn_record.has_op
            and grad_fn_record.creator_object_id is None
        )
    }


def _candidate_module_sort_key(trace: Any, candidate: GradFn) -> tuple[int, int, str]:
    """Return the deterministic P5 tie-break key for a containment candidate.

    Parameters
    ----------
    trace:
        Trace containing forward op logs.
    candidate:
        Neighbor GradFn with resolved module containment.

    Returns
    -------
    tuple[int, int, str]
        Sort key where smaller values are preferred.
    """

    raw_index = _op_raw_index(trace, candidate)
    consumer_rank = -(raw_index if raw_index is not None else -1)
    return (consumer_rank, candidate.step_index, candidate.label)


def _infer_grad_fn_module_membership(trace: Any) -> None:
    """Populate inferred module containment for intervening backward nodes.

    Parameters
    ----------
    trace:
        Trace whose ``grad_fn_logs`` already have graph relations synchronized.

    Returns
    -------
    None
        GradFn ``modules``, ``module_address``, and ``module_membership_source``
        fields are updated in place.
    """

    grad_fn_logs = getattr(trace, "grad_fn_logs", {})
    label_to_id = {grad_fn.label: object_id for object_id, grad_fn in grad_fn_logs.items()}
    carve_out_ids = _post_forward_grad_fn_ids(grad_fn_logs)
    changed = True
    while changed:
        changed = False
        for object_id, grad_fn_record in grad_fn_logs.items():
            if (
                object_id in carve_out_ids
                or grad_fn_record.module_membership_source is not None
                or grad_fn_record.creator_object_id is not None
            ):
                continue
            neighbor_ids = [
                label_to_id[label]
                for label in [*grad_fn_record.parents, *grad_fn_record.children]
                if label in label_to_id
            ]
            candidates = [
                grad_fn_logs[neighbor_id]
                for neighbor_id in neighbor_ids
                if grad_fn_logs[neighbor_id].module_membership_source is not None
            ]
            if not candidates:
                continue
            winner = min(
                candidates, key=lambda candidate: _candidate_module_sort_key(trace, candidate)
            )
            if winner.module_address is None:
                continue
            grad_fn_record.module_address = winner.module_address
            grad_fn_record.modules = list(winner.modules) or [winner.module_address]
            grad_fn_record.module_membership_source = "inferred"
            changed = True


def _prefer_direct_pairing_source_for_paired_ops(trace: Any) -> None:
    """Mark direct op pairings as paired after containment inference.

    Parameters
    ----------
    trace:
        Trace whose ``grad_fn_logs`` should be normalized.

    Returns
    -------
    None
        Directly paired GradFn records keep any inferred module address but expose
        ``module_membership_source="paired"``.
    """

    for grad_fn_record in getattr(trace, "grad_fn_logs", {}).values():
        op = grad_fn_record.op
        if (
            op is not None
            and (getattr(op, "is_compute_op", False) or getattr(op, "is_compute_layer", False))
            and grad_fn_record.module_membership_source == "inferred"
        ):
            grad_fn_record.module_membership_source = "paired"


def _resolved_order_for_creator(
    creator_object_id: int | None,
    grad_fn_logs: dict[int, GradFn],
) -> int | None:
    """Return the derived order for a creator-attributed grad-fn node."""

    if creator_object_id is None:
        return 1
    creator = grad_fn_logs.get(creator_object_id)
    creator_order = None if creator is None else creator.order
    if creator_order is None:
        return None
    return creator_order + 1


def _pass_order_from_roots(
    root_grad_fn_ids: Sequence[int],
    grad_fn_logs: dict[int, GradFn],
    pass_orders: dict[int, int],
) -> int | None:
    """Derive a backward pass order from its root grad-fn nodes."""

    root_orders = [
        _root_based_order(grad_fn_logs[root_id], pass_orders)
        for root_id in root_grad_fn_ids
        if root_id in grad_fn_logs
    ]
    if not root_orders:
        return None
    if any(root_order is None for root_order in root_orders):
        return None
    if len(root_orders) != len(root_grad_fn_ids):
        return None
    unique_orders = set(root_orders)
    if len(unique_orders) != 1:
        return None
    return cast(int, root_orders[0])


def _root_based_order(root_grad_fn: GradFn, pass_orders: dict[int, int]) -> int | None:
    """Return the ROOT-based pass order for one root grad-fn.

    Parameters
    ----------
    root_grad_fn:
        Root autograd node for the backward pass.
    pass_orders:
        Already materialized pass orders keyed by pass index.

    Returns
    -------
    int | None
        Root-based order, or ``None`` when the root cannot be attributed.
    """

    origin_backward_pass = root_grad_fn.origin_backward_pass
    if origin_backward_pass is None:
        return root_grad_fn.order
    origin_order = pass_orders.get(origin_backward_pass)
    if origin_order is None:
        return root_grad_fn.order
    return origin_order + 1


def _order_attribution_coverage(
    calls: Sequence[GradFnCall],
    grad_fn_logs: dict[int, GradFn],
) -> float | None:
    """Return the fraction of calls with resolved grad-fn order metadata."""

    if not calls:
        return None
    labels_with_order = {
        grad_fn.label for grad_fn in grad_fn_logs.values() if grad_fn.order is not None
    }
    covered = sum(1 for call in calls if call.label in labels_with_order)
    return covered / len(calls)


def _max_call_order(
    calls: Sequence[GradFnCall],
    grad_fn_logs: dict[int, GradFn],
) -> int | None:
    """Return the maximum resolved GradFn order among calls in one pass.

    Parameters
    ----------
    calls:
        Materialized GradFn calls for a backward pass.
    grad_fn_logs:
        GradFn records keyed by object id.

    Returns
    -------
    int | None
        Highest order observed among the pass calls, or ``None`` when no call has
        resolved order metadata.
    """

    label_to_order = {
        grad_fn.label: grad_fn.order
        for grad_fn in grad_fn_logs.values()
        if grad_fn.order is not None
    }
    call_orders = [label_to_order[call.label] for call in calls if call.label in label_to_order]
    return max(call_orders) if call_orders else None


def _assign_grad_fn_orders(grad_fn_logs: dict[int, GradFn]) -> None:
    """Populate resolved GradFn order values from creators and known topology."""

    for grad_fn_record in grad_fn_logs.values():
        grad_fn_record.order = _resolved_order_for_creator(
            grad_fn_record.creator_object_id,
            grad_fn_logs,
        )

    changed = True
    while changed:
        changed = False
        for grad_fn_record in grad_fn_logs.values():
            if grad_fn_record.creator_object_id is not None or grad_fn_record.has_op:
                continue
            child_orders: list[int] = []
            for child_id in grad_fn_record.next_grad_fn_ids:
                child = grad_fn_logs.get(child_id)
                if child is not None and child.order is not None:
                    child_orders.append(child.order)
            if not child_orders:
                continue
            inferred_order = max(child_orders)
            if inferred_order > 1 and grad_fn_record.order != inferred_order:
                grad_fn_record.order = inferred_order
                changed = True


def _normalize_grad_fn_type(grad_fn_handle: Any) -> str:
    """Normalize an autograd grad_fn_handle class name for TorchLens labels.

    Parameters
    ----------
    grad_fn_handle:
        Autograd function object.

    Returns
    -------
    str
        Lowercased class name with a trailing ``Backward<digits>`` suffix removed.
    """
    return re.sub(r"Backward\d*$", "", type(grad_fn_handle).__name__).lower()


def _grad_fn_label_parts(
    trace: Any,
    type: str,
    _layer_label: str | None,
    type_counter: dict[str, int],
    total_num: int,
) -> tuple[int, int, str]:
    """Build numeric label fields for one grad_fn_handle.

    Parameters
    ----------
    trace:
        Trace being updated.
    type:
        Normalized grad_fn_handle type.
    _layer_label:
        Matching forward layer label, or ``None`` for intervening grad_fns.
    type_counter:
        Running per-type counter for intervening grad_fns.
    total_num:
        One-based discovery index in the backward graph.

    Returns
    -------
    tuple[int, int, str]
        GradFn type index, total index, and user-facing label.
    """
    del trace, _layer_label
    type_counter[type] = type_counter.get(type, 0) + 1
    type_num = type_counter[type]
    label = f"{type}_back_{type_num}_{total_num}"
    return type_num, total_num, label


def _grad_fn_type_from_class_name(class_name: str) -> str:
    """Normalize an autograd class name for native backward labels."""

    return re.sub(r"Backward\d*$", "", class_name).lower()


def _materialize_backward_projections(trace: Any) -> None:
    """Rebuild backward-facing Trace records from sidecar events.

    Parameters
    ----------
    trace:
        Trace whose runtime backward event sidecar is authoritative.

    Returns
    -------
    None
        ``grad_fn_logs``, ``grad_fn_order``, ``backward_pass_logs``, and
        related counters are replaced in place.
    """

    if getattr(trace, "_tl_active_backward_bracket", False):
        return
    if getattr(trace, "_tl_materializing_backward_projection", False):
        return
    events = list(getattr(_ensure_backward_event_stream(trace), "backward_events", ()))
    if not events:
        return
    if getattr(trace, "_backward_projection_event_count", None) == len(events):
        return
    trace._tl_materializing_backward_projection = True
    try:
        _materialize_backward_projections_impl(trace, events)
    finally:
        trace.__dict__.pop("_tl_materializing_backward_projection", None)


def _materialize_backward_projections_impl(trace: Any, events: list[Any]) -> None:
    """Rebuild backward projections from an already-snapshotted event list."""

    starts: dict[int, BackwardPassStart] = {}
    ends: dict[int, BackwardPassEnd] = {}
    discovered: OrderedDict[int, GradFnDiscovered] = OrderedDict()
    latest_topology: dict[int, tuple[int, ...]] = {}
    fired_events: list[GradFnFired] = []
    op_grad_passes: set[int] = set()
    op_grad_events: list[OpGradObserved] = []
    for event in events:
        if isinstance(event, BackwardPassStart):
            starts[event.pass_index] = event
        elif isinstance(event, BackwardPassEnd):
            ends[event.pass_index] = event
        elif isinstance(event, GradFnDiscovered):
            if event.object_id not in discovered:
                discovered[event.object_id] = event
            else:
                existing = discovered[event.object_id]
                if existing.op_label is None and event.op_label is not None:
                    existing = replace(existing, op_label=event.op_label)
                if existing.param_ref is None and event.param_ref is not None:
                    existing = replace(existing, param_ref=event.param_ref)
                if existing.created_in_pass is None and event.created_in_pass is not None:
                    existing = replace(existing, created_in_pass=event.created_in_pass)
                if existing.creator_object_id is None and event.creator_object_id is not None:
                    existing = replace(existing, creator_object_id=event.creator_object_id)
                discovered[event.object_id] = existing
            latest_topology[event.object_id] = event.topology
        elif isinstance(event, GradFnFired):
            fired_events.append(event)
        elif isinstance(event, OpGradObserved):
            op_grad_passes.add(event.pass_index)
            op_grad_events.append(event)

    grad_fn_logs: OrderedDict[int, GradFn] = OrderedDict()
    type_counter: dict[str, int] = {}
    object_to_label: dict[int, str] = {}
    for ordinal_index, (object_id, event) in enumerate(discovered.items()):
        grad_fn_type = _grad_fn_type_from_class_name(event.class_name)
        step_index = ordinal_index + 1
        type_index, step_index, label = _grad_fn_label_parts(
            trace,
            grad_fn_type,
            event.op_label,
            type_counter,
            step_index,
        )
        source_fields = cast(dict[str, Any], dict(event.source))
        modules: list[str] = []
        module_address = None
        module_membership_source = None
        op_module_address = _op_module_address(trace, event.op_label)
        param_module_address = _param_module_address(trace, event.param_ref)
        if op_module_address is not None:
            module_address = op_module_address
            modules = [module_address]
            module_membership_source = "paired"
        elif param_module_address is not None:
            module_address = param_module_address
            modules = [module_address]
            module_membership_source = "paired"
        grad_fn_record = GradFn(
            grad_fn_object_id=object_id,
            class_name=event.class_name,
            class_qualname=event.class_qualname,
            label=label,
            type=grad_fn_type,
            type_index=type_index,
            ordinal_index=ordinal_index,
            step_index=step_index,
            is_custom=event.is_custom,
            has_op=event.op_label is not None,
            op_label=event.op_label,
            order=None,
            origin_backward_pass=event.created_in_pass,
            creator_object_id=event.creator_object_id,
            modules=modules,
            module_address=module_address,
            module_membership_source=module_membership_source,
            next_grad_fn_ids=list(latest_topology.get(object_id, event.topology)),
            **source_fields,
        )
        grad_fn_record.source_trace = trace
        grad_fn_logs[object_id] = grad_fn_record
        object_to_label[object_id] = label

    _assign_grad_fn_orders(grad_fn_logs)

    for object_id, grad_fn_record in grad_fn_logs.items():
        if grad_fn_record.creator_object_id is not None:
            grad_fn_record.differentiates = object_to_label.get(grad_fn_record.creator_object_id)

    trace.grad_fn_logs = grad_fn_logs
    trace.grad_fn_order = list(grad_fn_logs)

    pass_to_calls: dict[int, list[GradFnCall]] = {}
    per_object_ordinals: dict[int, int] = {}
    for event in sorted(fired_events, key=lambda item: (item.pass_index, item.timestamp, item.seq)):
        grad_fn_record = trace.grad_fn_logs.get(event.object_id)
        if grad_fn_record is None:
            continue
        ordinal = per_object_ordinals.get(event.object_id, 0) + 1
        per_object_ordinals[event.object_id] = ordinal
        call = GradFnCall(
            call_index=ordinal,
            ordinal=ordinal,
            backward_pass_index=event.pass_index,
            label=grad_fn_record.label,
            grad_inputs=event.grad_input_refs,
            grad_outputs=event.grad_output_refs,
            intervention_fire_ref=event.intervention_fire_ref,
            timestamp=event.timestamp,
            _time_started=event.timestamp,
            _time_finished=event.timestamp,
        )
        call.source_trace = trace
        grad_fn_record.calls[ordinal] = call
        pass_to_calls.setdefault(event.pass_index, []).append(call)

    _sync_grad_fn_graph_relations(trace)
    _infer_grad_fn_module_membership(trace)
    _prefer_direct_pairing_source_for_paired_ops(trace)

    unique_payload_ids: set[int] = set()
    total_gradient_memory = 0
    total_backward_memory = 0
    saved_grad_labels: set[str] = set()
    for op in getattr(trace, "layer_list", []):
        op._clear_gradient_records()
    for event in sorted(
        op_grad_events, key=lambda item: (item.pass_index, item.timestamp, item.seq)
    ):
        event_label = _resolve_op_grad_event_label(trace, event.op_label)
        if event_label not in getattr(trace, "layer_dict_all_keys", {}):
            continue
        op = trace.layer_dict_all_keys[event_label]
        payload = event.payload_ref if isinstance(event.payload_ref, torch.Tensor) else None
        transformed_payload = event.transformed_payload_ref
        op._record_gradient(
            backward_pass_index=event.pass_index,
            grad=payload,
            transformed_grad=transformed_payload,
            shape=event.shape,
            dtype=event.dtype,
            memory=event.memory,
            timestamp=event.timestamp,
        )
        if payload is None and transformed_payload is None:
            continue
        op.has_grad = True
        if event.shape is not None:
            op.grad_shape = tuple(event.shape)
        if event.dtype is not None:
            op.grad_dtype = _torch_dtype_from_string(event.dtype)
        op.gradient_memory = Bytes(event.memory or 0)
        op._internal_set("grad", payload)
        op._internal_set("transformed_grad", transformed_payload)
        op.transformed_grad_shape = _shape_or_none(transformed_payload)
        op.transformed_grad_dtype = _dtype_or_none(transformed_payload)
        op.transformed_gradient_memory = _memory_or_none(transformed_payload)
        saved_grad_labels.add(op.layer_label)
        for payload_ref, payload_memory in _retained_grad_payload_refs(
            payload, transformed_payload, raw_memory=event.memory
        ):
            payload_id = id(payload_ref)
            if payload_id not in unique_payload_ids:
                unique_payload_ids.add(payload_id)
                total_backward_memory += payload_memory
        total_gradient_memory += int(event.memory or 0)
    trace._saved_grad_labels = saved_grad_labels
    trace.saved_gradient_memory = Bytes(total_gradient_memory)
    trace.total_gradient_memory = Bytes(total_gradient_memory)
    trace.total_backward_memory = Bytes(total_backward_memory)

    roots_by_pass = getattr(trace, "_backward_roots_by_pass", {})
    backward_pass_logs: OrderedDict[int, BackwardPass] = OrderedDict()
    pass_indices = sorted(set(starts) | set(ends) | set(pass_to_calls) | op_grad_passes)
    resolved_pass_orders: dict[int, int] = {}
    for pass_index in pass_indices:
        start = starts.get(pass_index)
        end = ends.get(pass_index)
        root_grad_fn_ids = list(roots_by_pass.get(pass_index, ()))
        pass_order = (
            _pass_order_from_roots(root_grad_fn_ids, grad_fn_logs, resolved_pass_orders)
            if root_grad_fn_ids
            else start.order
            if start is not None
            else None
        )
        if pass_order is None and start is not None:
            pass_order = start.order
        grad_fn_calls = pass_to_calls.get(pass_index, [])
        max_call_order = _max_call_order(grad_fn_calls, grad_fn_logs)
        if max_call_order is not None and (pass_order is None or max_call_order > pass_order):
            pass_order = max_call_order
        order_attribution_coverage = (
            end.order_attribution_coverage
            if end is not None and end.order_attribution_coverage is not None
            else _order_attribution_coverage(grad_fn_calls, grad_fn_logs)
        )
        pass_record = BackwardPass(
            pass_index=pass_index,
            trigger=start.trigger if start is not None else "implicit",
            implicit=start.implicit if start is not None else True,
            outer_context=start.outer_context if start is not None else None,
            backward_call_context=start.call_context_ref if start is not None else None,
            root_grad_fn_ids=root_grad_fn_ids,
            root_meta=tuple(start.root_meta) if start is not None else (),
            root_grad_arguments=start.root_grad_arguments if start is not None else None,
            inputs_subset=tuple(start.inputs_subset) if start is not None else (),
            order=pass_order,
            origin_backward_pass=start.origin_backward_pass if start is not None else None,
            engine_flags=start.engine_flags if start is not None else None,
            save_grads_policy=start.save_grads_policy_repr if start is not None else None,
            duration=None if end is None or end.duration is None else Duration(end.duration),
            peak_memory=end.peak_memory if end is not None else None,
            status=end.status if end is not None else "ok",
            order_attribution_coverage=order_attribution_coverage,
            grad_fn_calls=grad_fn_calls,
        )
        pass_record.source_trace = trace
        backward_pass_logs[pass_index] = pass_record
        if pass_order is not None:
            resolved_pass_orders[pass_index] = pass_order

    trace.backward_pass_logs = backward_pass_logs
    trace.backward_root_grad_fn_object_ids = [
        root_id for roots in roots_by_pass.values() for root_id in roots
    ]
    trace.num_backward_passes = max(pass_indices) if pass_indices else 0
    trace.has_backward_pass = bool(pass_indices)
    trace.num_saved_grad_fn_calls = len(trace.saved_grad_fn_calls)
    trace.num_saved_grad_fns = len(trace.saved_grad_fns)
    trace._backward_projection_event_count = len(events)

    for grad_fn_record in trace.grad_fn_logs.values():
        if grad_fn_record.op is not None:
            grad_fn_record.op.grad_fn = grad_fn_record
            parent_layer = trace.layer_logs.get(grad_fn_record.op.layer_label)
            if parent_layer is not None:
                parent_layer.grad_fn = grad_fn_record
    for layer in getattr(trace, "layer_list", ()):
        grad_fn_object_id = getattr(layer, "grad_fn_object_id", None)
        if grad_fn_object_id in trace.grad_fn_logs:
            layer.grad_fn = trace.grad_fn_logs[grad_fn_object_id]
    for layer in getattr(trace, "layer_logs", {}).values():
        grad_fn_object_id = getattr(layer, "grad_fn_object_id", None)
        if grad_fn_object_id in trace.grad_fn_logs:
            layer.grad_fn = trace.grad_fn_logs[grad_fn_object_id]


def _torch_dtype_from_string(dtype_name: str) -> torch.dtype | str:
    """Return a ``torch.dtype`` for canonical dtype strings when possible."""

    if dtype_name.startswith("torch."):
        dtype_attr = dtype_name.removeprefix("torch.")
        dtype = getattr(torch, dtype_attr, None)
        if isinstance(dtype, torch.dtype):
            return dtype
    return dtype_name


def _retained_grad_payload_refs(
    raw_payload: torch.Tensor | None,
    transformed_payload: Any | None,
    *,
    raw_memory: int | None,
) -> list[tuple[Any, int]]:
    """Return retained gradient payload refs paired with their memory cost."""

    payloads: list[tuple[Any, int]] = []
    if raw_payload is not None:
        payloads.append((raw_payload, int(raw_memory or 0)))
    transformed_memory = _memory_or_none(transformed_payload)
    if transformed_payload is not None and transformed_memory is not None:
        payloads.append((transformed_payload, int(transformed_memory)))
    return payloads


def _make_grad_fn_hook(
    trace: Any,
    grad_fn_object_id: int,
    *,
    is_accumulate_grad: bool = False,
) -> Callable[..., tuple[torch.Tensor | None, ...] | None]:
    """Build a runtime hook for one autograd grad_fn_handle.

    Parameters
    ----------
    trace:
        Trace whose flat backward fields should receive runtime data.
    grad_fn_object_id:
        ``id()`` of the hooked grad_fn_handle.
    is_accumulate_grad:
        Whether this hook is attached to an AccumulateGrad node.

    Returns
    -------
    Callable[..., tuple[torch.Tensor | None, ...] | None]
        Hook compatible with ``grad_fn_handle.register_hook``.
    """

    trace_ref = weakref.ref(trace)

    def hook(*hook_args: Any) -> tuple[torch.Tensor | None, ...] | None:
        """Record one autograd grad_fn hook firing and apply live interventions."""
        live_trace = trace_ref()
        if live_trace is None:
            return None
        grad_fn_handle = live_trace.grad_fn_logs.get(grad_fn_object_id)
        if grad_fn_handle is None:
            return None
        grad_inputs = hook_args[0] if len(hook_args) >= 1 else None
        grad_outputs = hook_args[1] if len(hook_args) >= 2 else None
        layer_label = grad_fn_handle.op.layer_label if grad_fn_handle.has_op else None
        stored_grad_inputs = grad_inputs
        stored_grad_outputs = grad_outputs
        if not _selected_for_grad_save(live_trace, layer_label):
            stored_grad_inputs = None
            stored_grad_outputs = None
        with pause_logging():
            grad_fn_handle._log_call(stored_grad_inputs, stored_grad_outputs, time.time())
        call_index = len(grad_fn_handle.calls)
        events = _ensure_backward_event_stream(live_trace)
        event_timestamp = time.time()
        pass_index = int(
            getattr(
                live_trace,
                "_active_backward_pass_index",
                getattr(live_trace, "num_backward_passes", 0) + 1,
            )
        )
        _set_live_grad_fn_call_backward_pass_index(grad_fn_handle, call_index, pass_index)
        if is_accumulate_grad:
            fire_records = _pop_pending_accumulate_grad_records(
                live_trace, grad_fn_object_id, call_index
            )
            fire_ref = _intervention_fire_ref(fire_records)
            _set_live_grad_fn_call_fire_ref(grad_fn_handle, call_index, fire_ref)
            _record_higher_order_terminals_from_tuple(
                live_trace,
                tuple(grad_inputs or ()),
                creator_object_id=grad_fn_object_id,
                pass_index=pass_index,
            )
            events.append_backward(
                GradFnFired(
                    object_id=grad_fn_object_id,
                    pass_index=pass_index,
                    grad_input_refs=stored_grad_inputs,
                    grad_output_refs=stored_grad_outputs,
                    intervention_fire_ref=fire_ref,
                    timestamp=event_timestamp,
                    seq=events.next_backward_seq(),
                )
            )
            param_address = getattr(live_trace, "_grad_fn_param_refs_by_object_id", {}).get(
                grad_fn_object_id
            )
            param_log = (
                live_trace.param_logs[param_address]
                if param_address is not None and param_address in live_trace.param_logs
                else None
            )
            picked = _first_tensor_from_hook_args(hook_args)
            if param_log is not None and picked is not None:
                param_log._record_gradient_increment(
                    backward_pass_index=pass_index,
                    grad=picked[2],
                    timestamp=event_timestamp,
                )
            return None
        from ...intervention.runtime import _apply_live_backward_hooks

        result, fire_records = _apply_live_backward_hooks(
            grad_inputs, grad_outputs, grad_fn_handle, call_index
        )
        fire_ref = _intervention_fire_ref(fire_records)
        _set_live_grad_fn_call_fire_ref(grad_fn_handle, call_index, fire_ref)
        terminal_grad_inputs = result if result is not None else grad_inputs
        _record_higher_order_terminals_from_tuple(
            live_trace,
            tuple(terminal_grad_inputs or ()),
            creator_object_id=grad_fn_object_id,
            pass_index=pass_index,
        )
        events.append_backward(
            GradFnFired(
                object_id=grad_fn_object_id,
                pass_index=pass_index,
                grad_input_refs=stored_grad_inputs,
                grad_output_refs=stored_grad_outputs,
                intervention_fire_ref=fire_ref,
                timestamp=event_timestamp,
                seq=events.next_backward_seq(),
            )
        )
        return result

    return hook


def _make_grad_fn_prehook(
    trace: Any,
    grad_fn_object_id: int,
) -> Callable[..., tuple[torch.Tensor | None, ...] | None]:
    """Build an AccumulateGrad prehook for mutating incoming gradients.

    Parameters
    ----------
    trace:
        Trace whose backward hook plan should dispatch.
    grad_fn_object_id:
        ``id()`` of the hooked grad_fn_handle.

    Returns
    -------
    Callable[..., tuple[torch.Tensor | None, ...] | None]
        Hook compatible with ``grad_fn_handle.register_prehook``.
    """

    trace_ref = weakref.ref(trace)

    def prehook(*hook_args: Any) -> tuple[torch.Tensor | None, ...] | None:
        """Apply pending AccumulateGrad prehook interventions for one call."""
        live_trace = trace_ref()
        if live_trace is None:
            return None
        grad_fn_handle = live_trace.grad_fn_logs.get(grad_fn_object_id)
        if grad_fn_handle is None:
            return None
        grad_inputs = hook_args[0] if len(hook_args) >= 1 else ()
        call_index = len(grad_fn_handle.calls) + 1
        from ...intervention.runtime import _apply_live_backward_prehooks

        result, fire_records = _apply_live_backward_prehooks(
            grad_inputs, grad_fn_handle, call_index
        )
        if fire_records:
            _store_pending_accumulate_grad_records(
                live_trace, grad_fn_object_id, call_index, fire_records
            )
        return result

    return prehook


def _intervention_fire_ref(records: tuple[Any, ...]) -> Any | None:
    """Return the compact event-side reference for backward fire records.

    Parameters
    ----------
    records:
        Fire records produced for one backward callback.

    Returns
    -------
    Any | None
        ``None`` for no fires, the single record for one fire, or a tuple for
        multiple helpers fired at the same callback.
    """

    if not records:
        return None
    if len(records) == 1:
        return records[0]
    return records


def _set_live_grad_fn_call_fire_ref(
    grad_fn_handle: Any,
    call_index: int,
    fire_ref: Any | None,
) -> None:
    """Set the fire reference on the just-logged runtime GradFnCall.

    Parameters
    ----------
    grad_fn_handle:
        Runtime GradFn record whose call accessor was just appended.
    call_index:
        One-based callback index.
    fire_ref:
        FireRecord, tuple of records, or ``None``.

    Returns
    -------
    None
        Mutates the runtime call record when a fire reference exists.
    """

    if fire_ref is None:
        return
    calls = getattr(grad_fn_handle, "calls", None)
    call = getattr(calls, "_dict", {}).get(call_index)
    if call is not None:
        call.intervention_fire_ref = fire_ref


def _set_live_grad_fn_call_backward_pass_index(
    grad_fn_handle: Any,
    call_index: int,
    pass_index: int,
) -> None:
    """Set the active backward pass index on the just-logged GradFnCall.

    Parameters
    ----------
    grad_fn_handle:
        Runtime GradFn record whose call accessor was just appended.
    call_index:
        One-based callback index.
    pass_index:
        One-based active backward pass index.

    Returns
    -------
    None
        Mutates the runtime call record when present.
    """

    calls = getattr(grad_fn_handle, "calls", None)
    call = getattr(calls, "_dict", {}).get(call_index)
    if call is not None:
        call.backward_pass_index = pass_index


def _pending_accumulate_grad_record_key(
    grad_fn_object_id: int,
    call_index: int,
) -> tuple[int, int]:
    """Return the trace-local key for pending AccumulateGrad prehook records.

    Parameters
    ----------
    grad_fn_object_id:
        Hooked grad_fn object id.
    call_index:
        One-based callback index.

    Returns
    -------
    tuple[int, int]
        Stable pending-record key.
    """

    return grad_fn_object_id, call_index


def _store_pending_accumulate_grad_records(
    trace: Any,
    grad_fn_object_id: int,
    call_index: int,
    records: tuple[Any, ...],
) -> None:
    """Store AccumulateGrad prehook fire records until the posthook logs.

    Parameters
    ----------
    trace:
        Active trace.
    grad_fn_object_id:
        Hooked grad_fn object id.
    call_index:
        One-based callback index.
    records:
        Fire records emitted by the prehook.

    Returns
    -------
    None
        Mutates a private trace-local queue.
    """

    pending = trace.__dict__.setdefault("_tl_pending_accumulate_grad_fire_records", {})
    key = _pending_accumulate_grad_record_key(grad_fn_object_id, call_index)
    pending[key] = list(records)


def _pop_pending_accumulate_grad_records(
    trace: Any,
    grad_fn_object_id: int,
    call_index: int,
) -> tuple[Any, ...]:
    """Pop AccumulateGrad prehook fire records for the matching posthook.

    Parameters
    ----------
    trace:
        Active trace.
    grad_fn_object_id:
        Hooked grad_fn object id.
    call_index:
        One-based callback index.

    Returns
    -------
    tuple[Any, ...]
        Pending records for this callback, if any.
    """

    pending = trace.__dict__.get("_tl_pending_accumulate_grad_fire_records")
    if not pending:
        return ()
    key = _pending_accumulate_grad_record_key(grad_fn_object_id, call_index)
    records = tuple(pending.pop(key, ()))
    if not pending:
        trace.__dict__.pop("_tl_pending_accumulate_grad_fire_records", None)
    return records


def _clear_pending_accumulate_grad_records(trace: Any) -> None:
    """Drop unpaired AccumulateGrad prehook records at backward pass teardown.

    Parameters
    ----------
    trace:
        Active trace whose pending prehook records should be cleared.

    Returns
    -------
    None
        Removes the private trace-local pending queue if present.
    """

    trace.__dict__.pop("_tl_pending_accumulate_grad_fire_records", None)


def _record_higher_order_terminals_from_tuple(
    trace: Any,
    grad_values: tuple[Any, ...],
    *,
    creator_object_id: int,
    pass_index: int,
) -> None:
    """Register higher-order terminals found in a gradient tuple.

    Parameters
    ----------
    trace:
        Active trace.
    grad_values:
        Gradient tuple to inspect after live intervention mutation.
    creator_object_id:
        Backward grad_fn id that produced the tuple.
    pass_index:
        Active backward pass index.

    Returns
    -------
    None
        Mutates trace higher-order terminal state.
    """

    for grad_value in grad_values:
        if isinstance(grad_value, torch.Tensor) and grad_value.grad_fn is not None:
            _record_higher_order_terminal(
                trace,
                grad_value.grad_fn,
                creator_object_id=creator_object_id,
                pass_index=pass_index,
            )


def _memory_snapshot(device: torch.device) -> tuple[str, int]:
    """Return backend name and current allocated memory for a device.

    Parameters
    ----------
    device:
        Device associated with the backward loss tensor.

    Returns
    -------
    tuple[str, int]
        Backend label and memory snapshot in bytes.
    """
    if device.type == "cuda" and torch.cuda.is_available():
        return "cuda", int(torch.cuda.max_memory_allocated(device))
    if device.type == "mps" and hasattr(torch, "mps"):
        return "mps", int(torch.mps.current_allocated_memory())
    try:
        import psutil
    except ImportError:
        return "cpu", 0
    return "cpu", int(psutil.Process().memory_info().rss)


def _reset_peak_memory(device: torch.device) -> tuple[str, int]:
    """Reset peak tracking when available and return the starting snapshot.

    Parameters
    ----------
    device:
        Device associated with the backward loss tensor.

    Returns
    -------
    tuple[str, int]
        Backend label and starting memory snapshot in bytes.
    """
    if device.type == "cuda" and torch.cuda.is_available():
        torch.cuda.reset_peak_memory_stats(device)
    return _memory_snapshot(device)


def _layer_grad_fn_pairing_rank(layer: Any) -> int:
    """Return the preference rank for a forward op grad-fn pairing candidate.

    Parameters
    ----------
    layer:
        Forward Op/Layer candidate sharing a grad-fn object id.

    Returns
    -------
    int
        Lower rank is preferred; compute ops outrank boundary sentinels.
    """

    is_compute = getattr(layer, "is_compute_op", False) or getattr(
        layer,
        "is_compute_layer",
        False,
    )
    return 0 if is_compute else 1


def _layer_by_grad_fn_id(trace: Any) -> dict[int, str]:
    """Build a mapping from forward grad_fn_handle identity to final layer label.

    Parameters
    ----------
    trace:
        Trace whose layers were captured during the forward pass.

    Returns
    -------
    dict[int, str]
        Mapping from ``id(grad_fn_handle)`` to final layer label.
    """
    mapping: dict[int, str] = {}
    ranks: dict[int, int] = {}
    for layer in trace.layer_list:
        grad_fn_object_id = getattr(layer, "grad_fn_object_id", None)
        if grad_fn_object_id is None:
            continue
        candidate_rank = _layer_grad_fn_pairing_rank(layer)
        current_rank = ranks.get(grad_fn_object_id)
        if current_rank is not None and current_rank <= candidate_rank:
            continue
        mapping[grad_fn_object_id] = layer.layer_label
        ranks[grad_fn_object_id] = candidate_rank
    return mapping


def _walk_and_hook_backward_graph(trace: Any, loss: torch.Tensor) -> list[Any]:
    """Walk ``loss.grad_fn`` and register hooks on every reachable grad_fn_handle.

    Parameters
    ----------
    trace:
        Trace that owns the flat backward fields.
    loss:
        Scalar or tensor loss whose backward graph should be captured.

    Returns
    -------
    list[Any]
        Hook handles to remove after backward finishes.
    """
    if loss.grad_fn is None:
        raise ValueError("log_backward requires a loss tensor with a grad_fn_handle.")

    layer_lookup = _layer_by_grad_fn_id(trace)
    queue: deque[Any] = deque([loss.grad_fn])
    seen: set[int] = set()
    handles: list[Any] = []
    type_counter: dict[str, int] = {}
    # Keep strong refs to every discovered grad_fn_handle for the trace's lifetime so
    # Python cannot recycle their memory addresses. ``id()`` is used as the
    # primary key for ``grad_fn_logs`` and ``next_grad_fn_ids``; if leaf nodes
    # like AccumulateGrad were gc'd, their ids could be reused by later-created
    # grad_fns (e.g. the output clone wrapper), creating phantom cycles.
    strong_refs = trace.__dict__.setdefault("_backward_gradfn_refs", [])
    strong_refs.append(loss.grad_fn)
    root_grad_fn_id = id(loss.grad_fn)
    if root_grad_fn_id not in trace.backward_root_grad_fn_object_ids:
        trace.backward_root_grad_fn_object_ids.append(root_grad_fn_id)
    pass_index = int(
        getattr(trace, "_active_backward_pass_index", getattr(trace, "num_backward_passes", 0) + 1)
    )
    roots_by_pass = trace.__dict__.setdefault("_backward_roots_by_pass", {})
    roots_by_pass.setdefault(pass_index, [])
    if root_grad_fn_id not in roots_by_pass[pass_index]:
        roots_by_pass[pass_index].append(root_grad_fn_id)
    trace.has_backward_pass = True

    while queue:
        grad_fn_handle = queue.popleft()
        grad_fn_object_id = id(grad_fn_handle)
        if grad_fn_object_id in seen:
            continue
        seen.add(grad_fn_object_id)
        next_grad_fns = list(_iter_next_grad_fns(grad_fn_handle))
        strong_refs.extend(next_grad_fns)
        queue.extend(next_grad_fns)
        layer_label = layer_lookup.get(grad_fn_object_id)
        grad_fn_record = trace.grad_fn_logs.get(grad_fn_object_id)
        if grad_fn_record is None:
            grad_fn_type = _normalize_grad_fn_type(grad_fn_handle)
            step_index = len(trace.grad_fn_order) + 1
            type_index, step_index, label = _grad_fn_label_parts(
                trace,
                grad_fn_type,
                layer_label,
                type_counter,
                step_index,
            )
            grad_fn_cls = type(grad_fn_handle)
            grad_fn_record = GradFn(
                grad_fn_object_id=grad_fn_object_id,
                class_name=grad_fn_cls.__name__,
                class_qualname=f"{grad_fn_cls.__module__}.{grad_fn_cls.__qualname__}",
                label=label,
                type=grad_fn_type,
                type_index=type_index,
                ordinal_index=len(trace.grad_fn_order),
                step_index=step_index,
                is_custom=_grad_fn_is_custom(grad_fn_handle),
                has_op=layer_label is not None,
                op_label=layer_label,
                next_grad_fn_ids=[id(next_fn) for next_fn in next_grad_fns],
                **_grad_fn_source_metadata(grad_fn_cls),
            )
            grad_fn_record.source_trace = trace
            trace.grad_fn_logs[grad_fn_object_id] = grad_fn_record
            trace.grad_fn_order.append(grad_fn_object_id)
        else:
            grad_fn_record.next_grad_fn_ids = [id(next_fn) for next_fn in next_grad_fns]
            grad_fn_record.source_trace = trace
        is_accumulate_grad = _is_accumulate_grad(grad_fn_handle)
        if is_accumulate_grad:
            param = getattr(grad_fn_handle, "variable", None)
            param_address = trace._param_log_by_pid.get(id(param)) if param is not None else None
            if param_address is not None:
                trace._grad_fn_param_refs[grad_fn_record.label] = param_address
                trace.__dict__.setdefault("_grad_fn_param_refs_by_object_id", {})[
                    grad_fn_object_id
                ] = param_address
        source_fields = {
            key: getattr(grad_fn_record, key)
            for key in (
                "class_source_file",
                "class_source_line",
                "init_source_file",
                "init_source_line",
                "forward_source_file",
                "forward_source_line",
                "backward_source_file",
                "backward_source_line",
            )
        }
        _ensure_backward_event_stream(trace).append_backward(
            GradFnDiscovered(
                object_id=grad_fn_object_id,
                class_name=grad_fn_record.class_name,
                class_qualname=grad_fn_record.class_qualname,
                is_custom=grad_fn_record.is_custom,
                op_label=layer_label,
                param_ref=trace._grad_fn_param_refs.get(grad_fn_record.label),
                created_in_pass=None,
                creator_object_id=None,
                source=source_fields,
                topology=tuple(id(next_fn) for next_fn in next_grad_fns),
            )
        )
        if layer_label is not None:
            layer = trace.layer_dict_all_keys[layer_label]
            layer.grad_fn = grad_fn_record
            parent_layer = trace.layer_logs.get(layer.layer_label)
            if parent_layer is not None:
                parent_layer.grad_fn = grad_fn_record
        try:
            handles.append(
                grad_fn_handle.register_hook(
                    _make_grad_fn_hook(
                        trace,
                        grad_fn_object_id,
                        is_accumulate_grad=is_accumulate_grad,
                    )
                )
            )
            if is_accumulate_grad:
                handles.append(
                    grad_fn_handle.register_prehook(_make_grad_fn_prehook(trace, grad_fn_object_id))
                )
        except RuntimeError:
            continue
    _sync_grad_fn_graph_relations(trace)
    return handles


def _record_higher_order_terminal(
    trace: Any,
    grad_fn_handle: Any,
    *,
    creator_object_id: int,
    pass_index: int,
) -> None:
    """Queue a terminal grad-fn created by a differentiable backward op."""

    _strong_grad_fn_refs(trace).append(grad_fn_handle)
    terminals = trace.__dict__.setdefault("_higher_order_grad_fn_terminals", [])
    terminals.append((grad_fn_handle, creator_object_id, pass_index))


def _emit_discovered_grad_fn(
    trace: Any,
    grad_fn_handle: Any,
    *,
    created_in_pass: int | None,
    creator_object_id: int | None,
) -> None:
    """Append a discovery event and runtime record for one grad-fn object."""

    grad_fn_object_id = id(grad_fn_handle)
    next_grad_fns = list(_iter_next_grad_fns(grad_fn_handle))
    _strong_grad_fn_refs(trace).extend(next_grad_fns)
    grad_fn_record = trace.grad_fn_logs.get(grad_fn_object_id)
    if grad_fn_record is None:
        grad_fn_type = _normalize_grad_fn_type(grad_fn_handle)
        type_counter = trace.__dict__.setdefault("_backward_grad_fn_type_counter", {})
        step_index = len(trace.grad_fn_order) + 1
        type_index, step_index, label = _grad_fn_label_parts(
            trace,
            grad_fn_type,
            None,
            type_counter,
            step_index,
        )
        grad_fn_cls = type(grad_fn_handle)
        grad_fn_record = GradFn(
            grad_fn_object_id=grad_fn_object_id,
            class_name=grad_fn_cls.__name__,
            class_qualname=f"{grad_fn_cls.__module__}.{grad_fn_cls.__qualname__}",
            label=label,
            type=grad_fn_type,
            type_index=type_index,
            ordinal_index=len(trace.grad_fn_order),
            step_index=step_index,
            is_custom=_grad_fn_is_custom(grad_fn_handle),
            has_op=False,
            op_label=None,
            order=_resolved_order_for_creator(creator_object_id, trace.grad_fn_logs),
            origin_backward_pass=created_in_pass,
            creator_object_id=creator_object_id,
            next_grad_fn_ids=[id(next_fn) for next_fn in next_grad_fns],
            **_grad_fn_source_metadata(grad_fn_cls),
        )
        grad_fn_record.source_trace = trace
        trace.grad_fn_logs[grad_fn_object_id] = grad_fn_record
        trace.grad_fn_order.append(grad_fn_object_id)
    else:
        grad_fn_record.next_grad_fn_ids = [id(next_fn) for next_fn in next_grad_fns]
        grad_fn_record.source_trace = trace

    source_fields = {
        key: getattr(grad_fn_record, key)
        for key in (
            "class_source_file",
            "class_source_line",
            "init_source_file",
            "init_source_line",
            "forward_source_file",
            "forward_source_line",
            "backward_source_file",
            "backward_source_line",
        )
    }
    _ensure_backward_event_stream(trace).append_backward(
        GradFnDiscovered(
            object_id=grad_fn_object_id,
            class_name=grad_fn_record.class_name,
            class_qualname=grad_fn_record.class_qualname,
            is_custom=grad_fn_record.is_custom,
            op_label=None,
            param_ref=None,
            created_in_pass=created_in_pass,
            creator_object_id=creator_object_id,
            source=source_fields,
            topology=tuple(id(next_fn) for next_fn in next_grad_fns),
        )
    )


def _rewalk_higher_order_grad_fns(trace: Any) -> None:
    """Discover grad-fn nodes created by a differentiable backward pass."""

    terminals = list(trace.__dict__.pop("_higher_order_grad_fn_terminals", ()))
    if not terminals:
        return
    existing_ids = set(trace.grad_fn_logs)

    discovered_ids: set[int] = set()
    for terminal, creator_object_id, pass_index in terminals:
        queue: deque[Any] = deque([terminal])
        while queue:
            grad_fn_handle = queue.popleft()
            grad_fn_object_id = id(grad_fn_handle)
            if grad_fn_object_id in existing_ids or grad_fn_object_id in discovered_ids:
                continue
            discovered_ids.add(grad_fn_object_id)
            _emit_discovered_grad_fn(
                trace,
                grad_fn_handle,
                created_in_pass=pass_index,
                creator_object_id=creator_object_id,
            )
            queue.extend(_iter_next_grad_fns(grad_fn_handle))
    _sync_grad_fn_graph_relations(trace)


def _is_static_truthy_keep_grad(value: Any) -> bool:
    """Return whether a gradient capture decision is statically keep-grad true."""

    from ...fastlog.types import CaptureSpec

    return value is True or (isinstance(value, CaptureSpec) and value.keep_grad)


def _selected_fastlog_forward_labels(recording: Any) -> set[str]:
    """Return labels for predicate-selected forward records."""

    from ...capture.predicates import _evaluate_keep_op
    from ...ir.predicate import RetroactiveCaptureDecision

    recording._ensure_records()  # noqa: SLF001
    labels: set[str] = set()
    for record in recording.records:
        labels.add(record.ctx.label)
        if (
            record.ctx.kind == "op"
            and record.ctx.layer_type is not None
            and record.ctx.type_index is not None
        ):
            labels.add(f"{record.ctx.layer_type}_{record.ctx.type_index}")
        if record.ctx.raw_label is not None:
            labels.add(record.ctx.raw_label)
    recording_state = getattr(recording, "_recording_state", None)
    if recording_state is None:
        return labels
    for ctx in recording_state.all_contexts:
        spec = _evaluate_keep_op(ctx, recording_state.options)
        if isinstance(spec, RetroactiveCaptureDecision):
            continue
        if not spec.save_out and not spec.save_metadata:
            continue
        labels.add(ctx.label)
        if ctx.kind == "op" and ctx.layer_type is not None and ctx.type_index is not None:
            labels.add(f"{ctx.layer_type}_{ctx.type_index}")
        if ctx.raw_label is not None:
            labels.add(ctx.raw_label)
    return labels


def _first_tensor_from_hook_args(
    hook_args: tuple[Any, ...],
) -> tuple[str, int | None, torch.Tensor] | None:
    """Pick the first tensor gradient from grad output or input hook arguments."""

    grad_outputs = hook_args[1] if len(hook_args) >= 2 else ()
    if grad_outputs is not None:
        for index, grad in enumerate(grad_outputs):
            if isinstance(grad, torch.Tensor):
                return "grad_output", index, grad
    grad_inputs = hook_args[0] if len(hook_args) >= 1 else ()
    if grad_inputs is not None:
        for index, grad in enumerate(grad_inputs):
            if isinstance(grad, torch.Tensor):
                return "grad_input", index, grad
    return None


def log_recording_backward(
    recording: Any,
    loss: torch.Tensor,
    *,
    save_grads: Any = None,
    default_grad: Any = None,
    retain_graph: bool | None = None,
    create_graph: bool = False,
) -> Any:
    """Run backward while capturing gradients for a fastlog ``Recording``."""

    from ...fastlog.exceptions import InvalidStorageError, RecorderStateError
    from ...capture.projections import sync_recording_grad_records_from_sidecar

    recording_state = getattr(recording, "_recording_state", None)
    if recording_state is None:
        raise RecorderStateError("Recording.log_backward() requires a live recording state")
    trace = getattr(recording_state, "runtime_trace", None)
    if trace is None:
        raise RecorderStateError(
            "Recording.log_backward() requires a live runtime trace from Recorder.log()."
        )
    effective_save_grads = (
        save_grads if save_grads is not None else recording_state.options.save_grads
    )
    effective_default_grad = (
        default_grad if default_grad is not None else recording_state.options.default_grad
    )
    if (
        recording_state.storage_intent.on_disk
        and not recording_state.storage_intent.in_ram
        and _is_static_truthy_keep_grad(effective_save_grads)
    ):
        raise InvalidStorageError(
            "save_grads=True with CaptureSpec(keep_grad=True) is incompatible with "
            "disk-only fastlog gradient storage"
        )
    selected_forward_labels = _selected_fastlog_forward_labels(recording)

    def selected_save_grads(ctx: Any) -> Any:
        """Apply fastlog default and selected-forward-label semantics."""

        layer_label = getattr(ctx, "layer_label", None)
        if callable(effective_save_grads):
            decision = effective_save_grads(ctx)
            if (
                recording_state.storage_intent.on_disk
                and not recording_state.storage_intent.in_ram
                and _is_static_truthy_keep_grad(decision)
            ):
                raise InvalidStorageError(
                    "save_grads returned CaptureSpec(keep_grad=True), which is incompatible "
                    "with disk-only fastlog gradient storage"
                )
            return decision
        if effective_save_grads is True and layer_label not in selected_forward_labels:
            return False
        if effective_save_grads is None:
            return effective_default_grad
        return effective_save_grads

    backward_kwargs: dict[str, Any] = {"create_graph": create_graph}
    if retain_graph is not None:
        backward_kwargs["retain_graph"] = retain_graph

    def run() -> Any:
        """Run the requested recording backward call."""

        return loss.backward(**backward_kwargs)

    recording_state.active_save_grads_record_policy = selected_save_grads
    try:
        _run_backward_with_capture(
            trace,
            loss,
            run,
            trigger="recording_backward",
            engine_flags=backward_kwargs,
            save_grads=selected_save_grads,
        )
        sync_recording_grad_records_from_sidecar(recording_state)
    finally:
        recording_state.active_save_grads_record_policy = None
    return recording


def _is_accumulate_grad(grad_fn_handle: Any) -> bool:
    """Return whether an autograd node is an AccumulateGrad leaf.

    Parameters
    ----------
    grad_fn_handle
        Autograd node to inspect.

    Returns
    -------
    bool
        True when ``grad_fn_handle`` is an AccumulateGrad node.
    """

    accumulate_grad_cls = get_accumulate_grad_class()
    return type(grad_fn_handle).__name__ == "AccumulateGrad" or isinstance(
        grad_fn_handle, accumulate_grad_cls
    )


def _clear_forward_grad_fn_refs(trace: Any) -> None:
    """Clear strong forward references to autograd nodes after hook registration.

    Parameters
    ----------
    trace:
        Trace whose Op and Layer grad_fn_handle object refs should be
        released.
    """
    for layer in trace.layer_list:
        layer.grad_fn_handle = None
    for layer_log in trace.layer_logs.values():
        layer_log.grad_fn_handle = None


def _run_backward_with_capture(
    trace: Any,
    loss: torch.Tensor,
    backward_callable: Callable[[], Any],
    *,
    trigger: str = "backward",
    outer_context: str | None = None,
    engine_flags: dict[str, object] | None = None,
    save_grads: Any | MissingType = MISSING,
    forward_op_count_at_trigger: int | None = None,
    backward_call_context: FuncCallLocation | None = None,
) -> Any:
    """Capture a backward graph, run backward, and record memory delta.

    Parameters
    ----------
    trace:
        Trace to mutate.
    loss:
        Loss tensor that roots the backward graph.
    backward_callable:
        Zero-argument callable that performs the actual backward pass.

    Returns
    -------
    Any
        Return value from ``backward_callable``.
    """
    from ...intervention.hooks import normalize_hooks_from_spec

    _ensure_not_inference_only_backward(trace)
    _ensure_not_chunked_forward_backward(trace)
    previous_trace = _state._active_trace
    previous_plan = _state._active_hook_plan
    previous_spec = _state._active_intervention_spec
    if getattr(trace, "_tl_active_backward_bracket", False):
        return backward_callable()
    _close_implicit_backward_pass_if_open(trace)
    previous_save_grads_policy = getattr(trace, "_active_save_grads_policy", None)
    previous_had_save_grads_policy = "_active_save_grads_policy" in trace.__dict__
    active_save_grads_policy = (
        getattr(trace, "save_grads", None) if save_grads is MISSING else save_grads
    )
    trace._active_save_grads_policy = active_save_grads_policy
    _state._active_trace = trace
    _state._active_intervention_spec = getattr(trace, "_intervention_spec", None)
    _state._active_hook_plan = [
        *normalize_hooks_from_spec(_state._active_intervention_spec),
    ]
    pass_index = int(getattr(trace, "num_backward_passes", 0)) + 1
    events = _ensure_backward_event_stream(trace)
    trace._active_backward_pass_index = pass_index
    trace._implicit_backward_pass_open = False
    events.append_backward(
        BackwardPassStart(
            pass_index=pass_index,
            trigger=cast(Any, trigger),
            implicit=False,
            outer_context=outer_context,
            call_context_ref=backward_call_context,
            root_meta=(
                {
                    "shape": tuple(loss.shape),
                    "dtype": str(loss.dtype),
                    "device": str(loss.device),
                },
            ),
            root_grad_arguments=None,
            inputs_subset=(),
            order=None,
            origin_backward_pass=None,
            save_grads_policy_repr=repr(active_save_grads_policy),
            engine_flags=engine_flags,
            forward_op_count_at_trigger=(
                forward_op_count_at_trigger
                if forward_op_count_at_trigger is not None
                else _forward_op_count_at_backward_trigger(trace)
            ),
            timestamp=time.time(),
        )
    )
    handles = _walk_and_hook_backward_graph(trace, loss)
    backend, before = _reset_peak_memory(loss.device)
    backward_start_time = time.time()
    status = "ok"
    result = None
    trace._tl_active_backward_bracket = True
    try:
        result = backward_callable()
    except Exception:
        status = "error"
        raise
    finally:
        for handle in handles:
            with contextlib.suppress(Exception):
                handle.remove()
        _clear_forward_grad_fn_refs(trace)
        _state._active_trace = previous_trace
        _state._active_hook_plan = previous_plan
        _state._active_intervention_spec = previous_spec
        trace.__dict__.pop("_tl_active_backward_bracket", None)
        _backend, after = _memory_snapshot(loss.device)
        peak_delta = max(0, after - before)
        duration = time.time() - backward_start_time
        trace.backward_memory_backend = backend
        trace.backward_peak_memory += Bytes(peak_delta)
        trace.backward_durations.append(Duration(duration))
        trace.total_param_gradient_memory = Bytes(
            sum(int(param_log.gradient_memory) for param_log in getattr(trace, "param_logs", []))
        )
        trace.num_backward_passes = max(int(getattr(trace, "num_backward_passes", 0)), pass_index)
        _rewalk_higher_order_grad_fns(trace)
        events.append_backward(
            BackwardPassEnd(
                pass_index=pass_index,
                duration=duration,
                peak_memory=peak_delta,
                status=cast(Any, status),
                order_attribution_coverage=None,
            )
        )
        trace.__dict__.pop("_active_backward_pass_index", None)
        _clear_pending_accumulate_grad_records(trace)
        if previous_had_save_grads_policy:
            trace._active_save_grads_policy = previous_save_grads_policy
        else:
            trace.__dict__.pop("_active_save_grads_policy", None)
        _materialize_backward_projections(trace)
    return result


def disarm_triggers(trace: Any) -> None:
    """Detach a trace from global autograd trigger interception.

    Parameters
    ----------
    trace:
        Trace whose future tensor-hook and autograd-wrapper capture should be
        disabled.

    Returns
    -------
    None
        Registry state is updated in place.
    """

    trace._tl_backward_triggers_disarmed = True
    _purge_trace_from_backward_registry(trace)


def _capture_autograd_engine_call(
    roots: Any,
    engine_callable: Callable[[], Any],
    *,
    trigger: Literal["autograd_backward", "autograd_grad"],
    engine_flags: dict[str, object] | None,
    forward_op_count_at_trigger: int | None = None,
) -> Any:
    """Run a global autograd entry through TorchLens capture when roots match.

    Parameters
    ----------
    roots:
        Tensor roots passed to the autograd engine.
    engine_callable:
        Zero-argument callable invoking the original PyTorch autograd function.
    trigger:
        Trigger label to store on ``BackwardPassStart``.
    engine_flags:
        Best-effort keyword metadata from the engine invocation.

    Returns
    -------
    Any
        Return value from ``engine_callable``.
    """

    matched_traces = tuple(
        trace
        for trace in _traces_for_roots(roots)
        if not getattr(trace, "_tl_active_backward_bracket", False)
    )
    loss = _first_root_tensor(roots)
    if loss is None or not matched_traces:
        return engine_callable()
    if len(matched_traces) == 1:
        matched_trace = matched_traces[0]
        root_forward_op_count = _root_forward_op_count(matched_trace, roots)
        return _run_backward_with_capture(
            matched_trace,
            loss,
            engine_callable,
            trigger=trigger,
            engine_flags=engine_flags,
            forward_op_count_at_trigger=(
                root_forward_op_count
                if root_forward_op_count is not None
                else forward_op_count_at_trigger
            ),
        )

    # P1 supports multi-trace bracket opening by nesting setup and running the
    # engine once through the innermost capture. Later projection phases will
    # refine per-trace outer_context metadata.
    def nested_call(index: int) -> Any:
        """Run nested capture setup for all matched traces."""

        if index == len(matched_traces):
            return engine_callable()
        matched_trace = matched_traces[index]
        root_forward_op_count = _root_forward_op_count(matched_trace, roots)
        return _run_backward_with_capture(
            matched_trace,
            loss,
            lambda: nested_call(index + 1),
            trigger=trigger,
            outer_context=None if index == 0 else f"{trigger}:multi_trace",
            engine_flags=engine_flags,
            forward_op_count_at_trigger=(
                root_forward_op_count
                if root_forward_op_count is not None
                else forward_op_count_at_trigger
            ),
        )

    return nested_call(0)


def install_autograd_wrappers() -> None:
    """Install global autograd trigger wrappers idempotently.

    Returns
    -------
    None
        ``torch.autograd.backward`` and ``torch.autograd.grad`` are patched once.
    """

    global _AUTOGRAD_WRAPPERS_INSTALLED, _ORIGINAL_AUTOGRAD_BACKWARD, _ORIGINAL_AUTOGRAD_GRAD
    if _AUTOGRAD_WRAPPERS_INSTALLED:
        return
    _ORIGINAL_AUTOGRAD_BACKWARD = torch.autograd.backward
    _ORIGINAL_AUTOGRAD_GRAD = torch.autograd.grad

    def wrapped_backward(*args: Any, **kwargs: Any) -> Any:
        """Route ``torch.autograd.backward`` through TorchLens when roots match."""

        original = cast(Callable[..., Any], _ORIGINAL_AUTOGRAD_BACKWARD)
        forward_op_count_at_trigger = _active_forward_op_count_at_trigger()
        roots = _autograd_roots_from_call(args, kwargs, "tensors")

        def run() -> Any:
            """Invoke the original autograd backward function."""
            if _state._escape_detector_mode == "shadow":
                with expected_original_call(original, "autograd:backward"):
                    return original(*args, **kwargs)
            return original(*args, **kwargs)

        return _capture_autograd_engine_call(
            roots,
            run,
            trigger="autograd_backward",
            engine_flags=dict(kwargs),
            forward_op_count_at_trigger=forward_op_count_at_trigger,
        )

    def wrapped_grad(*args: Any, **kwargs: Any) -> Any:
        """Route ``torch.autograd.grad`` through TorchLens when roots match."""

        original = cast(Callable[..., Any], _ORIGINAL_AUTOGRAD_GRAD)
        forward_op_count_at_trigger = _active_forward_op_count_at_trigger()
        roots = _autograd_roots_from_call(args, kwargs, "outputs")

        def run() -> Any:
            """Invoke the original autograd grad function."""
            if _state._escape_detector_mode == "shadow":
                with expected_original_call(original, "autograd:grad"):
                    return original(*args, **kwargs)
            return original(*args, **kwargs)

        return _capture_autograd_engine_call(
            roots,
            run,
            trigger="autograd_grad",
            engine_flags=dict(kwargs),
            forward_op_count_at_trigger=forward_op_count_at_trigger,
        )

    torch.autograd.backward = wrapped_backward
    torch.autograd.grad = wrapped_grad
    _AUTOGRAD_WRAPPERS_INSTALLED = True


def uninstall_autograd_wrappers() -> None:
    """Restore original global autograd entry points when installed.

    Returns
    -------
    None
        PyTorch autograd functions are restored in place.
    """

    global _AUTOGRAD_WRAPPERS_INSTALLED
    if not _AUTOGRAD_WRAPPERS_INSTALLED:
        return
    if _ORIGINAL_AUTOGRAD_BACKWARD is not None:
        torch.autograd.backward = _ORIGINAL_AUTOGRAD_BACKWARD
    if _ORIGINAL_AUTOGRAD_GRAD is not None:
        torch.autograd.grad = _ORIGINAL_AUTOGRAD_GRAD
    _AUTOGRAD_WRAPPERS_INSTALLED = False


def _ensure_layer_grad_hooks(trace: Any) -> None:
    """Enable gradient retention when saved-out hook installation was deferred.

    Parameters
    ----------
    trace:
        Trace whose saved outs should receive grad hooks.
    """
    if getattr(trace, "_grad_op_nums_to_save", None) in [None, [], "none"]:
        trace._grad_op_nums_to_save = "all"


def _finalize_grad_streaming(trace: Any) -> None:
    """Finalize a deferred grad-streaming bundle after backward capture."""

    writer = getattr(trace, "_out_writer", None)
    if writer is None or not getattr(trace, "_defer_streaming_bundle_finalization", False):
        return

    from ...postprocess.finalization import (
        _evict_streamed_outs,
        _evict_streamed_grads,
        _finalize_streamed_bundle,
    )

    _finalize_streamed_bundle(trace)
    if not getattr(trace, "_keep_outs_in_memory", True):
        _evict_streamed_outs(trace)
    if not getattr(trace, "_grad_stream_retain_in_memory", True):
        _evict_streamed_grads(trace)
    for field_name in (
        "_out_writer",
        "_out_sink",
        "_keep_outs_in_memory",
        "_grad_stream_retain_in_memory",
        "_defer_streaming_bundle_finalization",
    ):
        trace.__dict__.pop(field_name, None)


def log_backward(
    self: Any,
    loss: torch.Tensor,
    *,
    save_grads: Any | MissingType = MISSING,
    **backward_kwargs: Any,
) -> Any:
    """Run ``loss.backward`` while capturing the backward graph.

    Parameters
    ----------
    loss:
        Loss tensor whose ``grad_fn_handle`` roots the backward graph.
    save_grads:
        Optional per-call gradient retention override. ``True`` captures all
        observed op gradients, ``False``/``None`` disables retention for this
        call, and selectors/callables are evaluated at hook fire time.
    **backward_kwargs:
        Keyword arguments forwarded to ``torch.Tensor.backward``.

    Returns
    -------
    Any
        The same Trace, for chaining.
    """
    _ensure_not_inference_only_backward(self)
    _ensure_not_chunked_forward_backward(self)
    backward_call_context = _capture_backward_call_context(self)
    _ensure_layer_grad_hooks(self)

    def run() -> Any:
        """Run the user's requested backward call."""
        return loss.backward(**backward_kwargs)  # type: ignore[no-untyped-call]

    _run_backward_with_capture(
        self,
        loss,
        run,
        trigger="backward",
        engine_flags=dict(backward_kwargs),
        save_grads=save_grads,
        backward_call_context=backward_call_context,
    )
    _finalize_grad_streaming(self)
    return self


class RecordingBackward:
    """Context manager that captures every ``Tensor.backward`` call inside it."""

    def __init__(
        self,
        trace: Any,
        *,
        save_grads: Any | MissingType = MISSING,
    ) -> None:
        """Store context state for temporary ``Tensor.backward`` patching."""
        self.trace = trace
        self.save_grads = save_grads
        self._original_backward: Callable[..., Any] | None = None

    def __enter__(self) -> "RecordingBackward":
        """Patch ``torch.Tensor.backward`` and return this context object."""
        _ensure_layer_grad_hooks(self.trace)
        self._original_backward = torch.Tensor.backward
        trace = self.trace
        original_backward = self._original_backward

        def wrapped_backward(tensor_self: torch.Tensor, *args: Any, **kwargs: Any) -> Any:
            """Capture the graph rooted at ``tensor_self`` before backward runs."""

            def run() -> Any:
                """Run the original Tensor.backward implementation."""
                if _state._escape_detector_mode == "shadow":
                    with expected_original_call(original_backward, "autograd:tensor_backward"):
                        return original_backward(tensor_self, *args, **kwargs)  # type: ignore[no-untyped-call]
                return original_backward(tensor_self, *args, **kwargs)  # type: ignore[no-untyped-call]

            return _run_backward_with_capture(
                trace,
                tensor_self,
                run,
                trigger="recording_backward",
                engine_flags=dict(kwargs),
                save_grads=self.save_grads,
            )

        torch.Tensor.backward = wrapped_backward  # type: ignore[assignment, method-assign]
        return self

    def __exit__(self, exc_type: Any, exc: Any, traceback: Any) -> None:
        """Restore ``torch.Tensor.backward``."""
        if self._original_backward is not None:
            torch.Tensor.backward = self._original_backward  # type: ignore[method-assign]
        if exc_type is None:
            _finalize_grad_streaming(self.trace)


def recording_backward(
    self: Any,
    *,
    save_grads: Any | MissingType = MISSING,
) -> RecordingBackward:
    """Return a context manager that records user-managed backward calls.

    Returns
    -------
    RecordingBackward
        Context manager that patches ``Tensor.backward`` inside the block.
    """
    return RecordingBackward(
        self,
        save_grads=save_grads,
    )
