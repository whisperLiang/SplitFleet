"""Global state for torchlens toggle-gated decoration.

This module is the single source of truth for all mutable state that controls
whether decorated torch wrappers log or pass through.  It also stores
pre-computed lookup tables populated by ``decorate_all_once``.

WARNING — No torchlens imports at module level:
    Every other torchlens module imports from here.  If this module imported
    back, Python's import machinery would hit a circular dependency before any
    code ran.  Type-hint-only imports are safe inside ``TYPE_CHECKING`` guards
    because they are never evaluated at runtime.

Design rationale:
    The "toggle architecture" means every torch function is wrapped once (on first
    use of ``trace`` or related API) and stays wrapped afterward.
    Wrappers check ``_logging_enabled`` (a single bool) on every call — when
    False, the wrapper is a one-branch-check no-op.  This avoids the cost of
    re-wrapping / un-wrapping on every ``trace`` call.  All shared
    state lives here so wrappers never need to import heavy torchlens modules
    just to check the toggle.
"""

import weakref
from collections.abc import Callable
from contextlib import contextmanager
from typing import TYPE_CHECKING, Any, Iterator

# TYPE_CHECKING is False at runtime, so this import only exists for static
# analysis / IDE support — it will never trigger the circular-import problem.
if TYPE_CHECKING:
    from .data_classes.trace import Trace
    from .intervention.types import InterventionSpec

# ---------------------------------------------------------------------------
# Toggle — the single bool that gates every decorated wrapper
# ---------------------------------------------------------------------------

_logging_enabled: bool = False
"""Master switch checked by every decorated torch-function wrapper.

When False (the default / steady state), wrappers execute the original function
directly with negligible overhead (one ``if`` check).  Set to True only for the
duration of a forward pass inside ``active_logging()``.
"""

# ---------------------------------------------------------------------------
# Session state — reset every forward pass
# ---------------------------------------------------------------------------

_active_trace: "Trace | None" = None
"""The Trace accumulating data for the current forward pass.

Set at the start of ``active_logging()`` and cleared on exit.  Wrappers read
this to know *where* to record tensor operations.  Always None outside a
logging session.
"""

_active_hook_plan: Any | None = None
"""Hook plan for the active intervention-ready capture.

Phase 4a only stores this slot. Hook normalization/execution is intentionally
deferred to Phase 4c, so the runtime value remains protocol-friendly and avoids
importing ``torchlens.intervention`` at module load.
"""

_active_intervention_spec: "InterventionSpec | None" = None
"""Intervention spec associated with the active capture, if any.

This module uses a string annotation plus a ``TYPE_CHECKING`` import so
``torchlens._state`` never imports the intervention package at runtime.
"""

_func_call_id_counter: int = 0
"""Session-scoped monotonic function-call id counter."""

_capture_replay_templates: bool = False
"""Whether the active capture should collect replay-template data.

Phase 4a only plumbs the flag. Phase 4b builds the actual templates.
"""

_relationship_model_id: int | None = None
"""Relationship evidence seed: ``id(model)`` at capture start."""

_relationship_model_class: str | None = None
"""Relationship evidence seed: model class qualname at capture start."""

_relationship_weight_fingerprint: str | None = None
"""Relationship evidence seed: deterministic parameter-structure fingerprint."""

_relationship_input_id: int | None = None
"""Relationship evidence seed: ``id(input_args)`` or first input tensor id."""

_relationship_input_shape_hash: str | None = None
"""Relationship evidence seed: deterministic input shape/dtype/device hash."""

_hook_reentrancy_depth: int = 0
"""Primitive hook execution depth mirrored by ``intervention.runtime``.

``_state`` owns this primitive instead of importing the runtime guard object,
which keeps this module free of runtime intervention imports.
"""

_log_registry: "weakref.WeakSet[Trace]" = weakref.WeakSet()
"""Process-wide weak registry of currently live ``Trace`` objects."""

_active_record_spans: list[dict[str, Any]] = []
"""Observer spans currently active around or inside a logging session."""

_naming_counters: dict[str, int] = {}
"""Process-global counters used by unnamed ``trace`` captures.

The counter is intentionally not thread-safe. Public capture is serialized by
``active_logging()``'s re-entrancy guard, which is the same concurrency boundary
used by the rest of TorchLens logging state.
"""

_HF_CLASS_SUFFIXES: tuple[str, ...] = (
    "ForCausalLM",
    "ForSequenceClassification",
    "ForMaskedLM",
    "ForQuestionAnswering",
    "ForTokenClassification",
    "ForImageClassification",
    "PreTrainedModel",
    "Model",
)
"""Common HuggingFace class suffixes stripped from generated log names."""


def _register_log(log: "Trace") -> None:
    """Register a model log in the process-wide weak registry.

    Parameters
    ----------
    log:
        Model log object to track weakly.

    Returns
    -------
    None
        The weak registry is updated in place.
    """

    _log_registry.add(log)


def list_logs() -> tuple["Trace", ...]:
    """Return a snapshot of currently live ``Trace`` objects.

    Returns
    -------
    tuple[Trace, ...]
        Immutable snapshot of logs still alive in this process.
    """

    snapshot = list(_log_registry)
    return tuple(log for log in snapshot if log is not None and hasattr(log, "layer_list"))


def _strip_hf_suffix(class_name: str) -> str:
    """Strip common HuggingFace suffixes from a model class name.

    Parameters
    ----------
    class_name:
        Model class name.

    Returns
    -------
    str
        Shortened class name when a known suffix matched.
    """

    for suffix in _HF_CLASS_SUFFIXES:
        if class_name.endswith(suffix) and len(class_name) > len(suffix):
            return class_name[: -len(suffix)]
    return class_name


def _auto_name(model: Any) -> str:
    """Return the next automatic name for a model instance.

    Parameters
    ----------
    model:
        PyTorch module-like object whose class name seeds the generated name.

    Returns
    -------
    str
        Lowercase short class name plus a monotonic counter.
    """

    class_name = type(model).__name__
    short = _strip_hf_suffix(class_name).lower()
    n = _naming_counters.get(short, 0) + 1
    _naming_counters[short] = n
    return f"{short}_{n}"


def reset_naming_counter(class_name: str | None = None) -> None:
    """Reset automatic log-name counters.

    Parameters
    ----------
    class_name:
        Lowercase short class name to reset, or ``None`` to reset all counters.

    Returns
    -------
    None
        The naming counter dictionary is mutated in place.
    """

    if class_name is None:
        _naming_counters.clear()
    else:
        _naming_counters.pop(class_name, None)


def reset_capture_runtime_context() -> None:
    """Reset per-capture intervention runtime context fields.

    Returns
    -------
    None
        The module-level runtime context is reset in place.
    """

    global _active_hook_plan, _active_intervention_spec, _func_call_id_counter
    global _capture_replay_templates
    global _relationship_model_id, _relationship_model_class
    global _relationship_weight_fingerprint, _relationship_input_id
    global _relationship_input_shape_hash

    _active_hook_plan = None
    _active_intervention_spec = None
    _func_call_id_counter = 0
    _capture_replay_templates = False
    _relationship_model_id = None
    _relationship_model_class = None
    _relationship_weight_fingerprint = None
    _relationship_input_id = None
    _relationship_input_shape_hash = None


def configure_capture_runtime_context(
    *,
    hook_plan: Any | None = None,
    intervention_spec: "InterventionSpec | None" = None,
    capture_replay_templates: bool = False,
    model_object_id: int | None = None,
    model_class_qualname: str | None = None,
    weight_fingerprint: str | None = None,
    input_object_id: int | None = None,
    input_signature_hash: str | None = None,
) -> None:
    """Set per-capture intervention runtime context fields.

    Parameters
    ----------
    hook_plan:
        Active hook plan placeholder. Execution is deferred to Phase 4c.
    intervention_spec:
        Active intervention spec placeholder. Mutators land in a later phase.
    capture_replay_templates:
        Whether replay-template capture should be enabled for this run.
    model_object_id:
        ``id(model)`` captured at the public API boundary.
    model_class_qualname:
        Model class qualname captured at the public API boundary.
    weight_fingerprint:
        Deterministic model-parameter fingerprint.
    input_object_id:
        Input object identity captured at the public API boundary.
    input_signature_hash:
        Deterministic input shape/dtype/device fingerprint.

    Returns
    -------
    None
        The module-level runtime context is updated in place.
    """

    global _active_hook_plan, _active_intervention_spec, _capture_replay_templates
    global _relationship_model_id, _relationship_model_class
    global _relationship_weight_fingerprint, _relationship_input_id
    global _relationship_input_shape_hash

    _active_hook_plan = hook_plan
    _active_intervention_spec = intervention_spec
    _capture_replay_templates = capture_replay_templates
    _relationship_model_id = model_object_id
    _relationship_model_class = model_class_qualname
    _relationship_weight_fingerprint = weight_fingerprint
    _relationship_input_id = input_object_id
    _relationship_input_shape_hash = input_signature_hash


def next_func_call_id() -> int:
    """Allocate the next session-scoped function-call id.

    Returns
    -------
    int
        Monotonic id for one decorated torch function invocation.
    """

    global _func_call_id_counter

    _func_call_id_counter += 1
    return _func_call_id_counter


# ---------------------------------------------------------------------------
# Decoration state — tracks whether torch functions are currently wrapped
# ---------------------------------------------------------------------------

_is_decorated: bool = False
"""True when torch functions are currently wrapped with torchlens interceptors.

Set to True at the end of ``decorate_all_once()`` / ``wrap_torch()``, and
to False at the end of ``unwrap_torch()``.  Checked by ``_ensure_decorated()``
to decide whether (re-)decoration is needed before a logging session.
"""

_decorated_identity: Callable[..., Any] | None = None
"""Decorated version of the ``identity`` no-op, used at module boundaries.

When ``nn.Identity`` is encountered or a module's output tensor is the same
object as its input, ``_decorated_identity(t)`` forces a new log entry so the
graph correctly shows the module boundary.  Stored here instead of on
``torch.identity`` to avoid monkey-patching an attribute that doesn't exist
in PyTorch's type stubs.
"""

# ---------------------------------------------------------------------------
# Pre-computed lookup tables (populated once by decorate_all_once, immutable after)
# ---------------------------------------------------------------------------
# These dicts are written exactly once during ``decorate_all_once()`` and are
# treated as read-only afterward.  They exist here (not in decoration/) so that
# wrapper code can look up argument names and original functions without
# importing the decoration subpackage.

_arg_names: dict[str, tuple[str, ...]] = {}
"""func_name -> tuple of argument names, pre-computed via ``inspect.signature``
for every torch function at decoration time.  Used by the wrapper to build
keyword-argument metadata for logged operations.
"""

_orig_to_decorated: dict[int, Callable[..., Any]] = {}
"""id(original_func) -> decorated wrapper.  Used by ``patch_detached_references``
to replace bare references (e.g. ``from torch import cos``) in sys.modules with
the decorated version.  Keyed by id() for O(1) lookup.
"""

_decorated_to_orig: dict[int, Callable[..., Any]] = {}
"""id(decorated_func) -> original_func.  The reverse of ``_orig_to_decorated``.
Keyed by id() for fast lookup when a wrapper needs the unwrapped callable.
"""

# Also keep a version keyed by the decorated func object itself (not id),
# for use in model_funcs where we need ``func in decorated_func_mapper``
# (i.e. the ``in`` operator needs the actual object, not its id).
_decorated_func_mapper: dict[Callable[..., Any], Callable[..., Any]] = {}
"""Bidirectional map: decorated -> original AND original -> decorated.

Keyed by actual callable objects (not ids) so that ``func in _decorated_func_mapper``
works.  Used in model_funcs to determine whether a callable is already wrapped.
"""

# ---------------------------------------------------------------------------
# Crawl cache (grows monotonically, never cleared)
# ---------------------------------------------------------------------------
# ``patch_detached_references`` walks sys.modules to find bare references to
# original torch functions (e.g. ``from torch import cos``) and replaces them
# with decorated versions.  These caches avoid re-scanning already-visited
# modules on subsequent calls.

_crawled_module_keys: set[str] = set()
"""sys.modules keys already scanned by ``patch_detached_references``.

Only new keys (modules imported after the last crawl) are scanned on each call,
making repeated crawls cheap.
"""

_dir_cache: dict[type, list[str]] = {}
"""Per-type cache of filtered ``dir()`` results for ``extend_search_stack_from_item``.

Avoids repeated introspection of the same type's attributes during the
recursive sys.modules crawl.
"""

_detached_source_has_torch: dict[str, bool | None] = {}
"""Module source-path cache for ``patch_detached_references``.

Values are ``True`` when source contains the byte substring ``b"torch"``,
``False`` when readable source does not, and ``None`` when source could not be
classified and the conservative full scan should run.
"""

_detached_patch_policy: str = "legacy"
"""Effective detached-reference policy for the current wrapper epoch."""

_detached_patch_modules: tuple[str, ...] = ()
"""Additive exact-module or package-prefix allowlist for scoped deep scanning."""

_detached_patch_epoch: int = 0
"""Monotonically increasing identity for wrapper/patch lifecycle epochs."""

_detached_patch_ledger: list[Any] = []
"""Identity-conditional foreign-slot mutations made in the current epoch."""

_crawled_module_identities: dict[int, Callable[[], Any | None]] = {}
"""Module identity resolvers shallow-scanned in the current patch epoch."""

_detached_positive_module_ids: set[int] = set()
"""Module identities with an exact raw-callable hit in the current epoch."""

_detached_positive_modules: list[Callable[[], Any | None]] = []
"""Owner resolvers for positive scoped candidates retained across captures."""

_escape_detector_mode: str = "off"
"""Callable escape detector mode: ``"off"`` or diagnostic ``"shadow"``."""

_completeness_witness_mode: str = "off"
"""Dispatcher completeness witness mode: ``"off"`` or diagnostic ``"shadow"``."""
_prepared_models: weakref.WeakSet[Any] = weakref.WeakSet()
"""Models that have already been through ``_prepare_model_once()``.

Using a WeakSet ensures that if the user discards a model, it can be
garbage-collected without this set holding a strong reference.  Membership
here means the model's forward and submodule hooks are already installed.
"""

# ---------------------------------------------------------------------------
# Module role-swap tracking (root vs non-root, per prepared tree)
# ---------------------------------------------------------------------------
# ``_prepare_model_once`` assigns role-DEPENDENT permanent metadata: a module's
# dotted address (root-relative) and, for non-root modules, a toggle-gated
# ``forward`` decoration. The root's ``forward`` is deliberately left UNDECORATED
# because ``trace`` invokes and frames it separately. That assignment silently
# assumed a module's root/non-root role never changes across its lifetime.
#
# It can: the SAME module can be traced as a non-root submodule in one trace and
# as its own top-level root in a later trace (or vice versa). When that happens,
# the metadata cached for the old role is stale for the new one -- a decorated
# forward run as a root crashes ``push_frame`` (the root is never registered in
# the per-session module-call dicts), and a descendant re-rooted under a new
# model leaves its ancestor's cached addresses pointing at the wrong root.
#
# These two structures let ``_prepare_model_once`` keep its O(1) cache fast path
# for the overwhelmingly common case (a model traced repeatedly in a fixed role,
# or independent models traced in any interleaving) while forcing a correct
# re-preparation of exactly the trees whose role assignment went stale.

_prepared_root_by_module: "weakref.WeakKeyDictionary[Any, weakref.ref[Any]]" = (
    weakref.WeakKeyDictionary()
)
"""module -> weakref to the ROOT model it was last prepared under.

Weak on both sides: the key (module) is weakly held by the WeakKeyDictionary,
and the value is a ``weakref.ref`` to the root, so neither keeps the other alive.
Read/written only through the helpers below during ``_prepare_model_once``.
"""

_stale_prepared_roots: "weakref.WeakSet[Any]" = weakref.WeakSet()
"""Prepared root models whose cached role metadata is known to be stale.

A root lands here when some module in its subtree is later re-prepared under a
DIFFERENT root (role swap). ``_prepare_model_once`` treats a stale root as
un-prepared for the fast-path check and re-establishes its tree's addresses and
forward decorations before clearing the staleness flag.
"""


def record_module_root_prep(root: Any, module: Any) -> None:
    """Stamp ``module`` as prepared under ``root``; flag a displaced prior root.

    If ``module`` was previously prepared under a different (still-live) root,
    that prior root's cached tree now has a re-rooted descendant and is marked
    stale so its next preparation re-establishes correct role metadata.

    Parameters
    ----------
    root:
        The root model whose ``_prepare_model_once`` traversal is running.
    module:
        A module (the root itself or any descendant) being (re)prepared.

    Returns
    -------
    None
        ``_prepared_root_by_module`` and ``_stale_prepared_roots`` are updated in
        place.
    """
    previous = _prepared_root_by_module.get(module)
    if previous is not None:
        previous_root = previous()
        if previous_root is not None and previous_root is not root:
            _stale_prepared_roots.add(previous_root)
    _prepared_root_by_module[module] = weakref.ref(root)


def root_prep_is_stale(root: Any) -> bool:
    """Return whether ``root``'s cached role metadata is known to be stale.

    Parameters
    ----------
    root:
        Candidate root model.

    Returns
    -------
    bool
        ``True`` when a descendant of ``root`` was re-rooted under another model
        since ``root`` was last prepared.
    """
    return root in _stale_prepared_roots


def clear_root_prep_stale(root: Any) -> None:
    """Clear the staleness flag for ``root`` after re-preparing its tree.

    Parameters
    ----------
    root:
        Root model that has just been (re)prepared.

    Returns
    -------
    None
        ``_stale_prepared_roots`` is updated in place.
    """
    _stale_prepared_roots.discard(root)


# ---------------------------------------------------------------------------
# Usage stats — opt-in per-function call counting for coverage analysis
# ---------------------------------------------------------------------------

_collect_usage_stats: bool = False
"""When True, every decorated wrapper increments call counts in
``_function_call_counts`` during logged forward ops.  Used by the
test suite to verify ArgSpec lookup table coverage."""

_functorch_warning_emitted: bool = False
"""True if a warning about skipped functorch/vmap ops has been emitted for
the current logging session.  Reset to False at the start of every
``active_logging()`` context so each forward pass gets at most one warning."""

_function_call_counts: dict[str, int] = {}
"""func_name -> total calls across all logged forward ops."""

_function_call_models: dict[str, set[str]] = {}
"""func_name -> set of model names that called this function."""

_current_model_name: str = ""
"""Set by test fixtures to identify which model is being logged."""

# ---------------------------------------------------------------------------
# Dynamic ArgSpec cache — Tier 3 of the O(1) extraction strategy
# ---------------------------------------------------------------------------

_dynamic_arg_specs: dict[str, object] = {}
"""Normalized func_name -> ArgSpec, populated by BFS fallback on first
call to an uncovered function.  Subsequent calls reuse the cached spec."""

# ---------------------------------------------------------------------------
# Tagged tensor tracking — for fast cleanup
# ---------------------------------------------------------------------------

_tagged_buffer_ids: set[int] = set()
"""ids of tensors tagged with _tl.address during prepare_buffer_tensors.
Used by _undecorate_model_tensors for O(n) cleanup instead of re-scanning
all module attributes."""

# ---------------------------------------------------------------------------
# Context managers
# ---------------------------------------------------------------------------


class ReentrantTraceError(RuntimeError):
    """Raised when a TorchLens trace is started while another trace is active."""


@contextmanager
def active_logging(trace: "Trace") -> Iterator[None]:
    """Activate logging for the duration of a forward pass.

    Sets ``_logging_enabled = True`` and ``_active_trace = trace``.
    On exit (including exceptions), resets both.

    Ordering invariant:
        - On entry: set ``_active_trace`` *before* the toggle, so wrappers
          never see ``_logging_enabled=True`` with a stale/None trace.
        - On exit: clear the toggle *before* the trace, for the same reason.

    This context manager is NOT nestable.  Only one forward pass may be logged
    at a time (single-threaded design).  Entering a second ``active_logging``
    while another is already active raises ``ReentrantTraceError`` — silently
    corrupting the outer log (overwriting ``_active_trace`` and then
    clearing it on inner exit) is worse than failing loudly.
    """
    global _logging_enabled, _active_trace, _functorch_warning_emitted, _func_call_id_counter
    if _logging_enabled or _active_trace is not None or _hook_reentrancy_depth > 0:
        active_model = getattr(_active_trace, "model_label", None)
        if active_model is None:
            active_model = getattr(_active_trace, "model_class_name", None)
        active_model_text = f" for active model {active_model!r}" if active_model else ""
        raise ReentrantTraceError(
            "torchlens.trace / active_logging is not re-entrant: "
            f"another forward pass{active_model_text} is already being logged. Nested logging "
            "would silently corrupt the outer Trace. If you need to log a "
            "model's forward pass from inside another trace call "
            "(e.g., a custom activation_transform), finish the outer capture "
            "before starting another one."
        )
    # Model log must be visible before the toggle flips — wrappers will
    # immediately read _active_trace once _logging_enabled is True.
    _active_trace = trace
    _functorch_warning_emitted = False
    _func_call_id_counter = 0
    _logging_enabled = True
    try:
        yield
    finally:
        # Toggle off first so no wrapper sees enabled=True with trace=None
        _logging_enabled = False
        _active_trace = None


@contextmanager
def pause_logging() -> Iterator[None]:
    """Temporarily disable logging so internal torch ops don't get recorded.

    Nestable via save/restore: if already paused, restoring ``prev`` (False)
    is a harmless no-op.  If logging was active, it resumes on exit.

    This intentionally does NOT clear ``_active_trace``. The active log
    remains visible while the toggle is paused so ``active_logging()`` can still
    reject nested captures inside paused internal work.

    Typical callers:
        - ``safe_copy``: copies tensors without logging the copy op
        - ``activation_transform``: applies user post-processing without logging
    """
    global _logging_enabled
    prev = _logging_enabled  # save current state (True or False)
    _logging_enabled = False
    try:
        yield
    finally:
        _logging_enabled = prev  # restore — enables nesting without corruption
