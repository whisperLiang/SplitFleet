"""Portable state scrubbing for TorchLens model logs.

This module converts a live ``Trace`` object graph into portable metadata
plus a list of tensor blob specs. It is the save-side counterpart to
rehydration: every class-specific ``PORTABLE_STATE_SPEC`` is applied here so
tensor payloads become ``BlobRef`` placeholders and non-portable live objects
are dropped or stringified before writing ``metadata.pkl``.
"""

from __future__ import annotations

import logging
import pickle
from io import BytesIO
from collections import OrderedDict, defaultdict
from collections.abc import Iterable, Iterator, Mapping
from dataclasses import dataclass, field
from typing import Any

import numpy as np
import torch

from . import BlobRef, FieldPolicy, TLSPEC_VERSION, TorchLensIOError
from .payload_codec import PayloadCodec, get_payload_codec
from ..constants import MODEL_LOG_FIELD_ORDER
from ..data_classes._state_adapter import state_items, state_new, state_restore
from ..data_classes.trace import Trace

_SIMPLE_KEEP_TYPES = (str, int, float, bool, type(None), torch.dtype, torch.device)
_RAW_INPUT_TEXT_LIMIT = 10_000
_RAW_INPUT_TENSOR_BYTES_LIMIT = 1_000_000
_RAW_OUTPUT_TEXT_LIMIT = _RAW_INPUT_TEXT_LIMIT
_RAW_OUTPUT_TENSOR_BYTES_LIMIT = _RAW_INPUT_TENSOR_BYTES_LIMIT
_RAW_CONTAINER_ITEM_LIMIT = 20
_RAW_INPUT_IMAGE_MAX_EDGE = 256
_RAW_INPUT_IMAGE_BYTES_LIMIT = 256_000
_RAW_IMAGE_SENTINEL = "__torchlens_small_raw_image__"
_LOGGER = logging.getLogger(__name__)


@dataclass(frozen=True)
class BlobSpec:
    """A payload selected for portable blob persistence.

    Parameters
    ----------
    blob_id:
        Opaque zero-padded blob identifier.
    value:
        Logical backend payload to persist.
    kind:
        Logical payload kind, for example ``"out"``.
    label:
        Human-readable TorchLens layer label.
    logical_backend:
        Backend name associated with ``value``.
    """

    blob_id: str
    value: Any
    kind: str
    label: str
    logical_backend: str

    def __iter__(self) -> Iterator[Any]:
        """Yield legacy tuple fields for conservative call-site migration."""

        yield self.blob_id
        yield self.value
        yield self.kind
        yield self.label

    def __getitem__(self, index: int) -> Any:
        """Return a legacy tuple field by position."""

        return (self.blob_id, self.value, self.kind, self.label)[index]


@dataclass
class _ScrubOptions:
    """Flags controlling which optional tensor payloads are preserved."""

    include_outs: bool
    include_grads: bool
    include_saved_args: bool
    include_rng_states: bool
    backend_name: str = "torch"
    payload_materialization: bool = True
    payload_codec: PayloadCodec = field(default_factory=lambda: get_payload_codec("torch"))
    unsupported_tensor_records: list[dict[str, str]] = field(default_factory=list)


def scrub_for_save(
    trace: Trace,
    *,
    include_outs: bool = True,
    include_grads: bool = True,
    include_saved_args: bool = False,
    include_rng_states: bool = False,
    backend_name: str | None = None,
    payload_materialization: bool = True,
) -> tuple[dict[str, Any], list[BlobSpec], list[dict[str, str]]]:
    """Scrub a ``Trace`` into portable metadata plus tensor blob specs.

    Parameters
    ----------
    trace:
        Live model log to scrub.
    include_outs:
        Whether saved outs should be replaced with blob references.
    include_grads:
        Whether grads should be replaced with blob references.
    include_saved_args:
        Whether captured args/kwargs and related tensor payloads should be
        preserved via blob references.
    include_rng_states:
        Whether captured RNG state tensors should be preserved via blob
        references.
    backend_name:
        Backend identifier for payload audit records. Defaults to
        ``trace.backend`` when present.
    payload_materialization:
        Whether this backend can serialize materialized tensor payloads.

    Returns
    -------
    tuple[dict[str, Any], list[BlobSpec], list[dict[str, str]]]
        Scrubbed top-level state dict plus blob specs and unsupported tensor
        audit records.
    """

    options = _ScrubOptions(
        include_outs=include_outs,
        include_grads=include_grads,
        include_saved_args=include_saved_args,
        include_rng_states=include_rng_states,
        backend_name=str(backend_name or getattr(trace, "backend", "torch")),
        payload_materialization=payload_materialization,
    )
    options.payload_codec = get_payload_codec(options.backend_name)
    memo: dict[int, Any] = {}
    blob_specs: list[BlobSpec] = []
    blob_counter = [0]

    scrubbed_model = _scrub_value(trace, options, memo, blob_specs, blob_counter)
    if not isinstance(scrubbed_model, Trace):
        raise TorchLensIOError("Portable scrub expected a scrubbed Trace instance.")

    scrubbed_state = dict(state_items(scrubbed_model))
    scrubbed_state["tlspec_version"] = TLSPEC_VERSION

    module_accessor = getattr(trace, "_module_logs", None)
    if module_accessor is not None:
        scrubbed_state["_io_module_accessor_state"] = _scrub_value(
            module_accessor,
            options,
            memo,
            blob_specs,
            blob_counter,
        )
    else:
        scrubbed_state["_io_module_accessor_state"] = None
    return scrubbed_state, blob_specs, options.unsupported_tensor_records


def _scrub_value(
    value: Any,
    options: _ScrubOptions,
    memo: dict[int, Any],
    blob_specs: list[BlobSpec],
    blob_counter: list[int],
    *,
    stringify_unknown: bool = False,
) -> Any:
    """Recursively scrub a value while preserving shared object identity.

    Parameters
    ----------
    stringify_unknown:
        When ``True``, a value with neither a container type handled here
        nor a ``PORTABLE_STATE_SPEC`` falls back to
        :func:`_stringify_value` instead of being returned unchanged. Used
        by the ``save_raw_input``/``save_raw_output`` ``True`` policy
        (:func:`_scrub_raw_value_for_save`) so live, un-picklable objects
        (generators, locks, open file handles, sockets, ...) nested inside
        a user's raw input/output never reach ``pickle.dump`` unmodified.
        Default ``False`` preserves the general-purpose scrub pass used for
        the rest of the ``Trace`` object graph.
    """

    if isinstance(value, _SIMPLE_KEEP_TYPES):
        return value
    if isinstance(value, torch.Size):
        return tuple(value)
    if isinstance(value, BlobRef):
        return value
    if isinstance(value, list):
        return [
            _scrub_value(
                item, options, memo, blob_specs, blob_counter, stringify_unknown=stringify_unknown
            )
            for item in value
        ]
    if isinstance(value, tuple):
        return tuple(
            _scrub_value(
                item, options, memo, blob_specs, blob_counter, stringify_unknown=stringify_unknown
            )
            for item in value
        )
    if isinstance(value, set):
        return {
            _scrub_value(
                item, options, memo, blob_specs, blob_counter, stringify_unknown=stringify_unknown
            )
            for item in value
        }
    if isinstance(value, OrderedDict):
        return OrderedDict(
            (
                key,
                _scrub_value(
                    item,
                    options,
                    memo,
                    blob_specs,
                    blob_counter,
                    stringify_unknown=stringify_unknown,
                ),
            )
            for key, item in value.items()
        )
    if isinstance(value, defaultdict):
        return {
            key: _scrub_value(
                item, options, memo, blob_specs, blob_counter, stringify_unknown=stringify_unknown
            )
            for key, item in value.items()
        }
    if isinstance(value, dict):
        return {
            key: _scrub_value(
                item, options, memo, blob_specs, blob_counter, stringify_unknown=stringify_unknown
            )
            for key, item in value.items()
        }

    spec = getattr(type(value), "PORTABLE_STATE_SPEC", None)
    if spec is None:
        if stringify_unknown and not _is_safely_picklable(value):
            return _stringify_value(value)
        return value
    obj_id = id(value)
    if obj_id in memo:
        return memo[obj_id]

    scrubbed_obj = state_new(type(value))
    memo[obj_id] = scrubbed_obj
    scrubbed_state: dict[str, Any] = {}
    for field_name, field_value in _state_items_for_scrub(value, spec):
        if isinstance(value, Trace) and _is_runtime_only_trace_field(field_name):
            continue
        if field_name not in spec:
            raise TorchLensIOError(
                f"{type(value).__name__}.{field_name} is missing from PORTABLE_STATE_SPEC."
            )
        if field_name == "_is_in_conditional_body" and field_value is None:
            field_value = False
        policy = _effective_policy(value, field_name, spec[field_name], options)
        scrubbed_state[field_name] = _scrub_field(
            owner=value,
            field_name=field_name,
            field_value=field_value,
            policy=policy,
            options=options,
            memo=memo,
            blob_specs=blob_specs,
            blob_counter=blob_counter,
        )

    if isinstance(value, Trace):
        scrubbed_state["_activation_transform_repr"] = (
            repr(value.activation_transform) if value.activation_transform is not None else None
        )
        scrubbed_state["tlspec_version"] = TLSPEC_VERSION

    return state_restore(scrubbed_obj, scrubbed_state)


def _state_items_for_scrub(
    value: Any, spec: Mapping[str, FieldPolicy]
) -> Iterable[tuple[str, Any]]:
    """Yield scrub fields in the portable on-disk order for ``value``.

    Parameters
    ----------
    value:
        Portable-state object being scrubbed.
    spec:
        Portable state policy mapping for ``value``.

    Returns
    -------
    Iterable[tuple[str, Any]]
        Field/value pairs in deterministic scrub order. Only Trace receives
        portable serialization ordering; other classes keep adapter order,
        including slot order for slotted objects.
    """

    if isinstance(value, Trace):
        return _trace_state_items_for_scrub(value, spec)
    return state_items(value)


def _trace_state_items_for_scrub(
    trace: Trace, spec: Mapping[str, FieldPolicy]
) -> Iterable[tuple[str, Any]]:
    """Yield Trace fields in deterministic portable serialization order.

    Parameters
    ----------
    trace:
        Trace whose live state should be scrubbed.
    spec:
        Trace portable state policy mapping.

    Yields
    ------
    tuple[str, Any]
        Live Trace field/value pairs: first fields present in
        ``MODEL_LOG_FIELD_ORDER`` order, then remaining present fields in
        ``PORTABLE_STATE_SPEC`` order, then any still-unseen fields so the
        existing unknown-field guard can raise.
    """

    live_state = dict(state_items(trace))
    yielded_fields: set[str] = set()

    for field_name in MODEL_LOG_FIELD_ORDER:
        if field_name in live_state:
            yielded_fields.add(field_name)
            yield field_name, live_state[field_name]

    for field_name in spec:
        if field_name in live_state and field_name not in yielded_fields:
            yielded_fields.add(field_name)
            yield field_name, live_state[field_name]

    for field_name, field_value in live_state.items():
        if field_name not in yielded_fields:
            yield field_name, field_value


def _is_runtime_only_trace_field(field_name: str) -> bool:
    """Return whether a Trace field is intentionally omitted from portable state.

    Parameters
    ----------
    field_name
        Trace ``__dict__`` key under scrub consideration.

    Returns
    -------
    bool
        True when the field stores runtime-only interpreter or visualization state.
    """

    return field_name in {
        "_last_sibling_ordering_decision",
        "_pending_container_collapse_nodes",
        "_defer_streaming_bundle_finalization",
        "_capture_producer_policy",
        "_capture_config",
        "_stop_directive",
        "_retain_layers_to_save_output_parents",
        "_fast_raw_index_lookup",
        "_keep_outs_in_memory",
        "_capture_container_structure",
        "_capture_output_structure",
        "_out_sink",
        "_out_writer",
        "_container_ordinals_by_output_op_label",
        "_container_ordinals_by_input_func_call_id",
        "_validation_replay_status",
        "_tl_predicate_intervention_spec_keys",
        "jax_closed_jaxpr",
        "jax_equation_captures",
        "jax_ordered_captures",
        "jax_region_captures",
        "_jax_capture_index_to_raw_op_label",
        "jax_capture_index_to_final_op_label",
        "jax_inlined_call_primitives",
        "jax_outvar_key_to_capture_index",
        "jax_static_argnums",
        "_selective_save_hidden_payloads",
        "_output_style",
        "_output_head",
        "_output_tokenizer",
        "_semantic_output_metadata",
        "tinygrad_payload_policy",
        "tinygrad_uop_captures",
    }


def _effective_policy(
    owner: Any,
    field_name: str,
    base_policy: FieldPolicy,
    options: _ScrubOptions,
) -> FieldPolicy:
    """Resolve the runtime policy for a field after include-flag overrides."""

    if field_name in {"out", "transformed_out"} and not options.include_outs:
        return FieldPolicy.DROP
    if field_name in {"grad", "transformed_grad"} and not options.include_grads:
        return FieldPolicy.DROP
    if field_name in {"saved_args", "saved_kwargs", "out_versions_by_child"}:
        return FieldPolicy.BLOB_RECURSIVE if options.include_saved_args else FieldPolicy.DROP
    if field_name in {"forward_args", "forward_kwargs"}:
        return FieldPolicy.BLOB_RECURSIVE if options.include_saved_args else FieldPolicy.DROP
    if field_name == "func_rng_states":
        return FieldPolicy.BLOB_RECURSIVE if options.include_rng_states else FieldPolicy.DROP
    return base_policy


def _scrub_field(
    *,
    owner: Any,
    field_name: str,
    field_value: Any,
    policy: FieldPolicy,
    options: _ScrubOptions,
    memo: dict[int, Any],
    blob_specs: list[BlobSpec],
    blob_counter: list[int],
) -> Any:
    """Scrub one object field according to its effective field policy."""

    if isinstance(owner, Trace) and field_name in {"raw_input", "raw_output"}:
        return _scrub_raw_value_for_save(
            owner,
            field_name,
            field_value,
            options,
            memo,
            blob_specs,
            blob_counter,
        )
    if policy in {FieldPolicy.DROP, FieldPolicy.WEAKREF_STRIP}:
        return None
    if policy == FieldPolicy.STRINGIFY:
        return _stringify_value(field_value)
    if policy == FieldPolicy.BLOB:
        return _blobify_tensor_field(
            owner, field_name, field_value, blob_specs, blob_counter, options
        )
    if policy == FieldPolicy.BLOB_RECURSIVE:
        return _blobify_recursive_value(
            owner=owner,
            field_name=field_name,
            value=field_value,
            options=options,
            memo=memo,
            blob_specs=blob_specs,
            blob_counter=blob_counter,
        )
    return _scrub_value(field_value, options, memo, blob_specs, blob_counter)


def _scrub_raw_value_for_save(
    owner: Trace,
    field_name: str,
    value: Any,
    options: _ScrubOptions,
    memo: dict[int, Any],
    blob_specs: list[BlobSpec],
    blob_counter: list[int],
) -> Any:
    """Apply a raw-value save policy before portable metadata serialization.

    Parameters
    ----------
    owner:
        Trace carrying the raw-value save policy.
    field_name:
        Raw-value field being serialized.
    value:
        Raw user input or output metadata to serialize.
    options:
        Active scrub options.
    memo:
        Object-identity memo for recursive scrubbing.
    blob_specs:
        Accumulated tensor blob specs.
    blob_counter:
        Mutable blob id counter.

    Returns
    -------
    Any
        Scrubbed raw value, a bounded placeholder, or ``None``.
    """

    policy_name = f"save_{field_name}"
    policy = getattr(owner, policy_name, "small")
    if policy is False:
        return None
    if policy is True:
        # Scrub with ``stringify_unknown=True`` (not the default
        # passthrough) so live, un-picklable objects nested inside a raw
        # input/output (generators, locks, open file handles, sockets, ...)
        # fall through to ``_stringify_value``'s bounded placeholder instead
        # of reaching ``pickle.dump`` unmodified. This mirrors the
        # ``saved_args``/``forward_args``/``custom_attributes`` policy,
        # which already uses a stringify fallback (via
        # ``_blobify_recursive_value``) for exactly this class of object.
        return _scrub_value(value, options, memo, blob_specs, blob_counter, stringify_unknown=True)
    if policy != "small":
        raise TorchLensIOError(f"{policy_name} must be 'small', True, or False.")
    return _small_raw_value(value, field_name=field_name)


def _small_raw_value(value: Any, *, field_name: str) -> Any:
    """Return a bounded portable representation of a raw value.

    Parameters
    ----------
    value:
        Raw user input or output metadata.
    field_name:
        Raw-value field being serialized.

    Returns
    -------
    Any
        Truncated string, small tensor, bounded image bytes, recursively
        bounded container, or ``None`` when the value is too large or
        unsupported. PIL images under ``save_raw_input="small"`` are copied,
        downsampled to at most 256 px on the longest edge, encoded as PNG or
        JPEG bytes, and dropped if the encoded payload exceeds 256 KB.
    """

    if value is None:
        return None
    if isinstance(value, str):
        text_limit = _RAW_OUTPUT_TEXT_LIMIT if field_name == "raw_output" else _RAW_INPUT_TEXT_LIMIT
        return value[:text_limit]
    if isinstance(value, torch.Tensor):
        tensor_bytes = value.nelement() * value.element_size()
        tensor_limit = (
            _RAW_OUTPUT_TENSOR_BYTES_LIMIT
            if field_name == "raw_output"
            else _RAW_INPUT_TENSOR_BYTES_LIMIT
        )
        if tensor_bytes <= tensor_limit:
            return value
        _LOGGER.debug(
            "Dropping %s tensor over small-policy cap: %s bytes", field_name, tensor_bytes
        )
        return None
    if field_name == "raw_input":
        small_image = _small_raw_image_value(value)
        if small_image is not None:
            return small_image
    if isinstance(value, list):
        return [
            _small_raw_value(item, field_name=field_name)
            for item in value[:_RAW_CONTAINER_ITEM_LIMIT]
        ]
    if isinstance(value, tuple):
        return tuple(
            _small_raw_value(item, field_name=field_name)
            for item in value[:_RAW_CONTAINER_ITEM_LIMIT]
        )
    if isinstance(value, dict):
        return {
            key: _small_raw_value(item, field_name=field_name)
            for key, item in list(value.items())[:_RAW_CONTAINER_ITEM_LIMIT]
        }
    _LOGGER.debug(
        "Dropping unsupported %s type under small policy: %s",
        field_name,
        type(value).__name__,
    )
    return None


def _small_raw_image_value(value: Any) -> dict[str, Any] | None:
    """Return bounded bytes for a PIL image under the small raw-input policy.

    Parameters
    ----------
    value:
        Candidate raw input value.

    Returns
    -------
    dict[str, Any] | None
        Sentinel dictionary containing encoded image bytes and metadata, or
        ``None`` when ``value`` is not a PIL image or cannot fit the cap.
    """

    try:
        from PIL.Image import Image as PILImage
    except ImportError:
        return None
    if not isinstance(value, PILImage):
        return None

    image = value.copy()
    original_size = tuple(image.size)
    image.thumbnail((_RAW_INPUT_IMAGE_MAX_EDGE, _RAW_INPUT_IMAGE_MAX_EDGE))
    if image.mode not in {"RGB", "L"}:
        image = image.convert("RGBA" if "A" in image.getbands() else "RGB")
    encoded = _encode_small_raw_image(image, fmt="PNG")
    image_format = "PNG"
    if encoded is None and image.mode != "RGBA":
        encoded = _encode_small_raw_image(image.convert("RGB"), fmt="JPEG")
        image_format = "JPEG"
    if encoded is None:
        _LOGGER.debug("Dropping raw_input PIL image over small-policy cap.")
        return None
    return {
        _RAW_IMAGE_SENTINEL: True,
        "format": image_format,
        "mode": image.mode,
        "size": tuple(image.size),
        "original_size": original_size,
        "max_edge": _RAW_INPUT_IMAGE_MAX_EDGE,
        "bytes_limit": _RAW_INPUT_IMAGE_BYTES_LIMIT,
        "data": encoded,
    }


def _encode_small_raw_image(image: Any, *, fmt: str) -> bytes | None:
    """Encode a PIL image and enforce the small-policy byte cap.

    Parameters
    ----------
    image:
        PIL image to encode.
    fmt:
        Pillow format name.

    Returns
    -------
    bytes | None
        Encoded bytes when they fit the cap, otherwise ``None``.
    """

    buffer = BytesIO()
    save_kwargs: dict[str, Any] = {"format": fmt}
    if fmt == "JPEG":
        save_kwargs.update({"quality": 85, "optimize": True})
    image.save(buffer, **save_kwargs)
    data = buffer.getvalue()
    if len(data) > _RAW_INPUT_IMAGE_BYTES_LIMIT:
        return None
    return data


def _blobify_tensor_field(
    owner: Any,
    field_name: str,
    field_value: Any,
    blob_specs: list[BlobSpec],
    blob_counter: list[int],
    options: _ScrubOptions,
) -> Any:
    """Replace a tensor field with a ``BlobRef`` and record its blob spec."""

    if field_value is None:
        return None
    if not options.payload_materialization and not isinstance(field_value, torch.Tensor):
        return _audit_null_tensor_field(
            owner,
            field_name,
            options,
            reason=f"{options.backend_name}_array_audit_null",
        )
    if not options.payload_codec.can_encode(field_value):
        raise TorchLensIOError(
            f"{type(owner).__name__}.{field_name} expected a codec-encodable payload for "
            "portable blobification, "
            f"got {type(field_value).__name__}."
        )
    blob_id = _next_blob_id(blob_counter)
    kind = _blob_kind_for_field(owner, field_name)
    label = _blob_label_for_owner(owner)
    tensor_payload = (
        field_value.detach() if isinstance(field_value, torch.nn.Parameter) else field_value
    )
    blob_specs.append(
        BlobSpec(
            blob_id=blob_id,
            value=tensor_payload,
            kind=kind,
            label=label,
            logical_backend=options.backend_name,
        )
    )
    return BlobRef(blob_id=blob_id, kind=kind)


def _audit_null_tensor_field(
    owner: Any,
    field_name: str,
    options: _ScrubOptions,
    *,
    reason: str,
) -> None:
    """Record an audit-only tensor payload that cannot be blobified.

    Parameters
    ----------
    owner:
        Object carrying the payload field.
    field_name:
        Name of the payload field.
    options:
        Active scrub options that collect unsupported tensor records.
    reason:
        Stable manifest reason code.

    Returns
    -------
    None
        The live payload is replaced by ``None`` in scrubbed state.
    """

    options.unsupported_tensor_records.append(
        {
            "owner_type": type(owner).__name__,
            "owner_label": _blob_label_for_owner(owner),
            "field": field_name,
            "kind": _blob_kind_for_field(owner, field_name),
            "reason": reason,
        }
    )
    return None


def _blobify_recursive_value(
    *,
    owner: Any,
    field_name: str,
    value: Any,
    options: _ScrubOptions,
    memo: dict[int, Any],
    blob_specs: list[BlobSpec],
    blob_counter: list[int],
) -> Any:
    """Blobify tensors recursively inside nested containers."""

    if isinstance(value, _SIMPLE_KEEP_TYPES):
        return value
    if isinstance(value, torch.Size):
        return tuple(value)
    if isinstance(value, BlobRef):
        return value
    if options.payload_codec.can_encode(value):
        return _blobify_tensor_field(owner, field_name, value, blob_specs, blob_counter, options)
    if isinstance(value, list):
        return [
            _blobify_recursive_value(
                owner=owner,
                field_name=field_name,
                value=item,
                options=options,
                memo=memo,
                blob_specs=blob_specs,
                blob_counter=blob_counter,
            )
            for item in value
        ]
    if isinstance(value, tuple):
        return tuple(
            _blobify_recursive_value(
                owner=owner,
                field_name=field_name,
                value=item,
                options=options,
                memo=memo,
                blob_specs=blob_specs,
                blob_counter=blob_counter,
            )
            for item in value
        )
    if isinstance(value, OrderedDict):
        return OrderedDict(
            (
                key,
                _blobify_recursive_value(
                    owner=owner,
                    field_name=field_name,
                    value=item,
                    options=options,
                    memo=memo,
                    blob_specs=blob_specs,
                    blob_counter=blob_counter,
                ),
            )
            for key, item in value.items()
        )
    if isinstance(value, defaultdict):
        return {
            key: _blobify_recursive_value(
                owner=owner,
                field_name=field_name,
                value=item,
                options=options,
                memo=memo,
                blob_specs=blob_specs,
                blob_counter=blob_counter,
            )
            for key, item in value.items()
        }
    if isinstance(value, dict):
        return {
            key: _blobify_recursive_value(
                owner=owner,
                field_name=field_name,
                value=item,
                options=options,
                memo=memo,
                blob_specs=blob_specs,
                blob_counter=blob_counter,
            )
            for key, item in value.items()
        }
    if isinstance(value, set):
        return {
            _blobify_recursive_value(
                owner=owner,
                field_name=field_name,
                value=item,
                options=options,
                memo=memo,
                blob_specs=blob_specs,
                blob_counter=blob_counter,
            )
            for item in value
        }

    spec = getattr(type(value), "PORTABLE_STATE_SPEC", None)
    if spec is not None:
        return _scrub_value(value, options, memo, blob_specs, blob_counter)
    return _stringify_value(value)


def _stringify_value(value: Any) -> str:
    """Convert a non-portable object into a stable placeholder string."""

    return f"<scrubbed:{type(value).__name__}>"


_KNOWN_SAFELY_PICKLABLE_TYPES = (torch.Tensor,)


def _is_safely_picklable(value: Any) -> bool:
    """Return whether ``value`` can be pickled without raising.

    Used by :func:`_scrub_value`'s ``stringify_unknown`` path to decide
    whether an unspecced leaf value (one with no
    ``PORTABLE_STATE_SPEC``) reached via ``save_raw_input``/
    ``save_raw_output``'s ``True`` policy should be kept as-is (full
    retention, per those options' docs) or degraded to a bounded
    :func:`_stringify_value` placeholder. Probing picklability once, here,
    at scrub time -- rather than letting the real ``pickle.dump()`` over
    the full scrubbed state discover the problem later -- is what keeps
    live-resource objects (generators, locks, open file handles, sockets,
    ...) from ever reaching that later call, where a failure mid-write can
    otherwise cost an already-saved bundle (see ``bundle.py``'s ``save()``
    atomic-write/backup-restore contract).

    ``torch.Tensor`` and ``numpy.ndarray`` values whose dtype holds no
    object references (numeric, bool, string, and structured dtypes with
    no object-typed field) are exempted from the probe: they always
    support the standard pickle protocol via their own ``__reduce_ex__``
    and hold no live OS resources that could make pickling fail, so
    probing them would only pay a full extra ``pickle.dumps()`` pass --
    doubling CPU and transiently doubling peak memory -- for a result
    that is always ``True``. Any ``numpy.ndarray`` whose dtype reports
    ``hasobject`` (a plain ``object``-dtype array, or a structured/
    compound/nested dtype with an object-typed field), however, is NOT
    exempted: it may hold arbitrary live Python objects (generators,
    locks, or other unpicklable values) in any of its fields, just like a
    plain ``list`` or ``dict`` can, so exempting it would reintroduce
    exactly the hard ``save()`` failure this probe exists to prevent.
    ``dtype.hasobject`` is used rather than a top-level
    ``dtype != np.dtype("object")`` identity check because the latter is
    only true for a bare object dtype -- a structured dtype whose fields
    include ``object`` is never itself equal to ``np.dtype("object")`` and
    would wrongly slip through an identity comparison even though it
    genuinely embeds live object references. Skipping the probe only for
    provably-safe types keeps the live-resource detection intact for
    every value it actually protects.

    Parameters
    ----------
    value:
        Candidate value to probe.

    Returns
    -------
    bool
        ``True`` if ``pickle.dumps(value)`` succeeds, ``False`` otherwise.
    """

    if isinstance(value, _KNOWN_SAFELY_PICKLABLE_TYPES):
        return True
    if isinstance(value, np.ndarray) and not value.dtype.hasobject:
        return True

    try:
        pickle.dumps(value, protocol=pickle.HIGHEST_PROTOCOL)
    except Exception:
        return False
    return True


def _next_blob_id(blob_counter: list[int]) -> str:
    """Allocate the next monotonically increasing zero-padded blob id."""

    blob_counter[0] += 1
    return f"{blob_counter[0]:010d}"


def _blob_kind_for_field(owner: Any, field_name: str) -> str:
    """Map an object field name to the portable manifest tensor kind."""

    if field_name == "out":
        return "out"
    if field_name == "transformed_out":
        return "transformed_out"
    if field_name == "grad":
        return "grad"
    if field_name == "transformed_grad":
        return "transformed_grad"
    if field_name in {"saved_args", "saved_kwargs"}:
        return "captured_arg"
    if field_name == "out_versions_by_child":
        return "child_version"
    if field_name == "func_rng_states":
        return "rng_state"
    if field_name in {"forward_args", "forward_kwargs"}:
        return "module_arg"
    if field_name in {"_args", "_kwargs", "payload"} and type(owner).__name__ in {
        "ModuleInputSnapshot",
        "TensorInputObservation",
    }:
        return "pre_hook_input"
    if field_name == "func_config":
        return "func_config"
    if field_name == "custom_attributes":
        return "module_meta"
    if field_name in {"grad_inputs", "grad_outputs"}:
        return "grad_fn_grad"
    if field_name == "_buffer_initial_values":
        return "buffer_initial_value"
    if field_name == "_annotation_blobs":
        return "annotation_blob"
    if field_name == "orphan_records":
        return "orphan_payload"
    raise TorchLensIOError(f"No blob kind mapping defined for {type(owner).__name__}.{field_name}.")


def _blob_label_for_owner(owner: Any) -> str:
    """Return the human-readable label stored alongside a blob spec."""

    if hasattr(owner, "label") and getattr(owner, "label") is not None:
        return str(getattr(owner, "label"))
    if hasattr(owner, "call_label") and getattr(owner, "call_label") is not None:
        return str(getattr(owner, "call_label"))
    if hasattr(owner, "address") and getattr(owner, "address") is not None:
        return str(getattr(owner, "address"))
    return type(owner).__name__
