"""Portable bundle manifest schema and compatibility policy.

This module defines the authoritative ``manifest.json`` structure for
TorchLens bundles, along with version and integrity helpers used by both save
and load paths. It records bundle-level metadata, one entry per persisted
tensor blob, and the compatibility checks that run before ``metadata.pkl`` is
trusted.
"""

from __future__ import annotations

import json
import logging
import sys
import warnings
from dataclasses import asdict, dataclass
from hashlib import sha256
from pathlib import Path
from typing import Any

import torch
from packaging.version import InvalidVersion, Version

from . import TLSPEC_VERSION, TorchLensIOError
from .. import __version__ as TORCHLENS_VERSION

LOGGER = logging.getLogger(__name__)


@dataclass(frozen=True)
class TensorEntry:
    """One persisted tensor blob entry in ``manifest.json``.

    Parameters
    ----------
    blob_id:
        Opaque zero-padded blob identifier.
    kind:
        Logical tensor kind, for example ``"out"``.
    label:
        Human-readable TorchLens layer label associated with the blob.
    relative_path:
        Bundle-relative path to the blob file.
    backend:
        Storage backend name. Only ``"safetensors"`` is currently supported.
    shape:
        Tensor shape recorded at save time.
    dtype:
        Tensor dtype string recorded at save time.
    device_at_save:
        Original tensor device string.
    layout:
        Tensor layout string recorded at save time.
    bytes:
        Persisted tensor byte size after any ``.contiguous()`` conversion.
    sha256:
        SHA-256 digest of the written blob file bytes.
    requires_grad:
        Whether the logical torch tensor required gradients at save time.
    logical_backend:
        Optional logical backend that produced the payload before transport.
    codec:
        Optional payload codec name used to encode the logical payload.
    logical_dtype:
        Optional logical backend dtype string before transport conversion.
    logical_device:
        Optional logical backend device string before transport conversion.
    transport_backend:
        Optional physical transport backend used for persisted bytes.
    transport_dtype:
        Optional physical transport dtype string.
    codec_metadata:
        Optional best-effort JSON-ready codec metadata.
    """

    blob_id: str
    kind: str
    label: str
    relative_path: str
    backend: str
    shape: list[int]
    dtype: str
    device_at_save: str
    layout: str
    bytes: int
    sha256: str
    requires_grad: bool = False
    logical_backend: str | None = None
    codec: str | None = None
    logical_dtype: str | None = None
    logical_device: str | None = None
    transport_backend: str | None = None
    transport_dtype: str | None = None
    codec_metadata: dict[str, Any] | None = None

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> TensorEntry:
        """Validate and build a ``TensorEntry`` from JSON-decoded data.

        Parameters
        ----------
        data:
            Raw decoded JSON mapping.

        Returns
        -------
        TensorEntry
            Validated tensor entry.

        Raises
        ------
        TorchLensIOError
            If the entry is missing required fields or uses invalid types.
        """

        required_str_fields = (
            "blob_id",
            "kind",
            "label",
            "relative_path",
            "backend",
            "dtype",
            "device_at_save",
            "layout",
            "sha256",
        )
        for field_name in required_str_fields:
            field_value = data.get(field_name)
            if not isinstance(field_value, str) or field_value == "":
                raise TorchLensIOError(
                    f"Manifest tensor entry must include non-empty string {field_name!r}."
                )

        shape = data.get("shape")
        if not isinstance(shape, list) or any(not isinstance(dim, int) for dim in shape):
            raise TorchLensIOError("Manifest tensor entry 'shape' must be a list of ints.")

        num_bytes = data.get("bytes")
        if not isinstance(num_bytes, int) or num_bytes < 0:
            raise TorchLensIOError("Manifest tensor entry 'bytes' must be a non-negative int.")

        optional_strings = {
            field_name: _optional_str(data, field_name)
            for field_name in (
                "logical_backend",
                "codec",
                "logical_dtype",
                "logical_device",
                "transport_backend",
                "transport_dtype",
            )
        }
        codec_metadata = data.get("codec_metadata")
        if codec_metadata is not None and not isinstance(codec_metadata, dict):
            raise TorchLensIOError("Manifest tensor entry 'codec_metadata' must be an object.")
        requires_grad = data.get("requires_grad", False)
        if not isinstance(requires_grad, bool):
            raise TorchLensIOError("Manifest tensor entry 'requires_grad' must be a boolean.")

        return cls(
            blob_id=data["blob_id"],
            kind=data["kind"],
            label=data["label"],
            relative_path=data["relative_path"],
            backend=data["backend"],
            shape=shape,
            dtype=data["dtype"],
            device_at_save=data["device_at_save"],
            layout=data["layout"],
            bytes=num_bytes,
            sha256=data["sha256"],
            requires_grad=requires_grad,
            codec_metadata=codec_metadata,
            **optional_strings,
        )

    def to_dict(self) -> dict[str, Any]:
        """Convert the entry into JSON-serializable data.

        Returns
        -------
        dict[str, Any]
            JSON-ready manifest entry.
        """

        return {key: value for key, value in asdict(self).items() if value is not None}


def _optional_str(data: dict[str, Any], field_name: str) -> str | None:
    """Return an optional manifest string field after validation.

    Parameters
    ----------
    data:
        Manifest entry mapping.
    field_name:
        Optional field to read.

    Returns
    -------
    str | None
        Field value, or ``None`` when omitted.

    Raises
    ------
    TorchLensIOError
        If the optional value is present but not a non-empty string.
    """

    field_value = data.get(field_name)
    if field_value is None:
        return None
    if not isinstance(field_value, str) or field_value == "":
        raise TorchLensIOError(
            f"Manifest tensor entry optional field {field_name!r} must be a non-empty string."
        )
    return field_value


@dataclass(frozen=True)
class Manifest:
    """Structured representation of ``manifest.json`` for portable bundles.

    Parameters
    ----------
    tlspec_version:
        Portable I/O schema version for TorchLens bundle metadata.
    torchlens_version:
        TorchLens runtime version that wrote the bundle.
    torch_version:
        PyTorch runtime version that wrote the bundle.
    python_version:
        Python runtime version that wrote the bundle.
    platform:
        Platform identifier string recorded at save time.
    created_at:
        UTC timestamp string for bundle creation.
    bundle_format:
        Bundle container format: ``"directory"`` for standard portable
        bundles written by ``Trace.save()``/``tl.save()``, or
        ``"fastlog-directory"`` for fastlog ring-buffer disk storage
        (see ``torchlens/fastlog/storage_disk.py``).
    n_layers:
        Total number of ``Op`` entries in the saved log.
    n_out_blobs:
        Count of persisted out tensor blobs.
    n_grad_blobs:
        Count of persisted grad tensor blobs.
    n_auxiliary_blobs:
        Count of persisted non-out, non-grad tensor blobs.
    tensors:
        Persisted tensor entries.
    unsupported_tensors:
        Best-effort records for tensors skipped under ``strict=False``.
    """

    tlspec_version: int
    torchlens_version: str
    torch_version: str
    python_version: str
    platform: str
    created_at: str
    bundle_format: str
    n_layers: int
    n_out_blobs: int
    n_grad_blobs: int
    n_auxiliary_blobs: int
    tensors: list[TensorEntry]
    unsupported_tensors: list[dict[str, str]]

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> Manifest:
        """Validate decoded JSON data and build a manifest instance.

        Parameters
        ----------
        data:
            Raw JSON-decoded mapping.

        Returns
        -------
        Manifest
            Validated manifest.

        Raises
        ------
        TorchLensIOError
            If required fields are missing or have invalid types.
        """

        required_int_fields = (
            "tlspec_version",
            "n_layers",
            "n_out_blobs",
            "n_grad_blobs",
            "n_auxiliary_blobs",
        )
        required_str_fields = (
            "torchlens_version",
            "torch_version",
            "python_version",
            "platform",
            "created_at",
            "bundle_format",
        )

        for field_name in required_int_fields:
            field_value = data.get(field_name)
            if not isinstance(field_value, int) or field_value < 0:
                raise TorchLensIOError(
                    f"Manifest field {field_name!r} must be a non-negative integer."
                )

        for field_name in required_str_fields:
            field_value = data.get(field_name)
            if not isinstance(field_value, str) or field_value == "":
                raise TorchLensIOError(f"Manifest field {field_name!r} must be a non-empty string.")

        if data["bundle_format"] not in {"directory", "fastlog-directory"}:
            raise TorchLensIOError(
                "Unsupported bundle_format="
                f"{data['bundle_format']!r}; expected 'directory' or 'fastlog-directory'."
            )

        raw_tensors = data.get("tensors")
        if not isinstance(raw_tensors, list):
            raise TorchLensIOError("Manifest field 'tensors' must be a list.")
        tensors = [TensorEntry.from_dict(entry) for entry in raw_tensors]

        unsupported_tensors = _validate_unsupported_tensors(data.get("unsupported_tensors"))
        manifest = cls(
            tlspec_version=data["tlspec_version"],
            torchlens_version=data["torchlens_version"],
            torch_version=data["torch_version"],
            python_version=data["python_version"],
            platform=data["platform"],
            created_at=data["created_at"],
            bundle_format=data["bundle_format"],
            n_layers=data["n_layers"],
            n_out_blobs=data["n_out_blobs"],
            n_grad_blobs=data["n_grad_blobs"],
            n_auxiliary_blobs=data["n_auxiliary_blobs"],
            tensors=tensors,
            unsupported_tensors=unsupported_tensors,
        )
        manifest._validate_counts()
        return manifest

    @classmethod
    def read(cls, path: str | Path) -> Manifest:
        """Read, parse, and validate ``manifest.json``.

        Parameters
        ----------
        path:
            Path to the manifest file.

        Returns
        -------
        Manifest
            Validated manifest instance.

        Raises
        ------
        TorchLensIOError
            If the file cannot be read or does not decode into a valid manifest.
        """

        manifest_path = Path(path)
        try:
            with manifest_path.open("r", encoding="utf-8") as handle:
                raw_data = json.load(handle)
        except (OSError, json.JSONDecodeError) as exc:
            raise TorchLensIOError(f"Failed to read manifest at {manifest_path}.") from exc
        if not isinstance(raw_data, dict):
            raise TorchLensIOError("Manifest root must be a JSON object.")
        return cls.from_dict(raw_data)

    def write(self, path: str | Path) -> None:
        """Write the manifest to disk using pretty-printed JSON.

        Parameters
        ----------
        path:
            Destination path for ``manifest.json``.

        Raises
        ------
        TorchLensIOError
            If the file cannot be written.
        """

        manifest_path = Path(path)
        try:
            with manifest_path.open("w", encoding="utf-8") as handle:
                json.dump(self.to_dict(), handle, indent=2, sort_keys=False)
                handle.write("\n")
        except OSError as exc:
            raise TorchLensIOError(f"Failed to write manifest at {manifest_path}.") from exc

    def to_dict(self) -> dict[str, Any]:
        """Convert the manifest into JSON-serializable data.

        Returns
        -------
        dict[str, Any]
            JSON-ready manifest mapping.
        """

        data = asdict(self)
        data["tensors"] = [entry.to_dict() for entry in self.tensors]
        return data

    def _validate_counts(self) -> None:
        """Ensure manifest tensor counts match the declared summary fields.

        Raises
        ------
        TorchLensIOError
            If the declared counts disagree with the tensor entries.
        """

        n_out_blobs = sum(1 for entry in self.tensors if entry.kind == "out")
        n_grad_blobs = sum(1 for entry in self.tensors if entry.kind == "grad")
        n_auxiliary_blobs = len(self.tensors) - n_out_blobs - n_grad_blobs
        if self.n_out_blobs != n_out_blobs:
            raise TorchLensIOError("Manifest n_out_blobs does not match tensor entries.")
        if self.n_grad_blobs != n_grad_blobs:
            raise TorchLensIOError("Manifest n_grad_blobs does not match tensor entries.")
        if self.n_auxiliary_blobs != n_auxiliary_blobs:
            raise TorchLensIOError("Manifest n_auxiliary_blobs does not match tensor entries.")


def sha256_of_file(path: str | Path) -> str:
    """Compute the SHA-256 digest of one file's bytes.

    Parameters
    ----------
    path:
        File path to hash.

    Returns
    -------
    str
        Lowercase hexadecimal digest.
    """

    digest = sha256()
    with Path(path).open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def enforce_version_policy(manifest: Manifest) -> None:
    """Apply the bundle version and integrity compatibility policy for a loaded manifest.

    Parameters
    ----------
    manifest:
        Parsed manifest to validate against the current runtime.

    Raises
    ------
    TorchLensIOError
        If the bundle targets a newer I/O format or an incompatible torch
        major version.
    """

    if manifest.tlspec_version > TLSPEC_VERSION:
        raise TorchLensIOError(
            "Bundle uses tlspec_version="
            f"{manifest.tlspec_version}, but this runtime only supports "
            f"{TLSPEC_VERSION}."
        )
    if manifest.tlspec_version < TLSPEC_VERSION:
        warnings.warn(
            "Bundle tlspec_version="
            f"{manifest.tlspec_version} is older than runtime "
            f"tlspec_version={TLSPEC_VERSION}; missing portable fields may "
            "default-fill during load.",
            DeprecationWarning,
            stacklevel=2,
        )

    runtime_torch = _parse_version(torch.__version__, label="runtime torch")
    manifest_torch = _parse_version(manifest.torch_version, label="manifest torch")
    if runtime_torch is not None and manifest_torch is not None:
        if runtime_torch.major != manifest_torch.major:
            raise TorchLensIOError(
                "Bundle torch_version="
                f"{manifest.torch_version} is incompatible with runtime torch_version="
                f"{torch.__version__} (major version mismatch)."
            )
        if runtime_torch.minor != manifest_torch.minor:
            warnings.warn(
                "Bundle torch_version="
                f"{manifest.torch_version} differs from runtime torch_version="
                f"{torch.__version__} (minor version mismatch).",
                UserWarning,
                stacklevel=2,
            )
    elif manifest.torch_version != torch.__version__:
        raise TorchLensIOError(
            "Bundle torch_version="
            f"{manifest.torch_version} could not be parsed compatibly with runtime "
            f"torch_version={torch.__version__}; refusing load."
        )

    runtime_torchlens = _parse_version(TORCHLENS_VERSION, label="runtime torchlens")
    manifest_torchlens = _parse_version(manifest.torchlens_version, label="manifest torchlens")
    if runtime_torchlens is not None and manifest_torchlens is not None:
        if manifest_torchlens > runtime_torchlens:
            warnings.warn(
                "Bundle torchlens_version="
                f"{manifest.torchlens_version} is newer than runtime torchlens_version="
                f"{TORCHLENS_VERSION}.",
                UserWarning,
                stacklevel=2,
            )
        elif manifest_torchlens < runtime_torchlens:
            LOGGER.info(
                "Bundle torchlens_version=%s is older than runtime torchlens_version=%s.",
                manifest.torchlens_version,
                TORCHLENS_VERSION,
            )
    elif manifest.torchlens_version != TORCHLENS_VERSION:
        warnings.warn(
            "Bundle torchlens_version="
            f"{manifest.torchlens_version} differs from runtime torchlens_version="
            f"{TORCHLENS_VERSION} and could not be parsed under PEP 440.",
            UserWarning,
            stacklevel=2,
        )

    runtime_python = _parse_version(_runtime_python_version(), label="runtime python")
    manifest_python = _parse_version(manifest.python_version, label="manifest python")
    if runtime_python is not None and manifest_python is not None:
        if runtime_python.major != manifest_python.major:
            warnings.warn(
                "Bundle python_version="
                f"{manifest.python_version} differs from runtime python_version="
                f"{_runtime_python_version()} (major version mismatch).",
                UserWarning,
                stacklevel=2,
            )
    elif manifest.python_version != _runtime_python_version():
        warnings.warn(
            "Bundle python_version="
            f"{manifest.python_version} differs from runtime python_version="
            f"{_runtime_python_version()} and could not be parsed under PEP 440.",
            UserWarning,
            stacklevel=2,
        )


def _parse_version(version_text: str, *, label: str) -> Version | None:
    """Parse a version string under PEP 440 with warning fallback.

    Parameters
    ----------
    version_text:
        Raw version string to parse.
    label:
        Human-readable label for warnings.

    Returns
    -------
    Version | None
        Parsed version object, or ``None`` when parsing fails.
    """

    try:
        return Version(version_text)
    except InvalidVersion:
        warnings.warn(
            f"Could not parse {label} version {version_text!r} under PEP 440; "
            "falling back to string comparison.",
            UserWarning,
            stacklevel=3,
        )
        return None


def _runtime_python_version() -> str:
    """Return the current runtime Python version string.

    Returns
    -------
    str
        ``major.minor.micro`` string for the active interpreter.
    """

    return f"{sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}"


def _validate_unsupported_tensors(raw_value: Any) -> list[dict[str, str]]:
    """Validate the ``unsupported_tensors`` manifest field.

    Parameters
    ----------
    raw_value:
        Raw decoded JSON value.

    Returns
    -------
    list[dict[str, str]]
        Validated unsupported tensor records.

    Raises
    ------
    TorchLensIOError
        If the value is not a list of string-only mappings.
    """

    if raw_value is None:
        return []
    if not isinstance(raw_value, list):
        raise TorchLensIOError("Manifest field 'unsupported_tensors' must be a list.")
    validated: list[dict[str, str]] = []
    for entry in raw_value:
        if not isinstance(entry, dict):
            raise TorchLensIOError("Manifest unsupported_tensors entries must be objects.")
        validated_entry: dict[str, str] = {}
        for key, value in entry.items():
            if not isinstance(key, str) or not isinstance(value, str):
                raise TorchLensIOError(
                    "Manifest unsupported_tensors entries must use string keys and values."
                )
            validated_entry[key] = value
        validated.append(validated_entry)
    return validated
