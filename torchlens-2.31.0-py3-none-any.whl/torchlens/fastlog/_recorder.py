"""Public Recorder context manager for fastlog sessions."""

from __future__ import annotations

from pathlib import Path
import time
import traceback as traceback_module
from types import TracebackType
from typing import Any, cast
import warnings

import torch
from torch import nn

from .._deprecations import MISSING, MissingType
from .._training_validation import TrainingModeConfigError, reject_compiled_model
from ..capture.projections import (
    RecordingState,
    _empty_recording,
    active_recording_state,
)
from ..capture.predicates import validate_followed_by_capability
from ..capture.config import InternalCaptureConfig
from ..capture.stop import StopDirective, stop_directive_for_trace
from ..capture.trace import _extract_and_mark_outputs
from ..data_classes.trace import Trace
from ..ir import CaptureEvents
from ..intervention.predicates import InterventionPredicate
from ..options import StreamingOptions
from ..types import ActivationPostfunc, GradientPostfunc
from ._halt import HaltSignal
from ._validation import validate_recording_options
from .exceptions import RecorderStateError
from .options import (
    GradPredicateFn,
    HaltPredicateFn,
    LookbackPayloadPolicy,
    PredicateErrorMode,
    PredicateFn,
    ForwardErrorMode,
    merge_recording_options,
)
from .types import CaptureSpec, Recording, _mark_recording_halted


def _rank_prefixed_streaming_options(
    streaming: StreamingOptions | None | MissingType,
) -> StreamingOptions | None | MissingType:
    """Return streaming options with a rank-local directory prefix.

    Parameters
    ----------
    streaming:
        Caller-supplied streaming options.

    Returns
    -------
    StreamingOptions | None | MissingType
        Options with ``bundle_path`` rewritten to include ``rank_NN`` when a
        bundle path is configured.
    """

    if isinstance(streaming, MissingType) or streaming is None or streaming.bundle_path is None:
        return streaming
    rank = 0
    if torch.distributed.is_available() and torch.distributed.is_initialized():
        rank = torch.distributed.get_rank()
    bundle_path = Path(streaming.bundle_path)
    return StreamingOptions(
        bundle_path=bundle_path.parent / f"rank_{rank:02d}" / bundle_path.name,
        retain_in_memory=streaming.retain_in_memory,
        out_callback=streaming.out_callback,
    )


def _resolve_save_alias(
    *,
    save: PredicateFn | None | MissingType,
    keep_op: PredicateFn | None | MissingType,
) -> PredicateFn | None | MissingType:
    """Resolve ``save=`` and deprecated ``keep_op=`` recorder predicates."""

    if save is not MISSING and keep_op is not MISSING:
        raise ValueError("Recorder received both save= and deprecated keep_op=.")
    if keep_op is not MISSING:
        warnings.warn(
            "Recorder(keep_op=...) is deprecated; use Recorder(save=...) instead.",
            DeprecationWarning,
            stacklevel=3,
        )
        return keep_op
    return save


def _unwrap_ddp_for_fastlog(
    model: nn.Module,
    streaming: StreamingOptions | None | MissingType,
) -> tuple[nn.Module, StreamingOptions | None | MissingType]:
    """Unwrap DDP/DataParallel wrappers for rank-local fastlog capture.

    Parameters
    ----------
    model:
        Candidate model supplied to fastlog.
    streaming:
        Caller-supplied streaming options.

    Returns
    -------
    tuple[nn.Module, StreamingOptions | None | MissingType]
        The model to execute and possibly rewritten streaming options.
    """

    try:
        from torch.distributed.fsdp import FullyShardedDataParallel
    except ImportError:
        pass
    else:
        if isinstance(model, FullyShardedDataParallel):
            raise RuntimeError(
                "torchlens.fastlog does not support FullyShardedDataParallel (FSDP): "
                "parameters are sharded across ranks and there is no unsharded module to log."
            )

    try:
        from torch.nn.parallel import DistributedDataParallel
    except ImportError:
        distributed_data_parallel: type[nn.Module] | None = None
    else:
        distributed_data_parallel = DistributedDataParallel

    if distributed_data_parallel is not None and isinstance(model, distributed_data_parallel):
        return cast(nn.Module, model.module), _rank_prefixed_streaming_options(streaming)
    if isinstance(model, nn.DataParallel):
        return cast(nn.Module, model.module), _rank_prefixed_streaming_options(streaming)
    return model, streaming


def _resolve_train_mode_default(
    *,
    field_name: str,
    value: bool | CaptureSpec | MissingType,
    backward_ready: bool,
) -> bool | CaptureSpec | MissingType:
    """Resolve one default capture option for train-mode sugar."""

    if backward_ready and value is MISSING:
        return CaptureSpec(keep_grad=True, save_out=True, save_metadata=True)
    if not backward_ready or value is MISSING or value is False:
        return value
    if value is True:
        raise TrainingModeConfigError(
            f"backward_ready=True conflicts with {field_name}=True because True uses "
            "keep_grad=False; use CaptureSpec(keep_grad=True) or omit the default"
        )
    if isinstance(value, CaptureSpec) and not value.keep_grad:
        raise TrainingModeConfigError(
            f"backward_ready=True conflicts with {field_name}=CaptureSpec(keep_grad=False)"
        )
    return value


class Recorder:
    """Context manager for explicitly captured fastlog forwards."""

    def __init__(
        self,
        model: nn.Module,
        *,
        save: PredicateFn | None | MissingType = MISSING,
        keep_op: PredicateFn | None | MissingType = MISSING,
        keep_module: PredicateFn | None | MissingType = MISSING,
        default_op: bool | CaptureSpec | MissingType = MISSING,
        default_module: bool | CaptureSpec | MissingType = MISSING,
        history_size: int | MissingType = MISSING,
        lookback: int | MissingType = MISSING,
        lookback_payload_policy: LookbackPayloadPolicy | MissingType = MISSING,
        include_source_events: bool | MissingType = MISSING,
        intervene: InterventionPredicate | None | MissingType = MISSING,
        halt: HaltPredicateFn | None | MissingType = MISSING,
        max_predicate_failures: int | MissingType = MISSING,
        on_predicate_error: PredicateErrorMode | MissingType = MISSING,
        on_forward_error: ForwardErrorMode | MissingType = MISSING,
        storage: StreamingOptions | None | MissingType = MISSING,
        streaming: StreamingOptions | None | MissingType = MISSING,
        random_seed: int | None | MissingType = MISSING,
        activation_transform: ActivationPostfunc | None | MissingType = MISSING,
        save_raw_activations: bool | MissingType = MISSING,
        save_grads: GradPredicateFn | bool | CaptureSpec | None | MissingType = MISSING,
        default_grad: bool | CaptureSpec | MissingType = MISSING,
        grad_transform: GradientPostfunc | None | MissingType = MISSING,
        save_raw_gradients: bool | MissingType = MISSING,
        backward_ready: bool = False,
    ) -> None:
        """Initialize a recorder and perform construction-time validation.

        Parameters
        ----------
        model:
            PyTorch module to record.
        save, keep_op, keep_module, default_op, default_module, history_size,
        lookback, lookback_payload_policy, include_source_events, max_predicate_failures,
        on_predicate_error, storage, streaming, random_seed:
            Fastlog recording options.
        on_forward_error:
            Controls failed-forward handling. ``"raise"`` preserves the
            historical behavior. ``"attach_partial"`` attaches a failed partial
            ``Recording`` to ``exc.partial_recording`` and re-raises.
            ``"return_partial"`` returns ``None`` from the failed ``log()`` and
            exposes the failed partial on ``recorder.recording``.
        halt:
            Optional predicate evaluated after each event's save decision. Returning
            ``True`` stops the active forward pass and marks the recording halted.
        activation_transform:
            Optional callable applied to each retained out copy after
            dtype/device transforms. The callable runs under ``pause_logging``
            and must return a ``torch.Tensor``. Errors are wrapped in
            :class:`torchlens.TorchLensPostfuncError`.
        save_raw_activations:
            When ``False`` and ``activation_transform`` is set, only the
            transformed payload is retained on the record. Defaults to
            ``True`` to mirror the slow path.
        backward_ready:
            If True, omitted defaults are promoted to ``CaptureSpec(keep_grad=True)``.
        """

        reject_compiled_model(model, api_name="torchlens.fastlog.Recorder")
        storage_supplied = storage is not MISSING and storage is not None
        streaming_supplied = streaming is not MISSING and streaming is not None
        if storage_supplied and streaming_supplied:
            raise TypeError("Do not pass both `storage` and `streaming`.")
        resolved_streaming = storage if storage_supplied else streaming
        keep_op = _resolve_save_alias(save=save, keep_op=keep_op)
        if keep_module is not MISSING:
            warnings.warn(
                "Recorder(keep_module=...) is deprecated; use Recorder(save=...) instead.",
                DeprecationWarning,
                stacklevel=2,
            )
        unwrapped_model, streaming = _unwrap_ddp_for_fastlog(model, resolved_streaming)
        default_op = _resolve_train_mode_default(
            field_name="default_op",
            value=default_op,
            backward_ready=backward_ready,
        )
        default_module = _resolve_train_mode_default(
            field_name="default_module",
            value=default_module,
            backward_ready=backward_ready,
        )
        self.model = unwrapped_model
        self.options = merge_recording_options(
            recording=None,
            keep_op=keep_op,
            keep_module=keep_module,
            default_op=default_op,
            default_module=default_module,
            history_size=history_size,
            lookback=lookback,
            lookback_payload_policy=lookback_payload_policy,
            include_source_events=include_source_events,
            intervene=intervene,
            halt=halt,
            max_predicate_failures=max_predicate_failures,
            on_predicate_error=on_predicate_error,
            on_forward_error=on_forward_error,
            streaming=streaming,
            random_seed=random_seed,
            activation_transform=activation_transform,
            save_raw_activations=save_raw_activations,
            save_grads=save_grads,
            default_grad=default_grad,
            grad_transform=grad_transform,
            save_raw_gradients=save_raw_gradients,
        )
        validate_recording_options(self.options)
        validate_followed_by_capability(
            self.options.keep_op,
            api_name="record(save=...)",
            supports_retroactive=False,
        )
        self._state: RecordingState | None = None
        self._recording: Recording | None = None
        self._capture_events: CaptureEvents | None = None
        self._output_tensors: list[torch.Tensor] = []
        self._output_tensor_addresses: list[str] = []
        self._entered = False
        self._exited = False
        self._failed = False
        self._next_pass_index = 1

    def __enter__(self) -> "Recorder":
        """Enter the recorder resource scope."""

        if self._entered or self._exited:
            raise RecorderStateError("Recorder cannot be re-entered")
        recording = _empty_recording(self.options)
        self._state = RecordingState(options=self.options, recording=recording)
        object.__setattr__(recording, "_recording_state", self._state)
        self._capture_events = CaptureEvents()
        self._entered = True
        return self

    def __exit__(
        self,
        exc_type: type[BaseException] | None,
        exc_value: BaseException | None,
        traceback: TracebackType | None,
    ) -> None:
        """Finalize or abort the recorder resource scope."""

        _ = exc_type, traceback
        if not self._entered or self._exited or self._state is None:
            raise RecorderStateError("Recorder is not active")
        if self._failed:
            self._entered = False
            self._exited = True
            return
        if exc_value is None:
            self._state.finalize_storage()
            session = type("_FastlogCaptureSession", (), {})()
            session.capture_events = self._capture_events
            session.output_tensors = self._output_tensors
            session.output_tensor_addresses = self._output_tensor_addresses
            session._fastlog_recording = self._state.recording
            session.recording_state = self._state
            self._recording = Recording.from_capture_events(session)
        else:
            self._state.abort_storage(str(exc_value))
        self._entered = False
        self._exited = True
        if exc_value is None:
            self._state.raise_accumulated_predicate_error()

    def log(
        self,
        input_args: Any,
        input_kwargs: dict[str, Any] | None = None,
        *,
        sample_id: str | int | None = None,
    ) -> Any:
        """Capture one forward pass and return the model output.

        Parameters
        ----------
        input_args:
            Tensor, tuple, or list of positional model inputs.
        input_kwargs:
            Optional keyword arguments for the model call.
        sample_id:
            Optional caller-provided sample identifier stored on event contexts.

        Returns
        -------
        Any
            Model forward output.
        """

        if not self._entered or self._exited or self._state is None:
            raise RecorderStateError("Recorder.log() requires an active with-block")
        if self._failed:
            raise RecorderStateError(
                "Recorder is in a failed state after a forward exception; "
                "create a new Recorder for further captures."
            )
        output = self._run_unified_capture(input_args, input_kwargs, sample_id=sample_id)
        self._next_pass_index += 1
        return output

    def _run_unified_capture(
        self,
        input_args: Any,
        input_kwargs: dict[str, Any] | None,
        *,
        sample_id: str | int | None,
    ) -> Any:
        """Run one unified predicate capture pass and retain CaptureEvents."""

        if self._state is None or self._capture_events is None:
            raise RecorderStateError("Recorder.log() requires an active with-block")
        trace = Trace(
            model_class_name=str(type(self.model).__name__),
            activation_transform=self.options.activation_transform,
            save_raw_activations=self.options.save_raw_activations,
            detach_saved_activations=False,
            backward_ready=True,
        )
        trace.capture_mode = "predicate"
        trace._fastlog_recording = self._state.recording
        trace._predicate_save_options = self.options
        trace._stop_directive = StopDirective(
            halt_options=self.options,
            raise_on_nan=False,
            forward_error_mode=self.options.on_forward_error,
            inference_only=False,
        )
        trace._capture_config = InternalCaptureConfig(
            capture_mode="predicate",
            layers_to_save=[],
            grad_layers_to_save=[],
            random_seed=self.options.random_seed,
            postprocess=False,
            stop=trace._stop_directive,
        )
        self._reset_state_for_pass(sample_id=sample_id)
        self._state.recording.start_times.append(time.time())
        try:
            with active_recording_state(self._state):
                output = trace._run_and_log_inputs_through_model(
                    self.model,
                    input_args,
                    input_kwargs,
                    layers_to_save=[],
                    grad_layers_to_save=[],
                    random_seed=self.options.random_seed,
                    postprocess=False,
                )
        except HaltSignal as halt_exc:
            self._carry_module_structure_events(trace)
            self._capture_events.extend(trace.capture_events.op_events)
            object.__setattr__(
                self._state.recording,
                "n_ops",
                max(self._state.recording.n_ops, self._next_pass_index),
            )
            self._mark_halted_pass(self._next_pass_index, halt_exc)
            output = None
            return output
        except Exception as exc:
            forward_disposition = stop_directive_for_trace(trace).forward_disposition(exc)
            if forward_disposition == "raise":
                self._state.abort_storage(str(exc))
                raise
            partial_build_failed = False
            try:
                partial = self._mark_recording_failed(trace, exc)
                self._failed = True
                self._recording = partial
                if forward_disposition == "attach_partial":
                    exc.partial_recording = partial  # type: ignore[attr-defined]
            except Exception:
                partial_build_failed = True
            if partial_build_failed:
                raise
            if forward_disposition == "attach_partial":
                raise
            return None
        finally:
            self._state.recording.end_times.append(time.time())
        # Output tensors are extracted+marked inside _run_and_log_inputs_through_model
        # (postprocess=False branch) BEFORE it cleans up model session metadata, so
        # buffer-output attribution isn't racing the label wipe. Read the stashed
        # scratch results back rather than re-extracting from the now-cleaned-up model.
        output_tensors = trace.__dict__.pop("_fastlog_output_tensors", None)
        output_tensor_addresses = trace.__dict__.pop("_fastlog_output_tensor_addresses", None)
        if output_tensors is None or output_tensor_addresses is None:
            # Defensive fallback only; the postprocess=False branch above always
            # populates these on a normal return.
            output_tensors, output_tensor_addresses = _extract_and_mark_outputs(trace, output)
        trace.__dict__.pop("_output_attribution_input_tensors", None)
        self._carry_module_structure_events(trace)
        self._capture_events.extend(trace.capture_events.op_events)
        trace.capture_events = self._capture_events
        trace._capture_events = self._capture_events
        self._state.runtime_trace = trace
        self._output_tensors = output_tensors
        self._output_tensor_addresses = output_tensor_addresses
        object.__setattr__(
            self._state.recording,
            "n_ops",
            max(self._state.recording.n_ops, self._next_pass_index),
        )
        return output

    def _carry_module_structure_events(self, trace: Trace) -> None:
        """Retain the pass's module prep/enter/exit events for ``to_trace()``.

        The predicate-capture per-pass ``trace`` created in
        :meth:`_run_unified_capture` owns its own ``CaptureEvents`` while the
        forward runs: model preparation emits one ``ModulePrepEvent`` per module
        (``backends/torch/model_prep.py``) onto it, carrying each module's real
        ``address_children`` / source metadata. The recorder then extends only
        ``op_events`` into its own longer-lived ``self._capture_events`` and
        reassigns ``trace.capture_events`` away, orphaning those prep events.

        ``Recording.to_trace()`` rebuilds a fresh ``Trace`` from exactly
        ``self._capture_events`` and runs the same postprocess pipeline as a live
        capture. Without the module prep events, ``_module_metadata`` stays empty
        and ``_build_root_module_log`` (postprocess finalization) falls back to
        deriving the root's ``address_children`` from ``top_level_modules`` --
        which is empty whenever every op's module stack starts at ``self`` --
        yielding a root ``Module`` with no ``address_children`` and a
        ``module_hierarchy`` invariant failure for any model with a submodule.

        Carry the real prep (and, for symmetry, any enter/exit) events across so
        ``to_trace()``'s materialize step applies them exactly as an exhaustive
        capture would. Guarded on emptiness so multi-pass recordings -- which
        re-prepare the model and re-emit identical prep events every pass -- keep
        a single, non-duplicated set.
        """

        if self._capture_events is None:
            return
        source = getattr(trace, "capture_events", None)
        if source is None or source is self._capture_events:
            return
        if not self._capture_events.module_prep_events:
            self._capture_events.module_prep_events.extend(source.module_prep_events)
        if not self._capture_events.module_enter_events:
            self._capture_events.module_enter_events.extend(source.module_enter_events)
        if not self._capture_events.module_exit_events:
            self._capture_events.module_exit_events.extend(source.module_exit_events)
        self._capture_events.pre_hook_events.extend(source.pre_hook_events)

    def _mark_halted_pass(self, pass_index: int, halt_exc: HaltSignal) -> None:
        """Persist halt state for the given pass."""

        if self._state is None:
            raise RecorderStateError("Recorder.log() requires an active with-block")
        _mark_recording_halted(self._state.recording, pass_index, halt_exc.reason)

    def _mark_recording_failed(self, trace: Trace, exc: BaseException) -> Recording:
        """Build and stamp a failed partial recording for a forward exception.

        Parameters
        ----------
        trace:
            Live trace whose predicate event stream contains the events captured
            before the exception.
        exc:
            Original forward exception. Only string metadata is copied from it.

        Returns
        -------
        Recording
            Failed partial recording. user-op failures exclude the failing call;
            TL-side capture failures may include a skipped/partial current-call
            event.
        """

        if self._state is None or self._capture_events is None:
            raise RecorderStateError("Recorder.log() requires an active with-block")
        self._state.abort_storage(str(exc))
        failed_events = getattr(trace, "_failed_fastlog_capture_events", None)
        if failed_events is None:
            raise RecorderStateError(
                "failed-capture event snapshot missing; cannot build a faithful partial"
            )
        combined_events = CaptureEvents()
        combined_events.extend(self._capture_events.op_events)
        combined_events.module_prep_events.extend(self._capture_events.module_prep_events)
        combined_events.module_enter_events.extend(self._capture_events.module_enter_events)
        combined_events.module_exit_events.extend(self._capture_events.module_exit_events)
        combined_events.pre_hook_events.extend(self._capture_events.pre_hook_events)
        if failed_events is not self._capture_events:
            combined_events.extend(failed_events.op_events)
            combined_events.pre_hook_events.extend(failed_events.pre_hook_events)
        self._capture_events = combined_events
        trace.capture_events = combined_events
        trace._capture_events = combined_events
        self._state.runtime_trace = trace
        session = type("_FastlogCaptureSession", (), {})()
        session.capture_events = self._capture_events
        session.output_tensors = []
        session.output_tensor_addresses = []
        session._fastlog_recording = self._state.recording
        session.recording_state = self._state
        recording = Recording.from_capture_events(session)
        self._stamp_failed_recording(recording, exc)
        return recording

    def _stamp_failed_recording(self, recording: Recording, exc: BaseException) -> None:
        """Stamp string-only failure metadata onto a frozen recording."""

        op_events = tuple(
            self._capture_events.op_events if self._capture_events is not None else ()
        )
        last_event = op_events[-1] if op_events else None
        last_ctx = getattr(last_event, "record_context", None)
        successful_op_labels = [
            str(getattr(event, "label_raw", getattr(event, "label", "")))
            for event in op_events
            if getattr(getattr(event, "record_context", None), "kind", None) == "op"
        ]
        object.__setattr__(recording, "status", "partial_error")
        object.__setattr__(recording, "failed", True)
        object.__setattr__(recording, "error_repr", repr(exc))
        object.__setattr__(
            recording,
            "error_traceback",
            "".join(traceback_module.format_exception(type(exc), exc, exc.__traceback__)),
        )
        object.__setattr__(recording, "n_ops_completed", len(successful_op_labels))
        object.__setattr__(
            recording,
            "last_successful_op_label",
            successful_op_labels[-1] if successful_op_labels else None,
        )
        object.__setattr__(
            recording,
            "last_event_label",
            None if last_ctx is None else str(getattr(last_ctx, "label", "")),
        )
        object.__setattr__(
            recording,
            "last_event_func",
            None if last_event is None else getattr(last_event, "func_name", None),
        )
        source_line = None if last_event is None else getattr(last_event, "source_line", None)
        object.__setattr__(
            recording, "last_event_source_line", str(source_line) if source_line else None
        )
        input_meta = None if last_ctx is None else getattr(last_ctx, "input_meta", None)
        object.__setattr__(
            recording,
            "last_event_input_meta",
            repr(input_meta) if input_meta is not None else None,
        )
        recoverable_path = self._recoverable_temp_bundle_path()
        if recoverable_path is not None:
            object.__setattr__(recording, "bundle_path", recoverable_path)

    def _recoverable_temp_bundle_path(self) -> Path | None:
        """Return the fastlog temp bundle path when it has a recoverable index."""

        if self._state is None:
            return None
        writer = getattr(self._state.storage_backend, "writer", None)
        tmp_path = getattr(writer, "tmp_path", None)
        if not isinstance(tmp_path, Path):
            return None
        if not (tmp_path / "fastlog_index.jsonl").exists():
            return None
        return tmp_path

    def _reset_state_for_pass(self, *, sample_id: str | int | None) -> None:
        """Reset per-pass predicate state while preserving accumulated events."""

        if self._state is None:
            raise RecorderStateError("Recorder.log() requires an active with-block")
        self._state.history.clear()
        self._state.op_counts.clear()
        self._state.module_stack.clear()
        self._state.sample_id = sample_id
        self._state.pass_index = self._next_pass_index
        self._state.event_index = 0
        self._state.step_index = 0

    def log_backward(
        self,
        loss: torch.Tensor,
        *,
        save_grads: (GradPredicateFn | bool | CaptureSpec | None) = None,
        default_grad: bool | CaptureSpec | None = None,
        retain_graph: bool | None = None,
        create_graph: bool = False,
    ) -> Recording:
        """Run backward for the active recorder and retain selected gradients."""

        if not self._entered or self._exited or self._state is None:
            raise RecorderStateError("Recorder.log_backward() requires an active with-block")
        self._state.recording.log_backward(
            loss,
            save_grads=save_grads,
            default_grad=default_grad,
            retain_graph=retain_graph,
            create_graph=create_graph,
        )
        return self._state.recording

    @property
    def recording(self) -> Recording:
        """Return the finalized recording after context-manager exit."""

        if self._recording is None:
            raise RecorderStateError("Recorder.recording is only available after __exit__")
        return self._recording
