"""Dry-run tracing API for fastlog predicates."""

from __future__ import annotations

import warnings
from typing import Any

from torch import nn

from .._input_coerce import _coerce_input_args
from ._recorder import Recorder
from .options import PredicateFn
from .types import RecordingTrace


def dry_run(
    model: nn.Module,
    input_args: Any,
    input_kwargs: dict[str, Any] | None = None,
    *,
    keep_op: PredicateFn | None = None,
    keep_module: PredicateFn | None = None,
    history_size: int = 8,
    include_source_events: bool = False,
    random_seed: int | None = None,
) -> RecordingTrace:
    """Run predicates over one forward pass without retaining tensor payloads.

    Parameters
    ----------
    model:
        PyTorch module to execute.
    input_args:
        Tensor, list, or tuple of positional model inputs.
    input_kwargs:
        Optional keyword arguments for the model call.
    keep_op, keep_module, history_size, include_source_events, random_seed:
        Fastlog dry-run options. Predicate exceptions propagate immediately.

    Returns
    -------
    RecordingTrace
        Chronological event contexts and any accumulated predicate failures.
    """

    input_args = _coerce_input_args(model, input_args)
    recorder_kwargs: dict[str, Any] = {
        "save": keep_op,
        "history_size": history_size,
        "include_source_events": include_source_events,
        "on_predicate_error": "fail-fast",
        "streaming": None,
        "random_seed": random_seed,
    }
    if keep_module is not None:
        recorder_kwargs["keep_module"] = keep_module

    with warnings.catch_warnings():
        warnings.filterwarnings(
            "ignore",
            r"Recorder\(keep_module=\.\.\.\) is deprecated; use Recorder\(save=\.\.\.\) instead\.",
            DeprecationWarning,
        )
        recorder_cm = Recorder(
            model,
            **recorder_kwargs,
        )

    with recorder_cm as recorder:
        if recorder._state is None:  # noqa: SLF001
            raise RuntimeError("Recorder state was not initialized")
        recorder._state.no_tensor_capture = True  # noqa: SLF001
        recorder.log(input_args, input_kwargs)
        contexts = tuple(recorder._state.all_contexts)  # noqa: SLF001
        kept_event_indexes = {
            record.ctx.event_index
            for record in recorder._state.recording.records  # noqa: SLF001
        }
        decisions = tuple(ctx.event_index in kept_event_indexes for ctx in contexts)
        failures = tuple(recorder._state.predicate_failures)  # noqa: SLF001
    return RecordingTrace(contexts=contexts, decisions=decisions, predicate_failures=failures)
