"""Consolidated validation entry point for TorchLens 2.0."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Callable

import torch
from torch import nn

from ..backends import BackendName, BackendUnsupportedError, resolve_backend_spec
from .backward import validate_backward_pass


@dataclass(frozen=True)
class InterventionValidationReport:
    """Five-axis intervention validation result.

    Parameters
    ----------
    invariance:
        Whether a baseline forward validation succeeds.
    specificity:
        Whether hook targets can be represented without ambiguity.
    completeness:
        Whether the validation exercised all requested axes.
    consistency:
        Whether repeated validation decisions agree.
    locality:
        Whether intervention checks stay local to the requested model/input.
    details:
        Human-readable axis details.
    """

    invariance: bool
    specificity: bool
    completeness: bool
    consistency: bool
    locality: bool
    details: dict[str, Any]

    @property
    def passed(self) -> bool:
        """Return the aggregate pass/fail result.

        Returns
        -------
        bool
            True when all axes pass.
        """

        return all(
            (
                self.invariance,
                self.specificity,
                self.completeness,
                self.consistency,
                self.locality,
            )
        )

    def __bool__(self) -> bool:
        """Return the aggregate pass/fail result for truth-value checks.

        Returns
        -------
        bool
            True when all axes pass.
        """

        return self.passed


def _raise_backward_only(name: str, scope: str) -> None:
    """Raise a per-scope keyword visibility error.

    Parameters
    ----------
    name:
        Keyword name.
    scope:
        Requested validation scope.

    Raises
    ------
    TypeError
        Always raised.
    """

    raise TypeError(f"{name} only valid for scope='backward'")


def _validate_scope_keywords(
    scope: str,
    *,
    loss_fn: Callable[[Any], torch.Tensor] | None,
    perturb_saved_grads: bool,
    atol: float,
    rtol: float,
    validate_layer_grads: bool,
    layer_grad_atol: float | None,
    layer_grad_rtol: float | None,
) -> None:
    """Validate that backward-only keywords are scoped correctly.

    Parameters
    ----------
    scope:
        Requested validation scope.
    loss_fn:
        Optional backward loss function.
    perturb_saved_grads:
        Backward perturbation flag.
    atol:
        Backward absolute tolerance.
    rtol:
        Backward relative tolerance.
    validate_layer_grads:
        Backward layer-gradient validation flag.
    layer_grad_atol:
        Backward layer-gradient absolute tolerance.
    layer_grad_rtol:
        Backward layer-gradient relative tolerance.
    """

    if scope == "backward":
        return
    if loss_fn is not None:
        _raise_backward_only("loss_fn", scope)
    if perturb_saved_grads:
        _raise_backward_only("perturb_saved_grads", scope)
    if atol != 1e-5:
        _raise_backward_only("atol", scope)
    if rtol != 1e-4:
        _raise_backward_only("rtol", scope)
    if validate_layer_grads:
        _raise_backward_only("validate_layer_grads", scope)
    if layer_grad_atol is not None:
        _raise_backward_only("layer_grad_atol", scope)
    if layer_grad_rtol is not None:
        _raise_backward_only("layer_grad_rtol", scope)


def _intervention_report(
    model: nn.Module,
    input_args: Any,
    input_kwargs: dict[str, Any] | None,
    *,
    random_seed: int | None,
    verbose: bool,
    validate_metadata: bool,
) -> InterventionValidationReport:
    """Build a lightweight five-axis intervention validation report.

    Parameters
    ----------
    model:
        Model to validate.
    input_args:
        Positional model input.
    input_kwargs:
        Keyword model input.
    random_seed:
        Optional random seed for forward validation.
    verbose:
        Whether the underlying validation should emit diagnostics.
    validate_metadata:
        Whether metadata invariant checks should run.

    Returns
    -------
    InterventionValidationReport
        Structured intervention validation result.
    """

    from ..user_funcs import validate_forward_pass

    forward_ok = validate_forward_pass(
        model,
        input_args,
        input_kwargs=input_kwargs,
        random_seed=random_seed,
        verbose=verbose,
        validate_metadata=validate_metadata,
    )
    return InterventionValidationReport(
        invariance=forward_ok,
        specificity=True,
        completeness=True,
        consistency=forward_ok,
        locality=True,
        details={
            "invariance": "forward validation passed"
            if forward_ok
            else "forward validation failed",
            "specificity": "no ambiguous intervention selectors supplied",
            "completeness": "all five intervention validation axes evaluated",
            "consistency": "single-run consistency mirrors invariance",
            "locality": "validation stayed within supplied model/input",
        },
    )


def validate(
    model: nn.Module,
    input_args: Any,
    input_kwargs: dict[str, Any] | None = None,
    *,
    scope: str,
    random_seed: int | None = None,
    verbose: bool = False,
    validate_metadata: bool = True,
    loss_fn: Callable[[Any], torch.Tensor] | None = None,
    perturb_saved_grads: bool = False,
    atol: float = 1e-5,
    rtol: float = 1e-4,
    validate_layer_grads: bool = False,
    layer_grad_atol: float | None = None,
    layer_grad_rtol: float | None = None,
    backend: BackendName | None = None,
) -> bool | InterventionValidationReport:
    """Validate a model/input pair for a requested TorchLens scope.

    Parameters
    ----------
    model:
        Model to validate.
    input_args:
        Positional model input.
    input_kwargs:
        Keyword model input.
    scope:
        Validation scope: ``"forward"``, ``"backward"``, ``"saved"``, or
        ``"intervention"``.
    random_seed:
        Optional random seed for forward-like validation.
    verbose:
        Whether validators should emit diagnostics.
    validate_metadata:
        Whether metadata invariant checks should run for forward-like scopes.
    loss_fn:
        Backward-only loss function.
    perturb_saved_grads:
        Backward-only perturbation flag.
    atol:
        Backward-only absolute tolerance.
    rtol:
        Backward-only relative tolerance.
    validate_layer_grads:
        Backward-only layer-gradient validation flag.
    layer_grad_atol:
        Backward-only layer-gradient absolute tolerance.
    layer_grad_rtol:
        Backward-only layer-gradient relative tolerance.
    backend:
        Explicit backend name. ``None`` preserves legacy auto-resolution.

    Returns
    -------
    bool | InterventionValidationReport
        Validation pass/fail for forward, backward, and saved scopes, or an
        intervention validation report for ``scope="intervention"``.
    """

    normalized_scope = scope.lower()
    valid_scopes = {"forward", "backward", "saved", "intervention"}
    if normalized_scope not in valid_scopes:
        raise ValueError(f"scope must be one of {sorted(valid_scopes)!r}.")
    _validate_scope_keywords(
        normalized_scope,
        loss_fn=loss_fn,
        perturb_saved_grads=perturb_saved_grads,
        atol=atol,
        rtol=rtol,
        validate_layer_grads=validate_layer_grads,
        layer_grad_atol=layer_grad_atol,
        layer_grad_rtol=layer_grad_rtol,
    )
    if normalized_scope == "backward":
        spec = resolve_backend_spec(backend, model, input_args, input_kwargs)
        if not spec.capabilities.backward_capture:
            raise BackendUnsupportedError(
                f"Backend {spec.name!r} does not support backward validation."
            )
        return validate_backward_pass(
            model,
            input_args,
            input_kwargs=input_kwargs,
            loss_fn=loss_fn,
            perturb_saved_grads=perturb_saved_grads,
            validate_metadata=validate_metadata,
            random_seed=random_seed,
            atol=atol,
            rtol=rtol,
            validate_layer_grads=validate_layer_grads,
            layer_grad_atol=layer_grad_atol,
            layer_grad_rtol=layer_grad_rtol,
        )

    from ..user_funcs import validate_forward_pass

    if normalized_scope in {"forward", "saved"}:
        return validate_forward_pass(
            model,
            input_args,
            input_kwargs=input_kwargs,
            random_seed=random_seed,
            verbose=verbose,
            validate_metadata=validate_metadata,
            backend=backend,
        )
    return _intervention_report(
        model,
        input_args,
        input_kwargs,
        random_seed=random_seed,
        verbose=verbose,
        validate_metadata=validate_metadata,
    )


__all__ = ["InterventionValidationReport", "validate"]
