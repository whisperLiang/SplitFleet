"""Human-readable formatting, print overrides, and environment detection.

Formatting helpers used by the display/print paths of Trace and Layer,
plus environment checks (Jupyter detection, parallel-processing guard).
"""

import multiprocessing as mp
import sys
import time
from collections.abc import Iterable
from contextlib import contextmanager
from typing import TYPE_CHECKING, Any, Iterator, List, TypeVar, cast

import torch

from ..quantities import Bytes, Flops

if TYPE_CHECKING:
    from ..data_classes.trace import Trace

_T = TypeVar("_T")


def _record_phase_timing(trace: "Trace", bucket: str, elapsed_s: float) -> None:
    """Accumulate one phase-timing sample on a trace.

    Parameters
    ----------
    trace:
        Trace receiving timing data.
    bucket:
        Stable timing bucket name.
    elapsed_s:
        Elapsed wall-clock seconds.
    """

    timings = trace.__dict__.setdefault("_phase_timings", {})
    bucket_stats = timings.setdefault(bucket, {"total_s": 0.0, "count": 0})
    bucket_stats["total_s"] += elapsed_s
    bucket_stats["count"] += 1


@contextmanager
def _timed_phase(trace: "Trace", bucket: str) -> Iterator[None]:
    """Record elapsed time for a capture or postprocess phase.

    Parameters
    ----------
    trace:
        Trace receiving timing data.
    bucket:
        Stable timing bucket name.

    Yields
    ------
    None
        Context body.
    """

    start = time.perf_counter()
    try:
        yield
    finally:
        _record_phase_timing(trace, bucket, time.perf_counter() - start)


def identity(x: Any) -> Any:
    """Return the input unchanged.

    Used as a no-op placeholder where a callable is expected (e.g.
    ``activation_transform`` when no user postprocessing is desired).
    """
    return x


def int_list_to_compact_str(int_list: List[int]) -> str:
    """Collapse a list of integers into a compact range string.

    Contiguous runs are collapsed into ``"start-end"`` ranges, separated
    by commas.  Example: ``[1, 2, 3, 7, 8, 10]`` becomes ``"1-3,7-8,10"``.

    Args:
        int_list: List of integers (need not be sorted).

    Returns:
        Compact string representation.
    """
    int_list = sorted(int_list)
    if len(int_list) == 0:
        return ""
    if len(int_list) == 1:
        return str(int_list[0])
    ranges = []
    start = int_list[0]
    end = int_list[0]
    for i in range(1, len(int_list)):
        if int_list[i] == end + 1:
            # Extend the current contiguous run.
            end = int_list[i]
        else:
            # Current run ended — flush it and start a new one.
            if start == end:
                ranges.append(str(start))
            else:
                ranges.append(f"{start}-{end}")
            start = int_list[i]
            end = int_list[i]
    # Flush the final run.
    if start == end:
        ranges.append(str(start))
    else:
        ranges.append(f"{start}-{end}")
    return ",".join(ranges)


def human_readable_size(size: float, decimal_places: int = 1) -> str:
    """Convert a byte count into a human-readable string (e.g. ``"1.5 MB"``).

    Args:
        size: Number of bytes.
        decimal_places: Number of decimal places for non-byte units.

    Returns:
        String with human-readable size and unit suffix.
    """
    if size < 0:
        raise ValueError("size must be non-negative.")
    if decimal_places == 1:
        return str(Bytes(size))
    return format(Bytes(size), f".{decimal_places}f")


def format_size(size: float, decimal_places: int = 1) -> str:
    """Format a byte count using binary units.

    Parameters
    ----------
    size:
        Number of bytes.
    decimal_places:
        Number of decimal places for KB and larger units.

    Returns
    -------
    str
        Human-readable byte string such as ``"1.2 MB"``.
    """

    return human_readable_size(size, decimal_places=decimal_places)


def format_flops(
    flops: float,
    decimal_places: int = 1,
    *,
    count_fma_as_two: bool = False,
) -> str:
    """Format a FLOP count using SI units.

    Parameters
    ----------
    flops:
        Number of floating-point operations.
    decimal_places:
        Number of decimal places for kilo-FLOPs and larger units.
    count_fma_as_two:
        Convention marker for callers that expose FLOP/MAC counting choices.
        The value does not rescale ``flops``; it records which convention the
        provided count already follows.

    Returns
    -------
    str
        Human-readable FLOP string such as ``"3.4 GFLOPs"``.
    """

    del count_fma_as_two
    if flops < 0:
        raise ValueError("flops must be non-negative.")
    if decimal_places == 1:
        return str(Flops(flops))
    return format(Flops(flops), f".{decimal_places}f")


def _format_number(value: float | None) -> str:
    """Format a compact tensor statistic value.

    Parameters
    ----------
    value:
        Numeric value or ``None`` for unavailable statistics.

    Returns
    -------
    str
        Compact display string.
    """

    if value is None:
        return "n/a"
    return f"{value:.4g}"


def _format_percent(value: float) -> str:
    """Format a percentage compactly.

    Parameters
    ----------
    value:
        Percent value in the range 0-100.

    Returns
    -------
    str
        Percentage string.
    """

    if value == 0:
        return "0%"
    if value < 0.1:
        return f"{value:.3g}%"
    if value < 10:
        return f"{value:.2g}%"
    return f"{value:.3g}%"


def _non_torch_array_summary(array: Any) -> str:
    """Return a backend-generic one-line summary for a non-``torch.Tensor`` array.

    Used for saved activations captured under a preview (non-torch) backend
    -- e.g. MLX, tinygrad, TensorFlow, JAX, Paddle -- whose array types do not
    share ``torch.Tensor``'s ``.device``/``grad_fn``/dtype-cast surface. Only
    duck-typed, near-universal attributes (``.shape``, ``.dtype``) are read;
    no torch-only numeric stats (mean/std/min/max/nan/inf/zero counts) are
    attempted, since those rely on torch-specific reductions that do not
    exist -- or behave differently -- across array libraries.

    Parameters
    ----------
    array:
        Non-torch array-like object to summarize.

    Returns
    -------
    str
        One-line summary with whatever shape/dtype information the object
        exposes. Never raises.
    """

    shape = getattr(array, "shape", None)
    if shape is not None:
        try:
            shape_text = "Tensor[" + ", ".join(str(dim) for dim in tuple(shape)) + "]"
        except TypeError:
            shape_text = f"Tensor[{shape}]"
    else:
        shape_text = "Tensor[?]"
    dtype = getattr(array, "dtype", None)
    dtype_text = str(dtype) if dtype is not None else "unknown dtype"
    return f"{shape_text} {dtype_text}"


def tensor_stats_summary(tensor: Any) -> str:
    """Return a lovely-style one-line tensor statistics summary.

    Parameters
    ----------
    tensor:
        Tensor to summarize. Non-``torch.Tensor`` arrays (saved activations
        from a preview backend such as MLX/tinygrad/TF/JAX/Paddle) are
        handled defensively via :func:`_non_torch_array_summary`: shape and
        dtype are reported when available and torch-only numeric stats are
        omitted, rather than raising ``AttributeError``. The ``torch.Tensor``
        path below is unchanged.

    Returns
    -------
    str
        One-line summary with shape, dtype, device, scalar stats, and
        NaN/Inf warning flags when present (torch tensors), or a reduced
        shape/dtype-only summary (non-torch arrays).
    """

    if not isinstance(tensor, torch.Tensor):
        return _non_torch_array_summary(tensor)

    shape = ", ".join(str(dim) for dim in tuple(tensor.shape))
    shape_text = f"Tensor[{shape}]" if shape else "Tensor[]"
    dtype_text = str(tensor.dtype).replace("torch.", "")
    prefix = f"{shape_text} {dtype_text} {tensor.device}"
    if tensor.numel() == 0:
        return f"{prefix} empty"

    try:
        work = tensor.detach()
        if work.is_complex():
            stat_tensor = work.abs().to(torch.float64)
            negative_percent = 0.0
        else:
            stat_tensor = work.to(torch.float64)
            negative_percent = float((stat_tensor < 0).sum().item()) / work.numel() * 100
        nan_percent = float(torch.isnan(stat_tensor).sum().item()) / work.numel() * 100
        inf_percent = float(torch.isinf(stat_tensor).sum().item()) / work.numel() * 100
        zero_percent = float((stat_tensor == 0).sum().item()) / work.numel() * 100
        finite = stat_tensor[torch.isfinite(stat_tensor)]
        if finite.numel() == 0:
            mean_value = std_value = min_value = max_value = None
        else:
            mean_value = float(finite.mean().item())
            std_value = float(finite.std(unbiased=False).item())
            min_value = float(finite.min().item())
            max_value = float(finite.max().item())
    except (RuntimeError, TypeError, ValueError):
        return prefix

    summary = (
        f"{prefix} mean={_format_number(mean_value)} std={_format_number(std_value)} "
        f"min={_format_number(min_value)} max={_format_number(max_value)} "
        f"nan={_format_percent(nan_percent)} inf={_format_percent(inf_percent)} "
        f"neg={_format_percent(negative_percent)} zero={_format_percent(zero_percent)}"
    )
    if nan_percent > 0:
        summary += f" [⚠ {_format_percent(nan_percent)} NaN]"
    if inf_percent > 0:
        summary += f" [⚠ {_format_percent(inf_percent)} Inf]"
    return summary


def progress_bar(
    iterable: Iterable[_T],
    *,
    total: int | None,
    desc: str,
    enabled: bool = True,
    threshold: int = 10,
) -> Iterable[_T]:
    """Wrap an iterable with an environment-appropriate progress bar.

    Parameters
    ----------
    iterable:
        Iterable to wrap.
    total:
        Total iteration count when known.
    desc:
        Progress-bar label.
    enabled:
        Whether the caller requested progress reporting.
    threshold:
        Minimum total count required before a progress bar is shown.

    Returns
    -------
    Iterable[_T]
        Original iterable or a tqdm-wrapped iterable.
    """

    if not enabled or total is None or total <= threshold:
        return iterable
    try:
        if in_notebook():
            from tqdm.notebook import tqdm

            return cast(Iterable[_T], tqdm(iterable, total=total, desc=desc))
        from tqdm import tqdm

        return cast(
            Iterable[_T],
            tqdm(iterable, total=total, desc=desc, disable=not sys.stderr.isatty()),
        )
    except ImportError:
        return iterable


def in_notebook() -> bool:
    """Return True if running inside a Jupyter notebook kernel.

    Checks for the IPython kernel app in the running IPython instance's
    config.  Returns False in plain Python, IPython terminal, or when
    IPython is not installed.
    """
    try:
        from IPython import get_ipython  # type: ignore[attr-defined]

        ipython = get_ipython()  # type: ignore[no-untyped-call]
        if ipython is None or "IPKernelApp" not in ipython.config:
            return False
    except (ImportError, AttributeError):
        return False
    return True


def _vprint(trace: "Trace", message: str) -> None:
    """Print a progress message if verbose mode is enabled on the Trace."""
    if getattr(trace, "verbose", False):
        print(f"[torchlens] {message}")


@contextmanager
def _vtimed(trace: "Trace", description: str) -> Iterator[None]:
    """Context manager that prints a timed progress message if verbose mode is enabled.

    Prints ``[torchlens] description...`` on entry, then appends `` done (X.XXs)``
    on exit.
    """
    bucket = f"postprocess:{description.strip()}"
    if not getattr(trace, "verbose", False):
        with _timed_phase(trace, bucket):
            yield
        return
    print(f"[torchlens] {description}...", end="", flush=True)
    start = time.perf_counter()
    try:
        yield
    finally:
        elapsed = time.perf_counter() - start
        _record_phase_timing(trace, bucket, elapsed)
        print(f" done ({elapsed:.2f}s)")


def warn_parallel() -> None:
    """Raise ``RuntimeError`` if called from a child process.

    TorchLens is single-threaded by design — its global toggle state and
    ordered tensor counter are not safe for concurrent access.  This guard
    is called early in ``trace`` to fail fast rather than
    produce silently corrupted logs.
    """
    if mp.current_process().name != "MainProcess":
        raise RuntimeError(
            "WARNING: It looks like you are using parallel execution; only run "
            "torchlens in the main process, since certain operations "
            "depend on execution order."
        )
