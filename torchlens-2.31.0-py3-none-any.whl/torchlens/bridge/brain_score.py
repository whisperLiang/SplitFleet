"""Brain-Score bridge helpers."""

from __future__ import annotations

from collections.abc import Iterable
from typing import Any

from ._utils import tensor_layers


def per_layer(
    log: Any,
    benchmark: Any,
    *,
    sites: Iterable[Any] | None = None,
    **kwargs: Any,
) -> dict[str, Any]:
    """Run a Brain-Score-style benchmark independently for saved layers.

    This offline adapter accepts a callable benchmark fixture so tests can run
    without network access or GUI resources.

    Parameters
    ----------
    log:
        TorchLens ``Trace`` containing saved outs.
    benchmark:
        Callable benchmark accepting ``(out, layer=..., **kwargs)``.
    sites:
        Optional iterable of layer labels/selectors to score. Defaults to all
        saved tensor layers except input placeholders.
    **kwargs:
        Additional benchmark keyword arguments.

    Returns
    -------
    dict[str, Any]
        Mapping from TorchLens layer label to benchmark score.

    Raises
    ------
    TypeError
        If ``benchmark`` is not callable.
    """

    if not callable(benchmark):
        raise TypeError("Brain-Score bridge currently requires a callable offline benchmark.")

    scores: dict[str, Any] = {}
    for layer in tensor_layers(log, sites):
        out = getattr(layer, "out")
        label = str(getattr(layer, "layer_label", "layer"))
        # TODO: connect the real Brain-Score Benchmark API once the offline
        # vendored fixtures are available in the launch extras matrix.
        scores[label] = benchmark(out, layer=label, **kwargs)
    return scores


__all__ = ["per_layer"]
