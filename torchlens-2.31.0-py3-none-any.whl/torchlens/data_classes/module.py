"""Structured per-module metadata: ModuleCall, Module, ModuleAccessor.

Three-level hierarchy:

* **ModuleCall** -- one invocation of one module (lightweight container).
  Stores ``ops`` as pass-qualified labels (e.g. ``"conv2d_1_1:1"``),
  pointing to individual Op entries.

* **Module** -- aggregate metadata for one ``nn.Module`` across all its
  invocations.  Stores ``layer_labels`` as no-pass labels (e.g.
  ``"conv2d_1_1"``), pointing to aggregate Layer entries.
  For single-pass modules, per-pass fields are delegated to ``ops[0]``
  via ``_single_pass_or_error()``.

* **ModuleAccessor** -- dict-like accessor returned by ``trace.modules``.
  Supports lookup by module address, alias (shared modules), pass label,
  or ordinal index.

Module vs ModuleCall label convention:
  - Module.layer_labels stores **no-pass** labels -> Layer
  - ModuleCall.ops stores **pass-qualified** labels -> Op
This matches each accessor's natural granularity.
"""

import weakref
from collections.abc import Iterator
from dataclasses import dataclass
from typing import (
    TYPE_CHECKING,
    Any,
    ClassVar,
    Dict,
    List,
    Optional,
    TextIO,
    Union,
    cast,
)

import torch

from .._errors import AmbiguousOpLookupError
from .._io import (
    FieldPolicy,
    TLSPEC_VERSION,
    coerce_container_typed_state,
    default_fill_state,
    read_tlspec_version,
)
from ..constants import LAYER_LOG_FIELD_ORDER, MODULE_LOG_FIELD_ORDER, MODULE_PASS_LOG_FIELD_ORDER
from ..quantities import Bytes, Duration, Flops, Macs
from ._accessor_base import Accessor
from .field_policy import build_record_field_policy_table, portable_state_spec_from_policy
from .layer import _layer_log_to_row
from ._runtime_handles import runtime_handle_from_trace
from ._repr import format_summary_lines

if TYPE_CHECKING:
    import pandas as pd

    from .buffer import BufferAccessor
    from .func_call_location import FuncCallLocation
    from .op import Op
    from .param import ParamAccessor
    from .trace import Trace
    from ..ir.container import ContainerSpec
    from .prehook import ModuleInputSnapshot, PreHookEffect


# Module fields deliberately omitted from ``ModuleAccessor.to_pandas()`` columns.
# Every field in ``MODULE_LOG_FIELD_ORDER`` must either appear as a dataframe
# column or be listed here -- ``tests/test_to_pandas_field_coverage.py``
# enforces this so new Module fields can never silently fail to reach the
# module table again (same regression class as TO-PANDAS-NEW-FIELDS).
_TO_PANDAS_EXCLUDED_MODULE_FIELDS: frozenset[str] = frozenset(
    {
        # Non-instantiable / live class object (not a scalar table cell):
        "cls",
        # Live rich accessors and object references, not scalar table cells:
        "ops",  # ModuleCallAccessor -- use trace.module_calls for per-pass rows
        "layers",  # list[Layer] -- use trace.layers.to_pandas() for per-layer rows
        "params",  # ParamAccessor -- use trace.params.to_pandas()
        "recursive_params",  # ParamAccessor -- same as params
        "call_parent_module",  # Module reference -- call_parent already carries the label
        "call_children_modules",  # list[Module] -- call_children already carries the labels
        "output_structure",  # ContainerSpec -- structural, not a flat scalar
        "forward_args_template",  # arbitrary structural template, not a flat scalar
        "forward_kwargs_template",  # arbitrary structural template, not a flat scalar
        # Hook lists (callables/handles, not scalar table cells):
        "forward_pre_hooks",
        "forward_hooks",
        "backward_pre_hooks",
        "backward_hooks",
        "full_backward_pre_hooks",
        "full_backward_hooks",
        # Arbitrary user-selected payload (parallel to Op.annotations exclusion):
        "custom_attributes",
    }
)


# Per-call fields that ``Module`` resolves via ``_single_pass_or_error``: they
# describe ONE forward pass and deliberately raise ``AttributeError`` on a
# multi-call Module (directing the user to a specific ``module.ops[i]`` pass).
# The field-order-driven table cannot let that raise, so it reports them as None
# for multi-call Modules -- mirroring ``Module.output_structure``, which already
# returns None for multi-call Modules. The ``total_*`` sibling columns carry the
# multi-call aggregate, so no information is lost.
_MULTI_CALL_PER_PASS_MODULE_FIELDS: frozenset[str] = frozenset(
    {
        "forward_args_summary",
        "forward_kwargs_summary",
        "forward_duration",
        "func_calls_duration",
    }
)


def _module_log_to_row(module_log: "Module") -> Dict[str, Any]:
    """Convert a Module into one DataFrame row.

    Parameters
    ----------
    module_log:
        Module metadata entry to export.

    Returns
    -------
    Dict[str, Any]
        Mapping from canonical field name to exported value, excluding the
        fields in ``_TO_PANDAS_EXCLUDED_MODULE_FIELDS``. Per-pass fields
        (``_MULTI_CALL_PER_PASS_MODULE_FIELDS``) are reported as ``None`` for
        multi-call Modules so the table never drops a column nor raises.
    """

    multi_call = module_log.num_calls > 1
    row: Dict[str, Any] = {}
    for field_name in MODULE_LOG_FIELD_ORDER:
        if field_name in _TO_PANDAS_EXCLUDED_MODULE_FIELDS:
            continue
        if multi_call and field_name in _MULTI_CALL_PER_PASS_MODULE_FIELDS:
            row[field_name] = None
            continue
        row[field_name] = getattr(module_log, field_name)
    return row


class ModuleCallAccessor(Accessor["ModuleCall"]):
    """Scoped dict-like accessor for ModuleCall entries owned by a Module."""

    PORTABLE_STATE_SPEC: ClassVar[dict[str, FieldPolicy]] = {
        "_dict": FieldPolicy.KEEP,
        "_list": FieldPolicy.KEEP,
        "_source_ref": FieldPolicy.WEAKREF_STRIP,
    }

    def __init__(self, calls: Dict[int, "ModuleCall"] | None = None) -> None:
        """Initialize the accessor.

        Parameters
        ----------
        calls:
            Mapping from 1-based call index to ModuleCall.
        """

        calls = calls or {}
        super().__init__(calls, item_list=[call for _, call in sorted(calls.items())])

    def __getitem__(self, key: int | str) -> "ModuleCall":
        """Return a ModuleCall by 0-based position or call label."""

        if isinstance(key, int):
            return self._list[key]
        resolved = self._resolve_substring(key)
        if resolved is not None:
            return resolved
        raise KeyError(f"Module call '{key}' not found in scoped calls.")

    def __setitem__(self, key: int, value: "ModuleCall") -> None:
        """Set a ModuleCall by 1-based call index."""

        self._dict[key] = value
        self._list = [call for _, call in sorted(self._dict.items())]

    def __contains__(self, key: object) -> bool:
        """Return whether key resolves to a ModuleCall."""

        if isinstance(key, int):
            return -len(self._list) <= key < len(self._list)
        if isinstance(key, str):
            try:
                self[key]
            except (KeyError, ValueError):
                return False
            return True
        return False

    # This scoped accessor intentionally iterates call-index keys, unlike the generic
    # Trace-level accessors that iterate log values.
    def __iter__(self) -> Iterator[int]:  # type: ignore[override]
        """Iterate call-index keys."""

        return iter(self._dict)

    def get(self, key: int, default: "ModuleCall | None" = None) -> "ModuleCall | None":
        """Return a ModuleCall by call index, or default."""

        return self._dict.get(key, default)

    def _resolve_substring(self, key: str) -> "ModuleCall | None":
        """Resolve a ModuleCall by exact call label or unique parent address."""
        if len(self._dict) == 1:
            only_call = next(iter(self._dict.values()))
            if key == only_call.address:
                return only_call
        for call in self._dict.values():
            if key == call.call_label:
                return call
        parent_matches = [call for call in self._dict.values() if key == call.address]
        if len(parent_matches) > 1:
            raise AmbiguousOpLookupError(
                f"Module '{key}' has {len(parent_matches)} calls. Use a 0-based integer "
                f"position or a call-qualified label like '{key}:1'."
            )
        return None


@dataclass
class HookInfo:
    """Metadata for one PyTorch module hook."""

    name: str = ""
    qualname: str = ""
    source_location: "FuncCallLocation | None" = None


def _display_call_label(call: "ModuleCall", show_call_index: bool) -> str:
    """Return the display label for a ModuleCall.

    Parameters
    ----------
    call:
        ModuleCall to display.
    show_call_index:
        Whether to include the ``:N`` call suffix.

    Returns
    -------
    str
        Display-ready call label.
    """

    if show_call_index:
        return call.call_label
    return call.call_label.rsplit(":", 1)[0]


def _module_call_summary(call: "ModuleCall") -> str:
    """Return a compact optional summary for a ModuleCall display row.

    Parameters
    ----------
    call:
        ModuleCall to summarize.

    Returns
    -------
    str
        Parenthesized summary, or an empty string.
    """

    duration = getattr(call, "forward_duration", None)
    if duration is None:
        return ""
    return f" (forward_duration: {duration})"


def _is_atomic_module_call(call: "ModuleCall") -> bool:
    """Return whether a ModuleCall represents an atomic module leaf.

    Parameters
    ----------
    call:
        ModuleCall to inspect.

    Returns
    -------
    bool
        ``True`` when one of the call's output Ops is marked atomic.
    """

    trace = call._source_trace
    if trace is None:
        return False
    return any(
        getattr(op, "is_atomic_module", False)
        for op_label in call.output_ops
        for op in _resolve_call_ops(trace, op_label)
    )


def _resolve_call_ops(trace: "Trace", label: str) -> list["Op"]:
    """Resolve a ModuleCall op-slot label to its Op object(s).

    Submodule calls store pass-qualified Op labels, each resolving to exactly
    one Op (unchanged behavior). The root ``self:1`` call stores bare Layer
    labels (per the function-root-module invariant), and a recurrent
    (multi-pass) Layer label resolves to EVERY one of its pass Ops. Aggregate
    ModuleCall properties sum/iterate over the resolved Ops so the root
    aggregate correctly spans all passes without a caller ever hitting the
    ``AmbiguousOpLookupError`` that plain ``trace.ops[layer_label]`` raises.
    """

    return trace.ops.resolve_all(label)


def _edge_counts_for_scope(trace: "Trace | None", op_labels: List[str]) -> tuple[int, int, int]:
    """Count internal, input, and output graph edges for a scoped op set.

    Parameters
    ----------
    trace:
        Owning Trace used to resolve Op labels.
    op_labels:
        Pass-qualified labels for Ops in the scope.

    Returns
    -------
    tuple[int, int, int]
        ``(internal_edges, input_edges, output_edges)`` with distinct
        ``(parent, child)`` pairs.
    """

    if trace is None:
        return 0, 0, 0

    scope = {op.label for label in op_labels for op in _resolve_call_ops(trace, label)}
    internal_edges: set[tuple[str, str]] = set()
    input_edges: set[tuple[str, str]] = set()
    output_edges: set[tuple[str, str]] = set()

    for parent_label in scope:
        parent = trace.ops[parent_label]
        for child_label in parent.children:
            canonical_child_label = trace.ops[child_label].label
            edge = (parent_label, canonical_child_label)
            if canonical_child_label in scope:
                internal_edges.add(edge)
            else:
                output_edges.add(edge)
        for inbound_label in parent.parents:
            canonical_inbound_label = trace.ops[inbound_label].label
            if canonical_inbound_label not in scope:
                input_edges.add((canonical_inbound_label, parent_label))

    return len(internal_edges), len(input_edges), len(output_edges)


def _visible_call_children(call: "ModuleCall", include_atomic: bool) -> list["ModuleCall"]:
    """Return displayable child ModuleCalls for ``call``.

    Parameters
    ----------
    call:
        Parent ModuleCall.
    include_atomic:
        Whether to include atomic module leaves.

    Returns
    -------
    list[ModuleCall]
        Displayable children in call-tree order.
    """

    trace = call._source_trace
    if trace is None:
        raise RuntimeError("ModuleCall not bound to a Trace")
    children = [trace.module_calls[child_label] for child_label in call.call_children]
    if include_atomic:
        return children
    return [child for child in children if not _is_atomic_module_call(child)]


def _print_call_tree_from_root(
    call: "ModuleCall",
    *,
    max_depth: int | None,
    include_atomic: bool,
    show_call_index: bool,
    file: TextIO | None,
) -> None:
    """Print a ModuleCall subtree as an ASCII tree.

    Parameters
    ----------
    call:
        Root ModuleCall to print.
    max_depth:
        Maximum descendant depth to print, or ``None`` for no limit.
    include_atomic:
        Whether to include atomic module leaves.
    show_call_index:
        Whether to include the ``:N`` call suffix.
    file:
        Optional output stream.
    """

    def print_node(node: "ModuleCall", prefix: str, is_last: bool, depth: int) -> None:
        """Print one node and its descendants."""

        connector = "" if depth == 0 else ("└── " if is_last else "├── ")
        label = _display_call_label(node, show_call_index)
        print(f"{prefix}{connector}{label}{_module_call_summary(node)}", file=file)

        children = _visible_call_children(node, include_atomic)
        if max_depth is not None and depth >= max_depth:
            if children:
                child_prefix = prefix if depth == 0 else prefix + ("    " if is_last else "│   ")
                print(f"{child_prefix}└── ...", file=file)
            return

        child_prefix = prefix if depth == 0 else prefix + ("    " if is_last else "│   ")
        for index, child in enumerate(children):
            print_node(child, child_prefix, index == len(children) - 1, depth + 1)

    print_node(call, "", True, 0)


def _module_call_log_to_row(module_call_log: "ModuleCall") -> Dict[str, Any]:
    """Convert a ModuleCall into one DataFrame row.

    Parameters
    ----------
    module_call_log:
        Module-pass metadata entry to export.

    Returns
    -------
    Dict[str, Any]
        Mapping from canonical field name to exported value.
    """
    row = {field: getattr(module_call_log, field) for field in MODULE_PASS_LOG_FIELD_ORDER}
    row["output_ops"] = list(module_call_log.output_ops)
    row["output_structure"] = (
        repr(module_call_log.output_structure)
        if module_call_log.output_structure is not None
        else None
    )
    return row


# Typed container defaults for every non-Optional container field ModuleCall
# stores directly. Same defect class as
# `Op._LAYER_PASS_LOG_CONTAINER_DEFAULTS`/`Trace._MODEL_LOG_CONTAINER_DEFAULTS`:
# without this, `coerce_container_typed_state` cannot repair a
# present-but-wrong-typed legacy value, and an absent field crashes instead of
# restoring an empty typed container. Plain builtin types are used
# deliberately.
_MODULE_CALL_CONTAINER_DEFAULTS: dict[str, Any] = {
    "all_addresses": [],
    "ops": [],
    "input_ops": [],
    "input_layers": [],
    "output_ops": [],
    "output_layers": [],
    "output_paths": (),
    "forward_arg_names": [],
    "code_context": [],
    "module_call_stack": [],
    "call_children": [],
    "forward_pre_hook_effects": (),
}


@dataclass(init=False)
class ModuleCall:
    """Per-(module, call_index) data for one invocation of a module.

    Lightweight container holding the list of layers computed during
    this particular invocation, the captured forward arguments, and
    the call-graph edges (parent/children in the module invocation tree).

    ``ops`` stores **pass-qualified** labels (e.g. ``"conv2d_1_1:1"``)
    that resolve to individual Op entries.
    """

    PORTABLE_STATE_SPEC: ClassVar[dict[str, FieldPolicy]] = {
        "address": FieldPolicy.KEEP,
        "all_addresses": FieldPolicy.KEEP,
        "class_name": FieldPolicy.KEEP,
        "class_qualname": FieldPolicy.KEEP,
        "cls": FieldPolicy.DROP,
        "call_index": FieldPolicy.KEEP,
        "call_label": FieldPolicy.KEEP,
        "ordinal_index": FieldPolicy.KEEP,
        "ops": FieldPolicy.KEEP,
        "input_ops": FieldPolicy.KEEP,
        "input_layers": FieldPolicy.KEEP,
        "output_ops": FieldPolicy.KEEP,
        "output_layers": FieldPolicy.KEEP,
        "output_structure": FieldPolicy.KEEP,
        "output_paths": FieldPolicy.KEEP,
        "forward_args": FieldPolicy.BLOB_RECURSIVE,
        "forward_kwargs": FieldPolicy.BLOB_RECURSIVE,
        "inputs_before_pre_hooks": FieldPolicy.KEEP,
        "inputs_after_pre_hooks": FieldPolicy.KEEP,
        "forward_pre_hook_effects": FieldPolicy.KEEP,
        "forward_arg_names": FieldPolicy.KEEP,
        "num_forward_args_total": FieldPolicy.KEEP,
        "num_forward_pos_args": FieldPolicy.KEEP,
        "num_forward_kwargs": FieldPolicy.KEEP,
        "forward_args_summary": FieldPolicy.KEEP,
        "forward_kwargs_summary": FieldPolicy.KEEP,
        "forward_args_template": FieldPolicy.DROP,
        "forward_kwargs_template": FieldPolicy.DROP,
        "_forward_args_template": FieldPolicy.DROP,
        "_forward_kwargs_template": FieldPolicy.DROP,
        "forward_duration": FieldPolicy.KEEP,
        "code_context": FieldPolicy.KEEP,
        "module_call_stack": FieldPolicy.KEEP,
        "call_parent": FieldPolicy.KEEP,
        "call_children": FieldPolicy.KEEP,
        "_source_trace_strong": FieldPolicy.DROP,
        "_source_trace_ref": FieldPolicy.WEAKREF_STRIP,
    }
    FIELD_POLICY = build_record_field_policy_table(MODULE_PASS_LOG_FIELD_ORDER, PORTABLE_STATE_SPEC)
    PORTABLE_STATE_SPEC = portable_state_spec_from_policy(FIELD_POLICY)

    address: str
    all_addresses: List[str]
    cls: type[Any] | None
    class_name: str
    class_qualname: str
    call_index: int
    call_label: str
    ordinal_index: int
    ops: List[str]
    input_ops: List[str]
    input_layers: List[str]
    output_ops: List[str]
    output_layers: List[str]
    output_structure: "ContainerSpec | None"
    output_paths: tuple[tuple[Any, ...], ...]
    forward_args: tuple[Any, ...] | None
    forward_kwargs: dict[str, Any] | None
    inputs_before_pre_hooks: "ModuleInputSnapshot | None"
    inputs_after_pre_hooks: "ModuleInputSnapshot | None"
    forward_pre_hook_effects: tuple["PreHookEffect", ...]
    forward_arg_names: List[str]
    num_forward_args_total: int
    num_forward_pos_args: int
    num_forward_kwargs: int
    forward_args_summary: str
    forward_kwargs_summary: str
    forward_duration: Duration
    code_context: List["FuncCallLocation"]
    module_call_stack: List[str]
    call_parent: Optional[str]
    call_children: List[str]

    def __init__(
        self,
        address: str,
        call_index: int,
        call_label: str,
        ops: List[str],
        input_layers: List[str],
        output_layers: List[str],
        output_ops: List[str] | None = None,
        output_structure: "ContainerSpec | None" = None,
        output_paths: tuple[tuple[Any, ...], ...] | None = None,
        forward_args: tuple[Any, ...] | None = None,
        forward_kwargs: dict[str, Any] | None = None,
        inputs_before_pre_hooks: "ModuleInputSnapshot | None" = None,
        inputs_after_pre_hooks: "ModuleInputSnapshot | None" = None,
        forward_pre_hook_effects: tuple["PreHookEffect", ...] | None = None,
        forward_args_template: Any = None,
        forward_kwargs_template: Any = None,
        forward_arg_names: List[str] | None = None,
        forward_duration: float = 0.0,
        code_context: List["FuncCallLocation"] | None = None,
        module_call_stack: List[str] | None = None,
        call_parent: Optional[str] = None,
        call_children: Optional[List[str]] = None,
        all_addresses: Optional[List[str]] = None,
        cls: type[Any] | None = None,
        class_name: str = "",
        class_qualname: str = "",
        ordinal_index: int = 0,
        _source_trace: "Trace | None" = None,
    ) -> None:
        """Initialize metadata for one module forward call.

        Parameters
        ----------
        address:
            Module address in the owning model.
        call_index:
            Zero-based invocation index for this module address.
        call_label:
            Pass-qualified module call label.
        ops:
            Operation labels executed inside this module call.
        input_layers:
            Input layer labels for this call.
        output_layers:
            Output layer labels for this call.
        output_ops:
            Output operation labels for this call.
        output_structure:
            Container structure describing module outputs.
        output_paths:
            Container paths for tensor outputs.
        forward_args:
            Positional arguments observed at module entry.
        forward_kwargs:
            Keyword arguments observed at module entry.
        inputs_before_pre_hooks:
            Provisional public field containing inputs as passed to ``Module.__call__``.
        inputs_after_pre_hooks:
            Provisional public field containing the logical state after user pre-hooks.
        forward_pre_hook_effects:
            Provisional public field containing one effect per executed user pre-hook.
        forward_args_template:
            Serializable template for positional arguments.
        forward_kwargs_template:
            Serializable template for keyword arguments.
        forward_arg_names:
            Argument names resolved for the module forward signature.
        forward_duration:
            Runtime duration of the module call in seconds.
        code_context:
            Source locations associated with the module call.
        module_call_stack:
            Module call stack active for this call.
        call_parent:
            Parent module call label, if any.
        call_children:
            Child module call labels.
        all_addresses:
            All model addresses that reference this same module object.
        cls:
            Live module class when available.
        class_name:
            Module class name.
        class_qualname:
            Qualified module class name.
        ordinal_index:
            Position of this module call in execution order.
        _source_trace:
            Owning trace used for live accessors.
        """

        self.address = address
        self.all_addresses = all_addresses if all_addresses is not None else [address]
        self.cls = cls
        self.class_name = class_name
        self.class_qualname = class_qualname
        self.call_index = call_index
        self.call_label = call_label  # e.g. "features.0:1"
        self.ordinal_index = ordinal_index
        self.ops = ops  # pass-qualified Op labels
        self.input_layers = input_layers
        self.output_layers = output_layers
        self.input_ops = list(input_layers)
        self.output_ops = output_ops if output_ops is not None else list(output_layers)
        self.output_structure = output_structure
        self.output_paths = output_paths if output_paths is not None else ()
        self.forward_args = forward_args
        self.forward_kwargs = forward_kwargs
        self.inputs_before_pre_hooks = inputs_before_pre_hooks
        self.inputs_after_pre_hooks = inputs_after_pre_hooks
        self.forward_pre_hook_effects = (
            forward_pre_hook_effects if forward_pre_hook_effects is not None else ()
        )
        self.forward_arg_names = forward_arg_names if forward_arg_names is not None else []
        self.num_forward_pos_args = len(forward_args) if forward_args is not None else 0
        self.num_forward_kwargs = len(forward_kwargs) if forward_kwargs is not None else 0
        self.num_forward_args_total = self.num_forward_pos_args + self.num_forward_kwargs
        self.forward_args_summary = ""
        self.forward_kwargs_summary = ""
        self.forward_args_template = forward_args_template
        self.forward_kwargs_template = forward_kwargs_template
        self.forward_duration = Duration(forward_duration)
        self.code_context = code_context if code_context is not None else []
        self.module_call_stack = module_call_stack if module_call_stack is not None else []
        self.call_parent = call_parent
        self.call_children = call_children if call_children is not None else []
        self._source_trace_ref = weakref.ref(_source_trace) if _source_trace is not None else None

    @property
    def module(self) -> "Module":
        """Return the Module record invoked by this call."""

        trace = self._source_trace
        if trace is None:
            raise RuntimeError("ModuleCall not bound to a Trace")
        return cast("Module", trace.modules[self.address])

    @property
    def num_layers(self) -> int:
        """Number of layers in this pass."""
        return len(self.ops)

    @property
    def num_ops(self) -> int:
        """Number of Ops in this module call."""

        return len(self.ops)

    @property
    def name(self) -> str:
        """Return the final segment of the primary module-call address.

        Returns
        -------
        str
            Module name within its parent module.
        """

        return "" if self.address == "self" else self.address.rsplit(".", 1)[-1]

    @property
    def has_multiple_addresses(self) -> bool:
        """Whether this module appears at multiple addresses."""
        return len(self.all_addresses) > 1

    @property
    def has_saved_forward_args(self) -> bool:
        """Whether forward arguments were captured for this module call."""

        return self.forward_args is not None or self.forward_kwargs is not None

    @property
    def had_pre_hook_input_change(self) -> bool | None:
        """Return whether any user pre-hook changed effective module inputs.

        This public name is provisional pending the TorchLens human naming
        session. ``None`` means at least one executed transition lacked enough
        evidence to claim that no change occurred.
        """

        if any(effect.changed is True for effect in self.forward_pre_hook_effects):
            return True
        if any(effect.changed is None for effect in self.forward_pre_hook_effects):
            return None
        return False

    @property
    def forward_args_template(self) -> Any:
        """Structural template for positional forward arguments at this call."""

        return self.__dict__.get("_forward_args_template")

    @forward_args_template.setter
    def forward_args_template(self, value: Any) -> None:
        """Set the structural template for positional forward arguments."""

        self.__dict__["_forward_args_template"] = value

    @property
    def forward_kwargs_template(self) -> Any:
        """Structural template for keyword forward arguments at this call."""

        return self.__dict__.get("_forward_kwargs_template")

    @forward_kwargs_template.setter
    def forward_kwargs_template(self, value: Any) -> None:
        """Set the structural template for keyword forward arguments."""

        self.__dict__["_forward_kwargs_template"] = value

    @property
    def num_param_tensors(self) -> int:
        """Number of parameter tensors owned by the called Module."""

        return self.module.num_param_tensors

    @property
    def num_param_tensors_trainable(self) -> int:
        """Number of trainable parameter tensors owned by the called Module."""

        return self.module.num_param_tensors_trainable

    @property
    def num_param_tensors_frozen(self) -> int:
        """Number of frozen parameter tensors owned by the called Module."""

        return self.module.num_param_tensors_frozen

    @property
    def has_trainable_params(self) -> bool:
        """Whether the called Module owns trainable parameters."""

        return self.module.has_trainable_params

    @property
    def has_frozen_params(self) -> bool:
        """Whether the called Module owns frozen parameters."""

        return self.module.has_frozen_params

    @property
    def func_calls_duration(self) -> Duration:
        """Inclusive duration of torch function calls inside this ModuleCall."""

        trace = self._source_trace
        if trace is None:
            return Duration(0)
        return Duration(
            sum(
                getattr(op, "func_duration", 0.0) or 0.0
                for label in self.ops
                for op in _resolve_call_ops(trace, label)
            )
        )

    @property
    def backward_duration(self) -> Duration | None:
        """Backward duration for this module call, if backward timing is available."""

        return None

    @property
    def num_internal_edges(self) -> int:
        """Edges whose parent and child Ops are both inside this ModuleCall."""

        return _edge_counts_for_scope(self._source_trace, self.ops)[0]

    @property
    def num_input_edges(self) -> int:
        """Edges whose child Op is inside this ModuleCall and parent Op is outside."""

        return _edge_counts_for_scope(self._source_trace, self.ops)[1]

    @property
    def num_output_edges(self) -> int:
        """Edges whose parent Op is inside this ModuleCall and child Op is outside."""

        return _edge_counts_for_scope(self._source_trace, self.ops)[2]

    @property
    def num_edges(self) -> int:
        """Total edge footprint for this ModuleCall."""

        return self.num_internal_edges + self.num_input_edges + self.num_output_edges

    def _ops_by_output_role(self, *, output: bool) -> list["Op"]:
        """Return Op records inside this call, filtered by output boundary role."""

        trace = self._source_trace
        if trace is None:
            return []
        output_labels = set(self.output_ops)
        result: list["Op"] = []
        for label in self.ops:
            if (label in output_labels) is not output:
                continue
            result.extend(_resolve_call_ops(trace, label))
        return result

    def _sum_op_memory(self, field_name: str, *, output: bool) -> Bytes:
        """Sum an Op memory field for output or non-output Ops in this call."""

        return Bytes(
            sum(
                int(getattr(op, field_name, 0) or 0)
                for op in self._ops_by_output_role(output=output)
            )
        )

    @property
    def output_activation_memory(self) -> Bytes:
        """Activation bytes for Ops whose outputs form this call's return value."""

        return self._sum_op_memory("activation_memory", output=True)

    @property
    def internal_activation_memory(self) -> Bytes:
        """Activation bytes for non-output Ops executed inside this call."""

        return self._sum_op_memory("activation_memory", output=False)

    @property
    def output_gradient_memory(self) -> Bytes:
        """Gradient bytes for Ops whose outputs form this call's return value."""

        return self._sum_op_memory("gradient_memory", output=True)

    @property
    def internal_gradient_memory(self) -> Bytes:
        """Gradient bytes for non-output Ops executed inside this call."""

        return self._sum_op_memory("gradient_memory", output=False)

    @property
    def autograd_memory(self) -> Bytes:
        """Autograd-saved tensor bytes for all Ops executed inside this call."""

        trace = self._source_trace
        if trace is None:
            return Bytes(0)
        return Bytes(
            sum(
                int(getattr(op, "autograd_memory", 0) or 0)
                for label in self.ops
                for op in _resolve_call_ops(trace, label)
            )
        )

    @property
    def param_memory(self) -> Bytes:
        """Own-address parameter bytes of the Module invoked by this call."""

        return self.module.param_memory

    @property
    def internal_param_memory(self) -> Bytes:
        """Address-recursive sum of ``param_memory`` under the invoked Module's subtree."""

        return self.module.internal_param_memory

    @property
    def call_parent_label(self) -> str | None:
        """Parent ModuleCall label in the dynamic call tree (glossary stored-form name)."""

        return cast("Optional[str]", self.call_parent)

    @property
    def call_children_labels(self) -> list[str]:
        """Child ModuleCall labels in the dynamic call tree (glossary stored-form name)."""

        return list(self.call_children)

    @property
    def num_descendant_calls(self) -> int:
        """Number of nested ModuleCalls under this call, recursively."""

        trace = self._source_trace
        if trace is None:
            return 0
        return sum(
            1 + trace.module_calls[child_label].num_descendant_calls
            for child_label in self.call_children
        )

    @property
    def max_descendant_depth(self) -> int:
        """Deepest nested ModuleCall depth beneath this call."""

        trace = self._source_trace
        if trace is None or not self.call_children:
            return 0
        return 1 + max(
            trace.module_calls[child_label].max_descendant_depth
            for child_label in self.call_children
        )

    def walk_descendants(self, include_self: bool = True) -> Iterator["ModuleCall"]:
        """Yield this ModuleCall and all descendant calls in depth-first order.

        Parameters
        ----------
        include_self:
            Whether to yield this call before its descendants.

        Yields
        ------
        ModuleCall
            ModuleCall records in call-tree order.

        Raises
        ------
        RuntimeError
            If this ModuleCall is not bound to an owning Trace.
        """

        if include_self:
            yield self
        trace = self._source_trace
        if trace is None:
            raise RuntimeError("ModuleCall not bound to a Trace")
        for child_label in self.call_children:
            child = trace.module_calls[child_label]
            yield from child.walk_descendants(include_self=True)

    @property
    def call_tree(self) -> "ModuleCall":
        """Return this ModuleCall as the root of its nested call tree.

        Returns
        -------
        ModuleCall
            This call, whose ``call_children`` labels link to child
            ``ModuleCall`` nodes in the owning Trace.
        """

        return self

    def show_call_tree(
        self,
        max_depth: int | None = None,
        include_atomic: bool = True,
        show_call_index: bool = True,
        file: TextIO | None = None,
    ) -> None:
        """Print this ModuleCall subtree as an ASCII tree.

        Parameters
        ----------
        max_depth:
            Maximum descendant depth to print, or ``None`` for no limit.
        include_atomic:
            Whether to include atomic module leaves.
        show_call_index:
            Whether to include the ``:N`` call suffix in labels.
        file:
            Optional output stream. ``None`` prints to stdout.
        """

        _print_call_tree_from_root(
            self,
            max_depth=max_depth,
            include_atomic=include_atomic,
            show_call_index=show_call_index,
            file=file,
        )

    @property
    def _source_trace(self) -> "Trace | None":
        """Owning Trace, if still alive."""

        strong_ref = self.__dict__.get("_source_trace_strong")
        if strong_ref is not None:
            return cast("Trace", strong_ref)
        ref = self.__dict__.get("_source_trace_ref")
        if ref is None:
            return None
        return cast("Trace | None", ref())

    @_source_trace.setter
    def _source_trace(self, value: "Trace | None") -> None:
        """Store the owning Trace for live module-call lookups."""

        self.__dict__["_source_trace_strong"] = value
        self._source_trace_ref = weakref.ref(value) if value is not None else None

    @property
    def trace(self) -> "Trace | None":
        """Alias for the owning Trace."""

        return self._source_trace

    def _output_values(self, field_name: str) -> list[Any]:
        """Return one field from all output layers."""

        trace = self._source_trace
        if trace is None:
            return []
        return [getattr(trace.ops[op_label], field_name) for op_label in self.output_ops]

    def _single_output_value(self, field_name: str) -> Any:
        """Return one output field, requiring exactly one output."""

        values = self._output_values(field_name)
        if len(values) != 1:
            from ..intervention.errors import MultiOutputModuleError

            raise MultiOutputModuleError(
                f"ModuleCall '{self.call_label}' has {len(values)} outputs; "
                "use .outs[i] or resolve .output_ops[i]."
            )
        return values[0]

    @property
    def outs(self) -> list[Any]:
        """Saved output tensors for this module call."""

        return self._output_values("out")

    @property
    def facets(self) -> Any:
        """Return the lazy semantic facet view for this module call."""

        cache = self.__dict__.get("_facets_cache")
        if cache is None:
            from ..semantic import FacetView

            cache = FacetView(self)
            self.__dict__["_facets_cache"] = cache
        return cache

    @facets.deleter
    def facets(self) -> None:
        """Drop the cached semantic facet view for this module call."""

        self.__dict__.pop("_facets_cache", None)

    @property
    def out(self) -> Any:
        """Saved output tensor for a single-output module call."""

        return self._single_output_value("out")

    @property
    def out_shapes(self) -> list[Any]:
        """Output shapes for this module call."""

        return self._output_values("shape")

    @property
    def out_shape(self) -> Any:
        """Output shape for a single-output module call."""

        return self._single_output_value("shape")

    @property
    def out_dtypes(self) -> list[Any]:
        """Output dtypes for this module call."""

        return self._output_values("dtype")

    @property
    def out_dtype(self) -> Any:
        """Output dtype for a single-output module call."""

        return self._single_output_value("dtype")

    @property
    def grads(self) -> list[Any]:
        """Saved output gradients for this module call."""

        return self._output_values("grad")

    @property
    def grad(self) -> Any:
        """Saved output gradient for a single-output module call."""

        return self._single_output_value("grad")

    def __repr__(self) -> str:
        """Show pass label, layer count, and children."""
        lines = [
            f"ModuleCall: {self.call_label}",
            f"  ops: {self.num_ops}",
        ]
        if self.input_layers:
            lines.append(f"  input_layers: {self.input_layers}")
        if self.output_layers:
            lines.append(f"  output_layers: {self.output_layers}")
        if self.call_children:
            lines.append(f"  call_children: {self.call_children}")
        return "\n".join(lines)

    def __len__(self) -> int:
        """Return the number of layers in this pass."""
        return self.num_layers

    def to_pandas(self) -> "pd.DataFrame":
        """Export this module pass as a one-row pandas DataFrame.

        Returns
        -------
        pd.DataFrame
            Single-row DataFrame ordered by ``MODULE_PASS_LOG_FIELD_ORDER``.
        """
        try:
            import pandas as pd
        except ImportError as e:
            raise ImportError(
                "pandas is required for this feature. Install with `pip install torchlens[tabular]`."
            ) from e

        row = _module_call_log_to_row(self)
        return pd.DataFrame([row], columns=MODULE_PASS_LOG_FIELD_ORDER)

    def __getstate__(self) -> Dict[str, Any]:
        """Return pickle state annotated with the current I/O format version."""
        state = self.__dict__.copy()
        state.pop("_source_trace_strong", None)
        state.pop("_source_trace_ref", None)
        state["tlspec_version"] = TLSPEC_VERSION
        return state

    def __setstate__(self, state: Dict[str, Any]) -> None:
        """Restore pickle state with version-aware default filling."""
        read_tlspec_version(state, cls_name=type(self).__name__)
        if "address" not in state and "module_address" in state:
            state["address"] = state.pop("module_address")
        if "call_index" not in state and "pass_num" in state:
            state["call_index"] = state.pop("pass_num")
        if "call_label" not in state and "pass_label" in state:
            state["call_label"] = state.pop("pass_label")
        if "all_addresses" not in state and "all_module_addresses" in state:
            state["all_addresses"] = state.pop("all_module_addresses")
        if "ops" not in state and "layers" in state:
            state["ops"] = state.pop("layers")
        if "input_ops" not in state:
            state["input_ops"] = list(state.get("input_layers", []))
        if "output_ops" not in state:
            if "output_labels" in state:
                state["output_ops"] = state.pop("output_labels")
            else:
                state["output_ops"] = list(state.get("output_layers", []))
        if "forward_args_template" in state:
            state["_forward_args_template"] = state.pop("forward_args_template")
        if "forward_kwargs_template" in state:
            state["_forward_kwargs_template"] = state.pop("forward_kwargs_template")
        module_call_setstate_defaults: dict[str, Any] = {
            **_MODULE_CALL_CONTAINER_DEFAULTS,
            "all_addresses": [state["address"]],
            "cls": None,
            "class_name": "",
            "class_qualname": "",
            "ordinal_index": 0,
            "forward_arg_names": [],
            "num_forward_args_total": 0,
            "num_forward_pos_args": 0,
            "num_forward_kwargs": 0,
            "forward_args_summary": "",
            "forward_kwargs_summary": "",
            "_forward_args_template": None,
            "_forward_kwargs_template": None,
            "forward_duration": 0.0,
            "code_context": [],
            "module_call_stack": [],
            "_source_trace_ref": None,
            "output_structure": None,
            "output_paths": (),
            "inputs_before_pre_hooks": None,
            "inputs_after_pre_hooks": None,
            "forward_pre_hook_effects": (),
        }
        default_fill_state(state, defaults=module_call_setstate_defaults)
        # Repair present-but-wrong-typed container fields from legacy states.
        # `default_fill_state` only fills absent keys; this closes the same
        # gap `Trace`/`Op` already close for their own fields.
        coerce_container_typed_state(state, module_call_setstate_defaults)
        state["forward_duration"] = Duration(state.get("forward_duration") or 0.0)
        self.__dict__.update(state)


# Typed container defaults for every non-Optional container field Module
# stores directly. Same defect class as
# `Op._LAYER_PASS_LOG_CONTAINER_DEFAULTS`/`Trace._MODEL_LOG_CONTAINER_DEFAULTS`:
# without this, `coerce_container_typed_state` cannot repair a
# present-but-wrong-typed legacy value, and an absent field crashes instead of
# restoring an empty typed container. Plain builtin types are used
# deliberately. `ops`/`params`/`recursive_params` are custom accessor classes
# (not plain containers) and are handled separately, below.
_MODULE_CONTAINER_DEFAULTS: dict[str, Any] = {
    "all_addresses": [],
    "address_children": [],
    "call_children": [],
    "call_labels": [],
    "layer_labels": [],
    "input_ops": [],
    "input_layers": [],
    "output_ops": [],
    "output_layers": [],
    "buffer_layers": [],
    "forward_pre_hooks": [],
    "forward_hooks": [],
    "backward_pre_hooks": [],
    "backward_hooks": [],
    "full_backward_pre_hooks": [],
    "full_backward_hooks": [],
    "custom_attributes": {},
    "custom_methods": [],
}


@dataclass(init=False)
class Module:
    """Aggregate metadata for one nn.Module across all its invocations.

    The primary user-facing class for module inspection.  Provides both
    static metadata (source file, class name, hierarchy) and dynamic
    data (layers computed, parameter usage, pass-level detail).

    ``layer_labels`` stores **no-pass** labels (e.g. ``"conv2d_1_1"``),
    pointing to aggregate Layer entries.  For per-pass detail, access
    ``self.ops[call_index].ops`` which stores pass-qualified labels.

    For single-pass modules, per-pass fields (``input_layers``,
    ``output_layers``, ``forward_args``, ``forward_kwargs``) are accessible
    directly via ``_single_pass_or_error()`` delegation to ``ops[0]``.
    """

    PORTABLE_STATE_SPEC: ClassVar[dict[str, FieldPolicy]] = {
        "address": FieldPolicy.KEEP,
        "all_addresses": FieldPolicy.KEEP,
        "cls": FieldPolicy.DROP,
        "class_name": FieldPolicy.KEEP,
        "class_qualname": FieldPolicy.KEEP,
        "class_source_file": FieldPolicy.KEEP,
        "class_source_line": FieldPolicy.KEEP,
        "init_source_file": FieldPolicy.KEEP,
        "init_source_line": FieldPolicy.KEEP,
        "forward_source_file": FieldPolicy.KEEP,
        "forward_source_line": FieldPolicy.KEEP,
        "class_docstring": FieldPolicy.KEEP,
        "init_signature": FieldPolicy.KEEP,
        "init_docstring": FieldPolicy.KEEP,
        "forward_signature": FieldPolicy.KEEP,
        "forward_docstring": FieldPolicy.KEEP,
        "address_parent": FieldPolicy.KEEP,
        "address_children": FieldPolicy.KEEP,
        "address_depth": FieldPolicy.KEEP,
        "call_parent": FieldPolicy.KEEP,
        "call_children": FieldPolicy.KEEP,
        "call_depth": FieldPolicy.KEEP,
        "num_calls": FieldPolicy.KEEP,
        "ops": FieldPolicy.KEEP,
        "call_labels": FieldPolicy.KEEP,
        "layer_labels": FieldPolicy.KEEP,
        "input_ops": FieldPolicy.KEEP,
        "input_layers": FieldPolicy.KEEP,
        "output_ops": FieldPolicy.KEEP,
        "output_layers": FieldPolicy.KEEP,
        "output_structure": FieldPolicy.KEEP,
        "params": FieldPolicy.KEEP,
        "num_params": FieldPolicy.KEEP,
        "num_params_trainable": FieldPolicy.KEEP,
        "num_params_frozen": FieldPolicy.KEEP,
        "param_memory": FieldPolicy.KEEP,
        "buffer_layers": FieldPolicy.KEEP,
        "_buffer_accessor": FieldPolicy.DROP,
        "training": FieldPolicy.KEEP,
        "forward_pre_hooks": FieldPolicy.KEEP,
        "forward_hooks": FieldPolicy.KEEP,
        "backward_pre_hooks": FieldPolicy.KEEP,
        "backward_hooks": FieldPolicy.KEEP,
        "full_backward_pre_hooks": FieldPolicy.KEEP,
        "full_backward_hooks": FieldPolicy.KEEP,
        "custom_attributes": FieldPolicy.BLOB_RECURSIVE,
        "custom_methods": FieldPolicy.KEEP,
        "_source_trace_ref": FieldPolicy.WEAKREF_STRIP,
    }
    FIELD_POLICY = build_record_field_policy_table(MODULE_LOG_FIELD_ORDER, PORTABLE_STATE_SPEC)
    PORTABLE_STATE_SPEC = portable_state_spec_from_policy(FIELD_POLICY)

    address: str
    all_addresses: List[str]
    cls: type[Any] | None
    class_name: str
    class_qualname: str
    class_source_file: Optional[str]
    class_source_line: Optional[int]
    init_source_file: Optional[str]
    init_source_line: Optional[int]
    forward_source_file: Optional[str]
    forward_source_line: Optional[int]
    class_docstring: Optional[str]
    init_signature: Optional[str]
    init_docstring: Optional[str]
    forward_signature: Optional[str]
    forward_docstring: Optional[str]
    address_parent: Optional[str]
    address_children: List[str]
    address_depth: int
    call_parent: Optional[str]
    call_children: List[str]
    call_depth: int
    num_calls: int
    ops: ModuleCallAccessor
    call_labels: List[str]
    layer_labels: List[str]
    input_ops: List[str]
    input_layers: List[str]
    output_ops: List[str]
    output_layers: List[str]
    params: "ParamAccessor"
    num_params: int
    num_params_trainable: int
    num_params_frozen: int
    buffer_layers: List[str]
    training: bool
    forward_pre_hooks: List[HookInfo]
    forward_hooks: List[HookInfo]
    backward_pre_hooks: List[HookInfo]
    backward_hooks: List[HookInfo]
    full_backward_pre_hooks: List[HookInfo]
    full_backward_hooks: List[HookInfo]
    custom_attributes: Dict[str, Any]
    custom_methods: List[str]

    def __init__(
        self,
        # Identity
        address: str,
        all_addresses: Optional[List[str]] = None,
        name: str = "",
        cls: type[Any] | None = None,
        class_name: str = "",
        class_qualname: str = "",
        # Source info
        class_source_file: Optional[str] = None,
        class_source_line: Optional[int] = None,
        init_source_file: Optional[str] = None,
        init_source_line: Optional[int] = None,
        forward_source_file: Optional[str] = None,
        forward_source_line: Optional[int] = None,
        class_docstring: Optional[str] = None,
        init_signature: Optional[str] = None,
        init_docstring: Optional[str] = None,
        forward_signature: Optional[str] = None,
        forward_docstring: Optional[str] = None,
        # Hierarchy — address-based (static)
        address_parent: Optional[str] = None,
        address_children: Optional[List[str]] = None,
        address_depth: int = 0,
        # Hierarchy — call-based (dynamic)
        call_parent: Optional[str] = None,
        call_children: Optional[List[str]] = None,
        call_depth: int = 0,
        # Pass info
        num_calls: int = 1,
        ops: Optional[Dict[int, "ModuleCall"]] = None,
        call_labels: Optional[List[str]] = None,
        # Layers (aggregate)
        layer_labels: Optional[List[str]] = None,
        # Parameters
        params: Optional["ParamAccessor"] = None,
        num_params: int = 0,
        num_params_trainable: int = 0,
        num_params_frozen: int = 0,
        param_memory: int = 0,
        # Buffers
        buffer_layers: Optional[List[str]] = None,
        # Module state
        training: bool = True,
        forward_pre_hooks: List[HookInfo] | None = None,
        forward_hooks: List[HookInfo] | None = None,
        backward_pre_hooks: List[HookInfo] | None = None,
        backward_hooks: List[HookInfo] | None = None,
        full_backward_pre_hooks: List[HookInfo] | None = None,
        full_backward_hooks: List[HookInfo] | None = None,
        custom_attributes: Optional[Dict[str, Any]] = None,
        custom_methods: Optional[List[str]] = None,
        # Back-reference
        _source_trace: "Trace | None" = None,
    ) -> None:
        """Initialize persistent metadata for a model module address.

        Parameters
        ----------
        address:
            Canonical module address.
        all_addresses:
            All model addresses that reference the same module object.
        name:
            Local module name.
        cls:
            Live module class when available.
        class_name:
            Module class name.
        class_qualname:
            Qualified module class name.
        class_source_file:
            Source file containing the module class.
        class_source_line:
            Source line for the module class.
        init_source_file:
            Source file containing ``__init__``.
        init_source_line:
            Source line for ``__init__``.
        forward_source_file:
            Source file containing ``forward``.
        forward_source_line:
            Source line for ``forward``.
        class_docstring:
            Module class docstring.
        init_signature:
            Signature for ``__init__`` when available.
        init_docstring:
            Docstring for ``__init__`` when available.
        forward_signature:
            Signature for ``forward`` when available.
        forward_docstring:
            Docstring for ``forward`` when available.
        address_parent:
            Static parent module address.
        address_children:
            Static child module addresses.
        address_depth:
            Static nesting depth in the module tree.
        call_parent:
            Dynamic parent module-call label.
        call_children:
            Dynamic child module-call labels.
        call_depth:
            Dynamic call-stack depth.
        num_calls:
            Number of observed forward calls.
        ops:
            Per-call module call logs.
        call_labels:
            Pass-qualified module call labels.
        layer_labels:
            Aggregate layer labels owned by this module.
        params:
            Parameters owned by this module.
        num_params:
            Total parameter count.
        num_params_trainable:
            Trainable parameter count.
        num_params_frozen:
            Frozen parameter count.
        param_memory:
            Parameter memory in bytes.
        buffer_layers:
            Buffer layer labels owned by this module.
        training:
            Training/eval mode captured from the live module.
        forward_pre_hooks:
            Registered forward pre-hooks.
        forward_hooks:
            Registered forward hooks.
        backward_pre_hooks:
            Registered backward pre-hooks.
        backward_hooks:
            Registered backward hooks.
        full_backward_pre_hooks:
            Registered full backward pre-hooks.
        full_backward_hooks:
            Registered full backward hooks.
        custom_attributes:
            User attributes selected for module metadata.
        custom_methods:
            User method names selected for module metadata.
        _source_trace:
            Owning trace used for live accessors.
        """

        self.address = address
        self.all_addresses = all_addresses if all_addresses is not None else [address]
        self.cls = cls
        self.class_name = class_name
        self.class_qualname = class_qualname

        self.class_source_file = class_source_file
        self.class_source_line = class_source_line
        self.init_source_file = init_source_file
        self.init_source_line = init_source_line
        self.forward_source_file = forward_source_file
        self.forward_source_line = forward_source_line
        self.class_docstring = class_docstring
        self.init_signature = init_signature
        self.init_docstring = init_docstring
        self.forward_signature = forward_signature
        self.forward_docstring = forward_docstring

        self.address_parent = address_parent
        self.address_children = address_children if address_children is not None else []
        self.address_depth = address_depth

        self.call_parent = call_parent
        self.call_children = call_children if call_children is not None else []
        self.call_depth = call_depth

        self.num_calls = num_calls
        self.ops = ModuleCallAccessor(ops)
        self.call_labels = call_labels if call_labels is not None else []

        # layer_labels stores NO-PASS labels (e.g. "conv2d_1_1") -> Layer.
        # Contrast with ModuleCall.ops which stores pass-qualified labels.
        self.layer_labels = layer_labels if layer_labels is not None else []
        self.input_ops: List[str] = []
        self.input_layers: List[str] = []
        self.output_ops: List[str] = []
        self.output_layers: List[str] = []
        self._sync_boundary_fields_from_calls()

        from .param import ParamAccessor

        self.params = params if params is not None else ParamAccessor({})
        self.num_params = num_params
        self.num_params_trainable = num_params_trainable
        self.num_params_frozen = num_params_frozen
        self.buffer_layers = buffer_layers if buffer_layers is not None else []
        self._buffer_accessor: Any = None  # populated by _build_module_logs

        self.training = training
        self.forward_pre_hooks = forward_pre_hooks if forward_pre_hooks is not None else []
        self.forward_hooks = forward_hooks if forward_hooks is not None else []
        self.backward_pre_hooks = backward_pre_hooks if backward_pre_hooks is not None else []
        self.backward_hooks = backward_hooks if backward_hooks is not None else []
        self.full_backward_pre_hooks = (
            full_backward_pre_hooks if full_backward_pre_hooks is not None else []
        )
        self.full_backward_hooks = full_backward_hooks if full_backward_hooks is not None else []
        self.custom_attributes = custom_attributes if custom_attributes is not None else {}
        self.custom_methods = custom_methods if custom_methods is not None else []

        # Store as weakref to break circular reference (Trace -> _module_logs -> Module -> Trace).
        self._source_trace_ref = weakref.ref(_source_trace) if _source_trace is not None else None

    def _sync_boundary_fields_from_calls(self) -> None:
        """Populate aggregate boundary fields from this Module's calls.

        Returns
        -------
        None
            Boundary lists are updated in first-seen call order.
        """

        input_ops: list[str] = []
        input_layers: list[str] = []
        output_ops: list[str] = []
        output_layers: list[str] = []
        for call in self.ops.values():
            for label in call.input_ops:
                if label not in input_ops:
                    input_ops.append(label)
            for label in call.input_layers:
                if label not in input_layers:
                    input_layers.append(label)
            for label in call.output_ops:
                if label not in output_ops:
                    output_ops.append(label)
            for label in call.output_layers:
                if label not in output_layers:
                    output_layers.append(label)
        self.input_ops = input_ops
        self.input_layers = input_layers
        self.output_ops = output_ops
        self.output_layers = output_layers

    @property
    def name(self) -> str:
        """Return the final segment of the primary module address.

        Returns
        -------
        str
            Module name within its parent module.
        """

        return "" if self.address == "self" else self.address.rsplit(".", 1)[-1]

    @property
    def has_multiple_addresses(self) -> bool:
        """Whether this module appears at multiple addresses."""
        return len(self.all_addresses) > 1

    @property
    def num_layers(self) -> int:
        """Number of unique layers in this module."""
        return len(self.layer_labels)

    @property
    def layers(self) -> list[Any]:
        """Layer records belonging to this Module."""

        trace = self._source_trace
        if trace is None:
            return list(self.layer_labels)
        return [trace.layers[label] for label in self.layer_labels]

    def _op_labels(self) -> list[str]:
        """Pass-qualified Op labels belonging to this Module across all calls."""

        labels: list[str] = []
        seen: set[str] = set()
        for call in self.ops.values():
            for label in call.ops:
                if label not in seen:
                    seen.add(label)
                    labels.append(label)
        return labels

    @property
    def num_internal_edges(self) -> int:
        """Edges whose parent and child Ops are both inside this Module."""

        return _edge_counts_for_scope(self._source_trace, self._op_labels())[0]

    @property
    def num_input_edges(self) -> int:
        """Edges whose child Op is inside this Module and parent Op is outside."""

        return _edge_counts_for_scope(self._source_trace, self._op_labels())[1]

    @property
    def num_output_edges(self) -> int:
        """Edges whose parent Op is inside this Module and child Op is outside."""

        return _edge_counts_for_scope(self._source_trace, self._op_labels())[2]

    @property
    def num_edges(self) -> int:
        """Total edge footprint for this Module."""

        return self.num_internal_edges + self.num_input_edges + self.num_output_edges

    @property
    def collapse_score(self) -> float:
        """Canonical smart-collapse score for this Module.

        Returns
        -------
        float
            Rounded default-policy score, or ``0.0`` when the module is not
            eligible for renderer collapse.
        """

        from ..visualization.auto_collapse import module_collapse_score

        return module_collapse_score(self)

    @property
    def call_parent_address(self) -> str | None:
        """Parent Module address (label string) in the dynamic call tree.

        Glossary stored-form name; ``call_parent_module`` resolves the record.
        """

        return cast("Optional[str]", self.call_parent)

    @property
    def call_children_addresses(self) -> list[str]:
        """Child Module addresses (label strings) in the dynamic call tree.

        Glossary stored-form name; ``call_children_modules`` resolves the records.
        """

        return list(self.call_children)

    @property
    def call_parent_module(self) -> "Module | None":
        """Parent Module in the dynamic call tree, if any."""

        if self.call_parent is None or self._source_trace is None:
            return None
        return cast("Module", self._source_trace.modules[self.call_parent])

    @property
    def call_children_modules(self) -> list["Module"]:
        """Child Modules in the dynamic call tree."""

        trace = self._source_trace
        if trace is None:
            return []
        return [cast("Module", trace.modules[address]) for address in self.call_children]

    def _recursive_modules_depth_first(self) -> list["Module"]:
        """Return this Module and address descendants in stable depth-first order."""

        trace = self._source_trace
        if trace is None:
            return [self]

        modules: list[Module] = []

        def visit(module: Module) -> None:
            """Append one module and recursively visit address-sorted children."""

            modules.append(module)
            for child_address in sorted(module.address_children):
                if child_address in trace.modules:
                    visit(cast("Module", trace.modules[child_address]))

        visit(self)
        return modules

    @property
    def recursive_params(self) -> "ParamAccessor":
        """Parameters owned by this Module address and all address descendants."""

        from .param import ParamAccessor

        trace = self._source_trace
        if trace is None:
            return self.params

        module_addresses = [module.address for module in self._recursive_modules_depth_first()]
        recursive_param_dict: dict[str, Any] = {}
        for module_address in module_addresses:
            for param in trace.param_logs:
                if (
                    param.module_address == module_address
                    and param.address not in recursive_param_dict
                ):
                    recursive_param_dict[param.address] = param
        return ParamAccessor(recursive_param_dict)

    @property
    def recursive_param_addresses(self) -> list[str]:
        """Parameter addresses in the same order as ``recursive_params``."""

        return list(self.recursive_params.keys())

    @property
    def num_recursive_params(self) -> int:
        """Number of address-recursive parameter records."""

        return len(self.recursive_params)

    @property
    def num_recursive_params_trainable(self) -> int:
        """Number of trainable address-recursive parameter records."""

        return sum(1 for param in self.recursive_params if param.is_trainable)

    @property
    def num_recursive_params_frozen(self) -> int:
        """Number of frozen address-recursive parameter records."""

        return sum(1 for param in self.recursive_params if not param.is_trainable)

    @property
    def num_recursive_param_tensors(self) -> int:
        """Number of tensors across address-recursive parameter records."""

        return sum(int(getattr(param, "num_tensors", 1) or 1) for param in self.recursive_params)

    @property
    def num_recursive_param_tensors_trainable(self) -> int:
        """Number of trainable tensors across address-recursive parameters."""

        return sum(
            int(getattr(param, "num_tensors", 1) or 1)
            for param in self.recursive_params
            if param.is_trainable
        )

    @property
    def num_recursive_param_tensors_frozen(self) -> int:
        """Number of frozen tensors across address-recursive parameters."""

        return sum(
            int(getattr(param, "num_tensors", 1) or 1)
            for param in self.recursive_params
            if not param.is_trainable
        )

    @property
    def param_memory(self) -> Bytes:
        """Own-address parameter bytes for this Module (call-invariant).

        Glossary: bare ``param_memory`` is own-address; use
        ``internal_param_memory`` for the address-recursive sum.
        """

        return Bytes(sum(int(param.param_memory or 0) for param in self.params))

    @property
    def total_param_memory(self) -> Bytes:
        """Bytes used by this Module's own-address parameters."""

        return self.param_memory

    @property
    def internal_param_memory(self) -> Bytes:
        """Address-recursive sum of ``param_memory`` under this Module's subtree.

        Shares its computation path with the ``recursive_params`` accessor.
        """

        return Bytes(sum(int(param.param_memory or 0) for param in self.recursive_params))

    @property
    def has_forward_hooks(self) -> bool:
        """Whether any forward hook registry is nonempty."""

        return bool(self.forward_pre_hooks or self.forward_hooks)

    @property
    def has_backward_hooks(self) -> bool:
        """Whether any backward hook registry is nonempty."""

        return bool(
            self.backward_pre_hooks
            or self.backward_hooks
            or self.full_backward_pre_hooks
            or self.full_backward_hooks
        )

    @property
    def _source_trace(self) -> "Trace | None":
        """Back-reference to the owning Trace (stored as weakref)."""
        ref = self.__dict__.get("_source_trace_ref")
        if ref is None:
            return None
        return cast("Trace | None", ref())

    @_source_trace.setter
    def _source_trace(self, value: "Trace | None") -> None:
        """Store the owning Trace weak reference for live module lookups."""

        self._source_trace_ref = weakref.ref(value) if value is not None else None

    @property
    def trace(self) -> "Trace | None":
        """Alias for the owning Trace."""

        return self._source_trace

    @property
    def handle(self) -> torch.nn.Module | None:
        """Return the live ``nn.Module`` from the source model when reachable.

        Returns
        -------
        torch.nn.Module | None
            Live module object, or ``None`` when the source model/address is
            unavailable. This computed runtime handle is not portable.
        """

        def resolve_module(model: torch.nn.Module) -> torch.nn.Module | None:
            """Resolve this module address against a live model.

            Parameters
            ----------
            model:
                Live source model.

            Returns
            -------
            torch.nn.Module | None
                Resolved module object.
            """

            if self.address in {"", "self"}:
                return model
            return model.get_submodule(self.address)

        return runtime_handle_from_trace(self._source_trace, resolve_module)

    def __getstate__(self) -> Dict[str, Any]:
        """Return pickle state with weakrefs stripped."""
        state = self.__dict__.copy()
        state["_source_trace_ref"] = None
        state["_buffer_accessor"] = None
        state.pop("_facets_cache", None)
        state["tlspec_version"] = TLSPEC_VERSION
        return state

    def __setstate__(self, state: Dict[str, Any]) -> None:
        """Restore pickle state without touching disk."""
        read_tlspec_version(state, cls_name=type(self).__name__)
        module_setstate_defaults: dict[str, Any] = {
            **_MODULE_CONTAINER_DEFAULTS,
            "_buffer_accessor": None,
            "_source_trace_ref": None,
            "class_source_file": None,
            "class_source_line": None,
            "init_source_file": None,
            "init_source_line": None,
            "forward_source_file": None,
            "forward_source_line": None,
            "training": True,
        }
        default_fill_state(state, defaults=module_setstate_defaults)
        # Repair present-but-wrong-typed container fields from legacy states.
        # `default_fill_state` only fills absent keys; this closes the same
        # gap `Trace`/`Op` already close for their own fields. `ops`/`params`/
        # `recursive_params` are accessor classes handled separately below,
        # not plain containers, so they are intentionally absent from
        # `_MODULE_CONTAINER_DEFAULTS`.
        coerce_container_typed_state(state, module_setstate_defaults)
        self.__dict__.update(state)
        if not isinstance(self.ops, ModuleCallAccessor):
            self.ops = ModuleCallAccessor(self.ops)
        if not self.input_ops and not self.input_layers and not self.output_ops:
            self._sync_boundary_fields_from_calls()

    # --- Per-call delegating properties ---
    # Mirror the Layer delegation pattern: single-pass modules transparently
    # expose per-pass fields; multi-pass modules raise with guidance.

    @property
    def facets(self) -> Any:
        """Return the lazy semantic facet view for this Module."""

        self._single_call_or_error()
        cache = self.__dict__.get("_facets_cache")
        if cache is None:
            from ..semantic import FacetView

            cache = FacetView(self)
            self.__dict__["_facets_cache"] = cache
        return cache

    @facets.deleter
    def facets(self) -> None:
        """Drop the cached semantic facet view for this Module."""

        self.__dict__.pop("_facets_cache", None)

    def _single_pass_or_error(self, field_name: str) -> Any:
        """Return a field from the single pass, or raise if the module has multiple ops.

        For modules invoked once, transparently delegates to ops[0].
        For multi-pass modules, raises AttributeError directing the user to
        access the field on a specific pass.
        """
        if self.num_calls > 1:
            raise AttributeError(
                f"Module '{self.address}' has {self.num_calls} ops. "
                f"Access '{field_name}' on a specific pass: "
                f"module.ops[0].{field_name}, module.ops[1].{field_name}, etc."
            )
        if len(self.ops) == 0:
            return None
        return getattr(self.ops[0], field_name)

    @property
    def output_structure(self) -> "ContainerSpec | None":
        """Return the single call's structured output shape when unambiguous.

        Returns
        -------
        ContainerSpec | None
            Output container specification for single-call modules. Multi-call
            aggregate modules return ``None`` to avoid inventing an additional
            call-index container dimension.
        """

        if len(self.ops._dict) != 1:
            return None
        return next(iter(self.ops._dict.values())).output_structure

    @property
    def forward_args(self) -> tuple[Any, ...] | None:
        """Return captured forward positional arguments for one module pass.

        Returns
        -------
        tuple[Any, ...] | None
            Captured positional arguments, or ``None`` when unavailable.
        """
        return cast("tuple[Any, ...] | None", self._single_pass_or_error("forward_args"))

    @property
    def forward_kwargs(self) -> dict[str, Any] | None:
        """Return captured forward keyword arguments for one module pass.

        Returns
        -------
        dict[str, Any] | None
            Captured keyword arguments, or ``None`` when unavailable.
        """
        return cast("dict[str, Any] | None", self._single_pass_or_error("forward_kwargs"))

    @property
    def forward_args_summary(self) -> str:
        """Human-readable forward positional arguments for a single-call Module."""

        return cast(str, self._single_pass_or_error("forward_args_summary"))

    @property
    def forward_kwargs_summary(self) -> str:
        """Human-readable forward keyword arguments for a single-call Module."""

        return cast(str, self._single_pass_or_error("forward_kwargs_summary"))

    @property
    def forward_args_template(self) -> Any:
        """Representative structural template for positional forward arguments."""

        if len(self.ops) == 0:
            return None
        return next(iter(self.ops.values())).forward_args_template

    @property
    def forward_kwargs_template(self) -> Any:
        """Representative structural template for keyword forward arguments."""

        if len(self.ops) == 0:
            return None
        return next(iter(self.ops.values())).forward_kwargs_template

    @property
    def forward_duration(self) -> Duration:
        """Wall-clock duration for this Module's single forward call."""

        return cast(Duration, self._single_pass_or_error("forward_duration"))

    @property
    def total_forward_duration(self) -> Duration:
        """Sum of wall-clock forward durations across all calls."""

        return Duration(sum(call.forward_duration for call in self.ops.values()))

    @property
    def backward_duration(self) -> Duration | None:
        """Backward duration for this module, if backward timing is available."""

        return None

    @property
    def total_backward_duration(self) -> Duration | None:
        """Total backward duration across calls, if backward timing is available."""

        return None

    @property
    def func_calls_duration(self) -> Duration:
        """Inclusive torch function duration for this Module's single call."""

        return cast(Duration, self._single_pass_or_error("func_calls_duration"))

    @property
    def total_func_calls_duration(self) -> Duration:
        """Sum of inclusive torch function durations across all calls."""

        return Duration(sum(call.func_calls_duration for call in self.ops.values()))

    @property
    def total_output_activation_memory(self) -> Bytes:
        """Sum of output activation bytes across this Module's calls."""

        return Bytes(sum(int(call.output_activation_memory) for call in self.ops.values()))

    @property
    def total_internal_activation_memory(self) -> Bytes:
        """Sum of internal activation bytes across this Module's calls."""

        return Bytes(sum(int(call.internal_activation_memory) for call in self.ops.values()))

    @property
    def total_output_gradient_memory(self) -> Bytes:
        """Sum of output gradient bytes across this Module's calls."""

        return Bytes(sum(int(call.output_gradient_memory) for call in self.ops.values()))

    @property
    def total_internal_gradient_memory(self) -> Bytes:
        """Sum of internal gradient bytes across this Module's calls."""

        return Bytes(sum(int(call.internal_gradient_memory) for call in self.ops.values()))

    @property
    def total_autograd_memory(self) -> Bytes:
        """Sum of autograd-saved bytes across this Module's calls."""

        return Bytes(sum(int(call.autograd_memory) for call in self.ops.values()))

    @property
    def num_descendant_calls(self) -> int:
        """Total nested ModuleCalls beneath all calls of this Module."""

        return sum(call.num_descendant_calls for call in self.ops.values())

    @property
    def max_descendant_depth(self) -> int:
        """Deepest nested ModuleCall depth beneath this Module."""

        if len(self.ops) == 0:
            return 0
        return max(call.max_descendant_depth for call in self.ops.values())

    def walk_descendants(self) -> Iterator["ModuleCall"]:
        """Yield every ModuleCall nested beneath any call of this Module.

        Yields
        ------
        ModuleCall
            Descendant ModuleCall records in depth-first order. This Module's
            own calls are not included.
        """

        for call in self.calls.values():
            yield from call.walk_descendants(include_self=False)

    @property
    def call_tree(self) -> "ModuleCall | None":
        """Return this Module's single ModuleCall as a nested call-tree root.

        Returns
        -------
        ModuleCall | None
            Sole call for this Module, or ``None`` if the Module was never
            called.

        Raises
        ------
        AttributeError
            If this Module was invoked multiple times; select a specific call
            from ``module.calls`` or ``module.ops`` in that case.
        """

        return cast("ModuleCall | None", self._single_pass_or_error("call_tree"))

    def show_call_tree(
        self,
        max_depth: int | None = None,
        include_atomic: bool = True,
        show_call_index: bool = True,
        file: TextIO | None = None,
    ) -> None:
        """Print this Module's call subtrees as ASCII trees.

        Parameters
        ----------
        max_depth:
            Maximum descendant depth to print for each call, or ``None`` for no
            limit.
        include_atomic:
            Whether to include atomic module leaves.
        show_call_index:
            Whether to include the ``:N`` call suffix in labels.
        file:
            Optional output stream. ``None`` prints to stdout.
        """

        calls = list(self.calls.values())
        for index, call in enumerate(calls):
            if index > 0:
                print(file=file)
            _print_call_tree_from_root(
                call,
                max_depth=max_depth,
                include_atomic=include_atomic,
                show_call_index=show_call_index,
                file=file,
            )

    @property
    def num_param_tensors(self) -> int:
        """Number of parameter tensors owned by this Module."""

        return len(self.params)

    @property
    def num_param_tensors_trainable(self) -> int:
        """Number of trainable parameter tensors owned by this Module."""

        return sum(1 for param in self.params if param.is_trainable)

    @property
    def num_param_tensors_frozen(self) -> int:
        """Number of frozen parameter tensors owned by this Module."""

        return sum(1 for param in self.params if not param.is_trainable)

    @property
    def has_trainable_params(self) -> bool:
        """Whether this Module owns at least one trainable parameter."""

        return self.num_params_trainable > 0

    @property
    def has_frozen_params(self) -> bool:
        """Whether this Module owns at least one frozen parameter."""

        return self.num_params_frozen > 0

    @property
    def class_source_location(self) -> str | None:
        """Combined class source location as ``file:line``."""

        if self.class_source_file is None or self.class_source_line is None:
            return None
        return f"{self.class_source_file}:{self.class_source_line}"

    @property
    def init_source_location(self) -> str | None:
        """Combined ``__init__`` source location as ``file:line``."""

        if self.init_source_file is None or self.init_source_line is None:
            return None
        return f"{self.init_source_file}:{self.init_source_line}"

    @property
    def forward_source_location(self) -> str | None:
        """Combined ``forward`` source location as ``file:line``."""

        if self.forward_source_file is None or self.forward_source_line is None:
            return None
        return f"{self.forward_source_file}:{self.forward_source_line}"

    def _single_call_or_error(self) -> ModuleCall:
        """Return the only ModuleCall or raise for multi-call modules."""

        if self.num_calls != 1 or len(self.ops) != 1:
            raise ValueError(
                f"Module '{self.address}' has {self.num_calls} calls; use module.calls[N]."
            )
        return self.ops[0]

    @property
    def calls(self) -> ModuleCallAccessor:
        """Scoped module-call collection."""

        return self.ops

    @property
    def outs(self) -> list[Any]:
        """Saved output tensors for a single-call module."""

        return self._single_call_or_error().outs

    @property
    def out(self) -> Any:
        """Saved output tensor for a single-call, single-output module."""

        return self._single_call_or_error().out

    @property
    def out_shapes(self) -> list[Any]:
        """Output shapes for a single-call module."""

        return self._single_call_or_error().out_shapes

    @property
    def out_shape(self) -> Any:
        """Output shape for a single-call, single-output module."""

        return self._single_call_or_error().out_shape

    @property
    def grads(self) -> list[Any]:
        """Saved output gradients for a single-call module."""

        return self._single_call_or_error().grads

    @property
    def grad(self) -> Any:
        """Saved output gradient for a single-call, single-output module."""

        return self._single_call_or_error().grad

    @property
    def buffers(self) -> "BufferAccessor":
        """Scoped BufferAccessor for buffers belonging to this module."""
        if self._buffer_accessor is not None:
            return cast("BufferAccessor", self._buffer_accessor)
        # Build on first access from the source Trace
        from .buffer import BufferAccessor

        if self._source_trace is None or self._source_trace._buffer_accessor is None:
            self._buffer_accessor = BufferAccessor({})
            return cast("BufferAccessor", self._buffer_accessor)
        parent_accessor = self._source_trace._buffer_accessor
        scoped = {
            addr: bl
            for addr, bl in parent_accessor._dict.items()
            if self.address in {"", "self"}
            or addr == self.address
            or addr.startswith(f"{self.address}.")
        }
        self._buffer_accessor = BufferAccessor(scoped, source_trace=self._source_trace)
        return cast("BufferAccessor", self._buffer_accessor)

    def _sum_layer_field(self, field: str) -> int:
        """Sum a numeric field across all layers in this module (skipping None)."""
        if self._source_trace is None:
            return 0
        total = 0
        for label in self.layer_labels:
            entry = self._source_trace[label]
            val = getattr(entry, field, None)
            if val is not None:
                total += val
        return total

    @property
    def total_flops_forward(self) -> Flops:
        """Sum of forward FLOPs across all Layers in this Module."""
        return Flops(self._sum_layer_field("flops_forward"))

    @property
    def total_flops_backward(self) -> Flops:
        """Sum of backward FLOPs across all Layers in this Module."""
        return Flops(self._sum_layer_field("flops_backward"))

    @property
    def total_flops(self) -> Flops:
        """Sum of forward and backward FLOPs for this Module."""
        return Flops(self.total_flops_forward + self.total_flops_backward)

    @property
    def total_macs_forward(self) -> Macs:
        """Approximate forward MACs across this Module. 1 MAC = 2 FLOPs."""
        return Macs(self.total_flops_forward // 2)

    @property
    def total_macs_backward(self) -> Macs:
        """Approximate backward MACs across this Module. 1 MAC = 2 FLOPs."""
        return Macs(self.total_flops_backward // 2)

    @property
    def total_macs(self) -> Macs:
        """Approximate total MACs (forward + backward) for this Module."""
        return Macs(self.total_flops // 2)

    def __repr__(self) -> str:
        """Show address, class, depth, param count, layer count, and pass count."""
        lines = [
            f"  call_depth: {self.call_depth}, address_depth: {self.address_depth}",
            f"  num_params: {self.num_params}",
            f"  num_layers: {self.num_layers}",
            f"  num_calls: {self.num_calls}",
        ]
        if self.has_multiple_addresses:
            lines.append(f"  aliases: {self.all_addresses}")
        if self.address_children:
            lines.append(f"  children: {self.address_children}")
        return format_summary_lines(f"Module: {self.address} ({self.class_name})", lines)

    def __len__(self) -> int:
        """Return the total number of layers across all ops of this module."""
        return self.num_layers

    def __getitem__(self, ix: int | str) -> Any:
        """Return the Op at position ix within this module's layer list.

        Supports int indexing and string label lookup (#120).
        """
        if self._source_trace is None:
            raise RuntimeError("No source Trace reference; cannot index into layers.")
        if isinstance(ix, str):
            # String label lookup within this module's layers
            if ix in self.layer_labels:
                return self._source_trace[ix]
            # Try substring match within module layers
            matches = [lbl for lbl in self.layer_labels if ix in lbl]
            if len(matches) == 1:
                return self._source_trace[matches[0]]
            elif len(matches) > 1:
                raise ValueError(
                    f"Ambiguous lookup: '{ix}' matches {len(matches)} layers in module "
                    f"'{self.address}': {', '.join(matches[:5])}"
                )
            raise KeyError(f"'{ix}' not found in module '{self.address}' layers")
        return self._source_trace[self.layer_labels[ix]]

    def __iter__(self) -> Iterator[Any]:
        """Iterate over Op entries for all layers in this module."""
        if self._source_trace is None:
            return iter(self.layer_labels)
        return iter(self._source_trace[label] for label in self.layer_labels)

    def draw(self, **kwargs: Any) -> str:
        """Render this module's focused graph.

        Parameters
        ----------
        **kwargs:
            Keyword arguments forwarded to ``Trace.draw``.

        Returns
        -------
        str
            Graphviz DOT source string.

        Raises
        ------
        RuntimeError
            If this Module is not bound to a Trace.
        """

        trace: Trace | None = self._source_trace
        if trace is None:
            raise RuntimeError("Module not bound to a Trace")
        return cast(str, trace.draw(module=self, **kwargs))

    def to_pandas(self) -> "pd.DataFrame":
        """Export this module's layers as a pandas DataFrame.

        Builds each row the same way as ``Layer.to_pandas()``
        (``LAYER_LOG_FIELD_ORDER``) so every populated Layer field is
        exported -- this used to hand-roll a 6-field subset that silently
        dropped the rest. ``num_ops`` is kept as a trailing convenience
        column (a derived ``len(layer.ops)`` count, not a stored field, so
        it isn't part of ``LAYER_LOG_FIELD_ORDER`` itself). Per-pass fields
        (e.g. ``transformed_out``/``transformed_grad``) are reported as
        ``None`` for multi-pass (recurrent) layers instead of raising.

        Returns
        -------
        pd.DataFrame
            One row per layer belonging to this module, ordered by
            ``LAYER_LOG_FIELD_ORDER`` plus a trailing ``num_ops`` column.
        """
        if self._source_trace is None:
            raise RuntimeError("No source Trace reference; cannot build DataFrame.")
        try:
            import pandas as pd
        except ImportError as e:
            raise ImportError(
                "pandas is required for this feature. Install with `pip install torchlens[tabular]`."
            ) from e

        columns = [*LAYER_LOG_FIELD_ORDER, "num_ops"]
        if not self.layer_labels:
            return pd.DataFrame(columns=columns)
        rows = []
        for label in self.layer_labels:
            entry = self._source_trace[label]
            row = _layer_log_to_row(entry)
            row["num_ops"] = getattr(entry, "num_ops", 1)
            rows.append(row)
        return pd.DataFrame(rows, columns=columns)


class ModuleAccessor(Accessor["Module"]):
    """Dict-like accessor for Module objects.

    Supports indexing by:
    * **module address** (str) -- e.g. ``"features.0"``, ``"self"``.
    * **alias** (str) -- for shared modules (same nn.Module registered at
      multiple addresses), any alias resolves to the same Module.
    * **pass label** (str) -- e.g. ``"features.0:2"`` returns a ModuleCall.
    * **ordinal index** (int) -- position in address order.

    Available as ``trace.modules``.
    """

    PORTABLE_STATE_SPEC: dict[str, FieldPolicy] = {
        "_dict": FieldPolicy.KEEP,
        "_list": FieldPolicy.KEEP,
        "_pass_dict": FieldPolicy.KEEP,
        "_alias_dict": FieldPolicy.KEEP,
    }

    def __init__(
        self,
        module_dict: Dict[str, "Module"],
        module_list: Optional[List["Module"]] = None,
        pass_dict: Optional[Dict[str, "ModuleCall"]] = None,
    ) -> None:
        """Initialize a module accessor with address, alias, and pass indexes.

        Parameters
        ----------
        module_dict:
            Mapping from canonical module addresses to ``Module`` logs.
        module_list:
            Ordered module logs; defaults to the mapping values.
        pass_dict:
            Mapping from pass-qualified call labels to ``ModuleCall`` logs.
        """

        super().__init__(module_dict, item_list=module_list)
        self._pass_dict = pass_dict if pass_dict is not None else {}  # pass label -> ModuleCall
        # Alias map: for shared modules (same nn.Module at multiple addresses),
        # every non-primary address also resolves to the same Module.
        self._alias_dict: Dict[str, "Module"] = {}
        for ml in self._dict.values():
            for alias in ml.all_addresses:
                if alias not in self._dict:
                    self._alias_dict[alias] = ml

    def __getitem__(  # type: ignore[override]
        self, key: Union[int, str]
    ) -> "Module":
        """Return a Module by module-specific lookup rules."""
        if key == "":
            key = "self"
        if isinstance(key, str) and key in self._alias_dict:
            return self._alias_dict[key]
        if isinstance(key, str) and key in self._pass_dict:
            key = self._pass_dict[key].address
        return super().__getitem__(key)

    def __contains__(self, key: object) -> bool:
        """Return True if key is a known module address, alias, or pass label."""
        if key == "":
            key = "self"
        return super().__contains__(key) or key in self._alias_dict or key in self._pass_dict

    def __dir__(self) -> list[str]:
        """Return Python attributes plus module addresses for tab completion.

        Returns
        -------
        list[str]
            Attribute names and valid module addresses.
        """

        keys = set(self._dict.keys()) | set(self._alias_dict.keys()) | set(self._pass_dict.keys())
        return sorted(set(super().__dir__()) | keys)

    def _ipython_key_completions_(self) -> list[str]:
        """Return module addresses for IPython ``obj[...]`` completion.

        Returns
        -------
        list[str]
            Valid module addresses and pass labels.
        """

        return (
            list(self._dict.keys()) + list(self._alias_dict.keys()) + list(self._pass_dict.keys())
        )

    def __repr__(self) -> str:
        """Show a table of all modules with class, depth, param, layer, and pass counts."""
        if len(self) == 0:
            return "ModuleAccessor({})"
        items = []
        for ml in self._list:
            items.append(
                f"  '{ml.address}': {ml.class_name} "
                f"(depth={ml.call_depth}, params={ml.num_params}, "
                f"layers={ml.num_layers}, ops={ml.num_calls})"
            )
        inner = "\n".join(items)
        return f"ModuleAccessor({len(self)} modules):\n{inner}"

    def to_pandas(self) -> "pd.DataFrame":
        """Export module metadata as a pandas DataFrame.

        Driven by ``MODULE_LOG_FIELD_ORDER`` minus the documented, genuinely
        non-tabular exclusions in ``_TO_PANDAS_EXCLUDED_MODULE_FIELDS`` --
        this used to hand-roll a 7-field subset that silently dropped the
        rest of ``MODULE_LOG_FIELD_ORDER``.

        Returns
        -------
        pd.DataFrame
            One row per module in address order.
        """
        try:
            import pandas as pd
        except ImportError as e:
            raise ImportError(
                "pandas is required for this feature. Install with `pip install torchlens[tabular]`."
            ) from e

        columns = [
            field_name
            for field_name in MODULE_LOG_FIELD_ORDER
            if field_name not in _TO_PANDAS_EXCLUDED_MODULE_FIELDS
        ]
        rows = [_module_log_to_row(ml) for ml in self._list]
        return pd.DataFrame(rows, columns=columns)

    def summary(self) -> str:
        """Return a compact text table of all modules.

        Returns
        -------
        str
            Summary table with module address, class, depth, params, layers, and ops.
        """
        if len(self) == 0:
            return "No modules."
        lines = [
            f"{'Address':<40} {'Class':<20} {'Depth':>5} {'Params':>10} {'Layers':>7} {'Passes':>7}"
        ]
        lines.append("-" * 92)
        for ml in self._list:
            lines.append(
                f"{ml.address:<40} {ml.class_name:<20} "
                f"{ml.call_depth:>5} {ml.num_params:>10} "
                f"{ml.num_layers:>7} {ml.num_calls:>7}"
            )
        return "\n".join(lines)
