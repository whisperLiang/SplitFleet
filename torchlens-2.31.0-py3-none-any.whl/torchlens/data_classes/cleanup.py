"""Trace cleanup helpers and post-session teardown.

This module provides the helper stack behind Trace cleanup operations:

1. **cleanup()** — full teardown: deletes all Op attributes, then
   deletes all Trace attributes (both FIELD_ORDER and internal containers).
   Breaks circular references (Trace <-> Op.source_trace,
   Module <-> _source_trace).
   Also frees GPU memory via ``torch.cuda.empty_cache()`` when CUDA is
   available (gated to avoid CUDA driver probe cost on CPU-only runs).

2. **_remove_log_entry_references()** — removes a single layer label from all
   Trace list/dict fields that hold graph references.

3. **_scrub_conditional_fields_after_removal()** — repairs conditional metadata
   after one or more labels are removed.

4. **_LIST_FIELDS_TO_CLEAN** — canonical Trace list fields filtered by both
   single-entry and batch removal helpers.
"""

from dataclasses import fields, is_dataclass, replace
from typing import TYPE_CHECKING, Any, Dict, Iterable, List, Set, Tuple, cast

import torch

from ..constants import MODEL_LOG_FIELD_ORDER
from ..intervention.types import ParentRef, Unsupported
from ..utils.collections import remove_entry_from_list
from ..utils.tensor_utils import _is_cuda_available
from ._state_adapter import state_items
from .op import Op

if TYPE_CHECKING:
    from .trace import Trace


def cleanup(self: "Trace") -> None:
    """Delete all log entries, break circular references, and free GPU memory.

    Called explicitly by the user or automatically at the end of a logging
    session. After cleanup, the Trace is effectively empty and should
    not be used further. No long-lived safetensors handles need to be
    closed here because lazy materialization opens and closes files per call.
    """
    from ..backends.torch.backward import _purge_trace_from_backward_registry

    _purge_trace_from_backward_registry(self)
    # GC-1: Release parameter references to allow model GC.
    if hasattr(self, "param_logs"):
        for pl in self.param_logs:
            pl.release_param_ref()
    # First, clear all attributes from each Op entry.
    # This breaks the Op -> Trace circular reference
    # (via source_trace) without needing per-entry reference removal.
    for tensor_log_entry in self:
        _clear_entry_attributes(tensor_log_entry)
    # Then delete all Trace attributes listed in the canonical FIELD_ORDER.
    for attr in MODEL_LOG_FIELD_ORDER:
        if hasattr(self, attr):
            delattr(self, attr)
    # GC-5/GC-12: Also clear internal containers not in MODEL_LOG_FIELD_ORDER.
    # These hold back-references (e.g. _module_logs -> Module -> _source_trace)
    # and large data structures (layer_logs, layer_dict_all_keys).
    for attr in [
        "_raw_layer_dict",
        "_raw_layer_labels_list",
        "_saved_grad_labels",
        "_module_logs",
        "_buffer_accessor",
        "_module_metadata",
        "_module_forward_args",
        "_module_build_data",
        "_param_logs_by_module",
        "layer_logs",
        "layer_dict_all_keys",
        "layer_dict_main_keys",
        "_orphan_labels",
        "_loaded_from_bundle",
        "_source_bundle_manifest_sha256",
        "_source_bundle_path",
        "_source_bundle_created_at",
        "_validation_replay_status",
    ]:
        if hasattr(self, attr):
            delattr(self, attr)
    # Gated behind cached cuda.is_available() so CPU-only runs don't pay the
    # CUDA driver / NVML probe cost (per profiling audit 2026-04-27 finding #4).
    if _is_cuda_available():
        torch.cuda.empty_cache()


def _clear_entry_attributes(log_entry: Op) -> None:
    """Clear all instance attributes from a Op entry."""
    for attr, _ in list(state_items(log_entry)):
        delattr(log_entry, attr)


def _strip_pass_suffix(layer_label: str) -> str:
    """Remove any ``:call_index`` suffix from a layer label.

    Args:
        layer_label: Layer label, optionally pass-qualified.

    Returns:
        The pass-stripped label.
    """
    return layer_label.split(":", 1)[0]


def _label_for_reference_removal(log_entry: Op, pass_finished: bool) -> str:
    """Return the label namespace currently used by graph-level references.

    Parameters
    ----------
    log_entry:
        Entry being removed.
    pass_finished:
        Whether postprocessing has fully completed.

    Returns
    -------
    str
        Final layer label when available, otherwise the raw tensor label.
    """
    if pass_finished:
        return cast(str, log_entry.layer_label)
    if getattr(log_entry, "layer_label", None):
        return cast(str, log_entry.layer_label)
    return cast(str, log_entry._label_raw)


def _filter_conditional_arm_children(
    conditional_arm_children: Dict[int, Dict[str, List[str]]],
    labels_to_remove: Set[str],
) -> Dict[int, Dict[str, List[str]]]:
    """Drop removed labels from ``conditional_arm_children``.

    Args:
        conditional_arm_children: ``cond_id -> branch_kind -> child labels``.
        labels_to_remove: Labels that should be removed.

    Returns:
        A new nested dict with removed labels and empty containers pruned.
    """
    filtered_children_by_cond: Dict[int, Dict[str, List[str]]] = {}
    for cond_id, branch_children in conditional_arm_children.items():
        filtered_branch_children = {
            branch_kind: [
                child_label for child_label in child_labels if child_label not in labels_to_remove
            ]
            for branch_kind, child_labels in branch_children.items()
        }
        filtered_branch_children = {
            branch_kind: child_labels
            for branch_kind, child_labels in filtered_branch_children.items()
            if child_labels
        }
        if filtered_branch_children:
            filtered_children_by_cond[cond_id] = filtered_branch_children
    return filtered_children_by_cond


def _filter_conditional_elif_children(
    conditional_elif_children: Dict[int, List[str]],
    labels_to_remove: Set[str],
) -> Dict[int, List[str]]:
    """Drop removed labels from ``conditional_elif_children``.

    Args:
        conditional_elif_children: ``elif_index -> child labels``.
        labels_to_remove: Labels that should be removed.

    Returns:
        A new dict with removed labels and empty lists pruned.
    """
    return {
        elif_ix: [
            child_label for child_label in child_labels if child_label not in labels_to_remove
        ]
        for elif_ix, child_labels in conditional_elif_children.items()
        if any(child_label not in labels_to_remove for child_label in child_labels)
    }


def _filter_conditional_arm_entry_edges(
    conditional_arm_entry_edges: Dict[Tuple[int, str], List[Tuple[str, str]]],
    labels_to_remove: Set[str],
) -> Dict[Tuple[int, str], List[Tuple[str, str]]]:
    """Drop removed labels from ``conditional_arm_entry_edges``.

    Args:
        conditional_arm_entry_edges: ``(cond_id, branch_kind) -> [(parent, child)]``.
        labels_to_remove: Labels that should be removed.

    Returns:
        A new dict with empty edge lists pruned.
    """
    filtered_arm_edges: Dict[Tuple[int, str], List[Tuple[str, str]]] = {}
    for key, edge_list in conditional_arm_entry_edges.items():
        filtered_edges = [
            (parent, child)
            for parent, child in edge_list
            if parent not in labels_to_remove and child not in labels_to_remove
        ]
        if filtered_edges:
            filtered_arm_edges[key] = filtered_edges
    return filtered_arm_edges


def _filter_conditional_edge_call_indices(
    conditional_edge_call_indices: Dict[Tuple[str, str, int, str], List[int]],
    labels_to_remove_no_pass: Set[str],
) -> Dict[Tuple[str, str, int, str], List[int]]:
    """Drop removed labels from ``conditional_edge_call_indices`` keys.

    Args:
        conditional_edge_call_indices: ``(parent_no_pass, child_no_pass, cond_id, branch_kind) -> pass list``.
        labels_to_remove_no_pass: Pass-stripped labels that should be removed.

    Returns:
        A new dict with removed-key entries pruned.
    """
    return {
        key: call_indexs
        for key, call_indexs in conditional_edge_call_indices.items()
        if key[0] not in labels_to_remove_no_pass and key[1] not in labels_to_remove_no_pass
    }


def _scrub_layer_entry_conditional_fields(
    layer_entry: Op,
    labels_to_remove: Set[str],
) -> None:
    """Remove deleted labels from conditional fields on a surviving Op.

    Args:
        layer_entry: Surviving layer entry to scrub.
        labels_to_remove: Labels that were removed elsewhere in the log.
    """
    layer_entry.conditional_entry_children = [
        child_label
        for child_label in layer_entry.conditional_entry_children
        if child_label not in labels_to_remove
    ]
    layer_entry.conditional_arm_children = _filter_conditional_arm_children(
        layer_entry.conditional_arm_children,
        labels_to_remove,
    )
    layer_entry.conditional_then_children = [
        child_label
        for child_label in layer_entry.conditional_then_children
        if child_label not in labels_to_remove
    ]
    layer_entry.conditional_elif_children = _filter_conditional_elif_children(
        layer_entry.conditional_elif_children,
        labels_to_remove,
    )
    layer_entry.conditional_else_children = [
        child_label
        for child_label in layer_entry.conditional_else_children
        if child_label not in labels_to_remove
    ]


def _scrub_layer_log_conditional_fields(self: "Trace", labels_to_remove_no_pass: Set[str]) -> None:
    """Remove deleted labels from aggregate Layer conditional fields.

    Args:
        self: Trace owning the LayerLogs.
        labels_to_remove_no_pass: Pass-stripped labels that were removed.
    """
    for layer_log in getattr(self, "layer_logs", {}).values():
        layer_log.conditional_entry_children = [
            child_label
            for child_label in layer_log.conditional_entry_children
            if child_label not in labels_to_remove_no_pass
        ]
        layer_log.conditional_arm_children = _filter_conditional_arm_children(
            layer_log.conditional_arm_children,
            labels_to_remove_no_pass,
        )
        layer_log.conditional_then_children = [
            child_label
            for child_label in layer_log.conditional_then_children
            if child_label not in labels_to_remove_no_pass
        ]
        layer_log.conditional_elif_children = _filter_conditional_elif_children(
            layer_log.conditional_elif_children,
            labels_to_remove_no_pass,
        )
        layer_log.conditional_else_children = [
            child_label
            for child_label in layer_log.conditional_else_children
            if child_label not in labels_to_remove_no_pass
        ]


def _scrub_conditional_fields_after_removal(
    self: "Trace",
    labels_to_remove: Set[str],
    surviving_entries: Iterable[Op],
) -> None:
    """Scrub conditional references after one or more layer labels are removed.

    Args:
        self: Trace being updated.
        labels_to_remove: Removed layer labels using the same qualification as the
            current removal pass.
        surviving_entries: Surviving Op entries to scrub in-place.
    """
    labels_to_remove_no_pass = {_strip_pass_suffix(layer_label) for layer_label in labels_to_remove}

    for layer_entry in surviving_entries:
        _scrub_layer_entry_conditional_fields(layer_entry, labels_to_remove)

    _scrub_layer_log_conditional_fields(self, labels_to_remove_no_pass)

    self.conditional_arm_entry_edges = _filter_conditional_arm_entry_edges(
        self.conditional_arm_entry_edges,
        labels_to_remove,
    )
    self.conditional_edge_call_indices = _filter_conditional_edge_call_indices(
        self.conditional_edge_call_indices,
        labels_to_remove_no_pass,
    )
    for conditional_event in self.conditional_records:
        conditional_event.bool_layers = [
            layer_label
            for layer_label in conditional_event.bool_layers
            if layer_label not in labels_to_remove
        ]

    _scrub_intervention_fields_after_removal(self, labels_to_remove, surviving_entries)


def _scrub_intervention_fields_after_removal(
    self: Any,
    labels_to_remove: Set[str],
    surviving_entries: Iterable[Op],
) -> None:
    """Scrub replay/intervention metadata that carries layer labels.

    Args:
        self: Trace being updated.
        labels_to_remove: Removed labels in the active label namespace.
        surviving_entries: Surviving entries to scrub in-place.
    """

    for layer_entry in surviving_entries:
        layer_entry._edge_uses = [
            edge
            for edge in getattr(layer_entry, "_edge_uses", [])
            if edge.parent_label not in labels_to_remove
            and edge.child_label not in labels_to_remove
        ]
        layer_entry.args_template = _replace_removed_parent_refs(
            getattr(layer_entry, "args_template", None), labels_to_remove
        )
        layer_entry.kwargs_template = _replace_removed_parent_refs(
            getattr(layer_entry, "kwargs_template", None), labels_to_remove
        )
        interventions = [
            record
            for record in getattr(layer_entry, "interventions", [])
            if not _record_mentions_removed_label(record, labels_to_remove)
        ]
        if hasattr(layer_entry, "_internal_set"):
            layer_entry._internal_set("interventions", interventions)
        else:
            layer_entry.interventions = interventions

    self.state_history = [
        record
        for record in getattr(self, "state_history", [])
        if not _record_mentions_removed_label(record, labels_to_remove)
    ]
    intervention_spec = getattr(self, "_intervention_spec", None)
    if intervention_spec is not None:
        intervention_spec.records = [
            record
            for record in getattr(intervention_spec, "records", [])
            if not _record_mentions_removed_label(record, labels_to_remove)
        ]


def _replace_removed_parent_refs(value: Any, labels_to_remove: Set[str]) -> Any:
    """Replace template parent refs to removed labels with unsupported leaves.

    Args:
        value: Template or nested component.
        labels_to_remove: Removed layer labels.

    Returns:
        Template value with stale parent refs replaced.
    """

    if isinstance(value, ParentRef) and value.parent_label in labels_to_remove:
        return Unsupported(reason="removed_parent_ref", value_type="ParentRef")
    if isinstance(value, tuple):
        return tuple(_replace_removed_parent_refs(item, labels_to_remove) for item in value)
    if isinstance(value, list):
        return [_replace_removed_parent_refs(item, labels_to_remove) for item in value]
    if isinstance(value, dict):
        return {
            key: _replace_removed_parent_refs(item, labels_to_remove) for key, item in value.items()
        }
    if is_dataclass(value) and not isinstance(value, type):
        updates = {
            field.name: _replace_removed_parent_refs(getattr(value, field.name), labels_to_remove)
            for field in fields(value)
            if hasattr(value, field.name)
        }
        return replace(value, **updates)
    return value


def _record_mentions_removed_label(record: Any, labels_to_remove: Set[str]) -> bool:
    """Return whether a record contains a removed label-bearing field.

    Args:
        record: Dataclass record or nested object.
        labels_to_remove: Removed labels.

    Returns:
        Whether the record references a removed label.
    """

    label_fields = {"parent_label", "child_label", "target_label", "call_label", "site_label"}
    if isinstance(record, str):
        return record in labels_to_remove
    if isinstance(record, (list, tuple)):
        return any(_record_mentions_removed_label(item, labels_to_remove) for item in record)
    if isinstance(record, dict):
        return any(
            _record_mentions_removed_label(key, labels_to_remove)
            or _record_mentions_removed_label(value, labels_to_remove)
            for key, value in record.items()
        )
    if is_dataclass(record) and not isinstance(record, type):
        for field in fields(record):
            if not hasattr(record, field.name):
                continue
            field_value = getattr(record, field.name)
            if field.name in label_fields and field_value in labels_to_remove:
                return True
            if field.name not in label_fields and _record_mentions_removed_label(
                field_value, labels_to_remove
            ):
                return True
    return False


# List fields on Trace that hold tensor labels and need filtering during entry
# removal. Both single-entry and batch removal iterate this list.
_LIST_FIELDS_TO_CLEAN = [
    "input_layers",
    "output_layers",
    "buffer_layers",
    "internal_source_ops",
    "internal_sink_ops",
    "internally_terminated_bool_ops",
]

_OP_LABEL_FIELDS_TO_CLEAN = (
    "parents",
    "root_ancestors",
    "children",
    "input_ancestors",
    "output_descendants",
    "internal_source_parents",
    "internal_source_ancestors",
    "conditional_entry_children",
    "conditional_then_children",
    "conditional_else_children",
    "equivalent_ops",
    "recurrent_ops",
)


def _remove_log_entry_references(self: "Trace", layer_to_remove: str) -> None:
    """Removes all references to a single Op from the Trace's list/dict fields.

    This is the single-entry counterpart to the reference-cleaning logic in
    ``_batch_remove_log_entries``. Both iterate ``_LIST_FIELDS_TO_CLEAN`` for
    Trace list fields.

    Args:
        layer_to_remove: The label of the log entry to remove.
    """
    # Clear any fields in Trace referring to the entry.

    for field_name in _LIST_FIELDS_TO_CLEAN:
        remove_entry_from_list(getattr(self, field_name), layer_to_remove)

    _scrub_conditional_fields_after_removal(self, {layer_to_remove}, self)

    self.conditional_branch_edges = [
        edge for edge in self.conditional_branch_edges if layer_to_remove not in edge
    ]
    # Now any nested fields.

    for param_group, tensor_labels in self.layers_with_params.items():
        if layer_to_remove in tensor_labels:
            tensor_labels.remove(layer_to_remove)
    self.layers_with_params = {
        param_group: tensor_labels
        for param_group, tensor_labels in self.layers_with_params.items()
        if len(tensor_labels) > 0
    }

    for equiv_group, equiv_tensor_labels in self.op_equivalence_classes.items():
        if layer_to_remove in equiv_tensor_labels:
            equiv_tensor_labels.remove(layer_to_remove)
    self.op_equivalence_classes = {
        equiv_group: tensor_labels
        for equiv_group, tensor_labels in self.op_equivalence_classes.items()
        if len(tensor_labels) > 0
    }

    _scrub_per_op_equivalence_lists(self, {layer_to_remove})


def _scrub_per_op_equivalence_lists(ops: Iterable["Op"], labels_to_remove: Set[str]) -> None:
    """Remove dead labels from per-op graph-reference fields.

    ``equivalent_ops`` and other raw-label fields are stored per op
    (``FieldPolicy.KEEP``), so removing an Op from the Trace does not by itself
    clear references to it held by other ops. Later postprocess phases rename
    these fields by raw-label lookup; stale labels therefore mean the graph is
    internally inconsistent and can raise ``KeyError`` before validation gets a
    chance to replay the model. Keep every raw-label-bearing per-op field
    consistent with the surviving graph.
    """

    for op in ops:
        _scrub_op_label_collections(op, labels_to_remove)
        _scrub_parent_arg_positions(op, labels_to_remove)
        _scrub_out_versions_by_child(op, labels_to_remove)
        _scrub_conditional_child_maps(op, labels_to_remove)


def _scrub_op_label_collections(op: "Op", labels_to_remove: Set[str]) -> None:
    """Remove dead labels from direct list/set fields on one op.

    Parameters
    ----------
    op:
        Operation record to repair.
    labels_to_remove:
        Raw labels that no longer have a materialized operation record.
    """

    for field_name in _OP_LABEL_FIELDS_TO_CLEAN:
        value = getattr(op, field_name, None)
        if not value:
            continue
        if isinstance(value, list):
            setattr(op, field_name, [label for label in value if label not in labels_to_remove])
        elif isinstance(value, set):
            setattr(op, field_name, value - labels_to_remove)


def _scrub_parent_arg_positions(op: "Op", labels_to_remove: Set[str]) -> None:
    """Remove parent-argument references to deleted raw labels.

    Parameters
    ----------
    op:
        Operation record to repair.
    labels_to_remove:
        Raw labels that no longer have a materialized operation record.
    """

    parent_arg_positions = getattr(op, "parent_arg_positions", None)
    if not parent_arg_positions:
        return
    for arg_type in ("args", "kwargs"):
        positions = parent_arg_positions.get(arg_type, {})
        for key, value in list(positions.items()):
            if value in labels_to_remove:
                del positions[key]


def _scrub_out_versions_by_child(op: "Op", labels_to_remove: Set[str]) -> None:
    """Remove output-version records keyed by deleted child raw labels.

    Parameters
    ----------
    op:
        Operation record to repair.
    labels_to_remove:
        Raw labels that no longer have a materialized operation record.
    """

    out_versions_by_child = getattr(op, "out_versions_by_child", None)
    if not out_versions_by_child:
        return
    op.out_versions_by_child = {
        child_label: tensor_version
        for child_label, tensor_version in out_versions_by_child.items()
        if child_label not in labels_to_remove
    }


def _scrub_conditional_child_maps(op: "Op", labels_to_remove: Set[str]) -> None:
    """Remove deleted raw labels from nested conditional child maps.

    Parameters
    ----------
    op:
        Operation record to repair.
    labels_to_remove:
        Raw labels that no longer have a materialized operation record.
    """

    conditional_elif_children = getattr(op, "conditional_elif_children", None)
    if conditional_elif_children:
        op.conditional_elif_children = {
            elif_ix: [label for label in child_labels if label not in labels_to_remove]
            for elif_ix, child_labels in conditional_elif_children.items()
        }
    conditional_arm_children = getattr(op, "conditional_arm_children", None)
    if conditional_arm_children:
        op.conditional_arm_children = {
            cond_id: {
                branch_kind: [label for label in child_labels if label not in labels_to_remove]
                for branch_kind, child_labels in branch_children.items()
            }
            for cond_id, branch_children in conditional_arm_children.items()
        }
