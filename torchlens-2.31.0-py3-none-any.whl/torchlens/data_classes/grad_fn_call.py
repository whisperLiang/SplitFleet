"""Per-pass runtime data for autograd grad_fn_handle nodes."""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING, Any, ClassVar
import weakref

if TYPE_CHECKING:
    import pandas as pd

from .._io import (
    FieldPolicy,
    TLSPEC_VERSION,
    coerce_container_typed_state,
    default_fill_state,
    read_tlspec_version,
)
from ..constants import GRAD_FN_PASS_LOG_FIELD_ORDER
from ..quantities import Duration
from .field_policy import build_record_field_policy_table, portable_state_spec_from_policy

# GradFnCall currently declares no plain-container (list/dict/tuple/set)
# fields -- every field is scalar, `Any`-typed blob, or a weakref. This empty
# mapping documents that and keeps `GradFnCall.__setstate__` calling
# `coerce_container_typed_state` for consistency with every sibling record
# class (`Op`/`Layer`/`Param`/`GradFn`/...), so a future container field added
# to this dataclass is automatically covered instead of silently missed.
_GRAD_FN_CALL_CONTAINER_DEFAULTS: dict[str, Any] = {}


@dataclass
class GradFnCall:
    """Runtime data for one execution of an autograd ``grad_fn_handle`` node."""

    PORTABLE_STATE_SPEC: ClassVar[dict[str, FieldPolicy]] = {
        "call_index": FieldPolicy.KEEP,
        "ordinal": FieldPolicy.KEEP,
        "backward_pass_index": FieldPolicy.KEEP,
        "label": FieldPolicy.KEEP,
        "grad_inputs": FieldPolicy.BLOB_RECURSIVE,
        "grad_outputs": FieldPolicy.BLOB_RECURSIVE,
        "intervention_fire_ref": FieldPolicy.KEEP,
        "timestamp": FieldPolicy.KEEP,
        "_time_started": FieldPolicy.KEEP,
        "_time_finished": FieldPolicy.KEEP,
        "_source_trace_ref": FieldPolicy.WEAKREF_STRIP,
    }
    FIELD_POLICY = build_record_field_policy_table(
        GRAD_FN_PASS_LOG_FIELD_ORDER,
        {
            **PORTABLE_STATE_SPEC,
            "call_label": PORTABLE_STATE_SPEC["label"],
        },
    )
    PORTABLE_STATE_SPEC = portable_state_spec_from_policy(FIELD_POLICY)

    call_index: int
    ordinal: int | None = None
    backward_pass_index: int | None = None
    label: str = ""
    grad_inputs: Any = None
    grad_outputs: Any = None
    intervention_fire_ref: object | None = None
    timestamp: float | None = None
    _time_started: float | None = None
    _time_finished: float | None = None
    _source_trace_ref: Any = None

    def __post_init__(self) -> None:
        """Fill pass-projection defaults derived from legacy call fields."""

        if self.ordinal is None:
            self.ordinal = self.call_index
        if self.timestamp is None:
            self.timestamp = self._time_finished

    def __getstate__(self) -> dict[str, Any]:
        """Return pickle state with an IO format marker."""

        state = self.__dict__.copy()
        state["_source_trace_ref"] = None
        state["tlspec_version"] = TLSPEC_VERSION
        return state

    def __setstate__(self, state: dict[str, Any]) -> None:
        """Restore pickle state and fill fields added in newer versions."""

        read_tlspec_version(state, cls_name=type(self).__name__)
        grad_fn_call_setstate_defaults: dict[str, Any] = {
            **_GRAD_FN_CALL_CONTAINER_DEFAULTS,
            "label": "",
            "ordinal": state.get("call_index"),
            "backward_pass_index": None,
            "grad_inputs": None,
            "grad_outputs": None,
            "intervention_fire_ref": None,
            "timestamp": None,
            "_time_started": None,
            "_time_finished": None,
            "_source_trace_ref": None,
        }
        default_fill_state(state, defaults=grad_fn_call_setstate_defaults)
        # No-op today (no container fields declared), but keeps this class
        # consistent with every sibling record class and automatically covers
        # any container field added to this dataclass in the future.
        coerce_container_typed_state(state, grad_fn_call_setstate_defaults)
        if "duration" in state and "_time_started" not in state and "_time_finished" not in state:
            state["_time_started"] = 0.0
            state["_time_finished"] = float(state.pop("duration"))
        self.__dict__.update(state)
        if self.ordinal is None:
            self.ordinal = self.call_index

    @property
    def source_trace(self) -> Any:
        """Return the owning Trace if it is still alive."""

        ref = self._source_trace_ref
        return None if ref is None else ref()

    @source_trace.setter
    def source_trace(self, value: Any) -> None:
        """Set the owning Trace weakref."""

        self._source_trace_ref = weakref.ref(value) if value is not None else None

    @property
    def trace(self) -> Any:
        """Alias for the owning Trace."""

        return self.source_trace

    @property
    def ordinal_index(self) -> int:
        """Return this GradFnCall's 0-based position in ``trace.grad_fn_calls``."""

        trace = self.source_trace
        if trace is None:
            return -1
        return list(trace.grad_fn_calls).index(self)

    @property
    def call_label(self) -> str:
        """Return the pass-qualified GradFnCall label.

        Returns
        -------
        str
            GradFn label with the 1-based call index suffix.
        """

        return f"{self.label}:{self.call_index}" if self.label else str(self.call_index)

    @property
    def is_saved(self) -> bool:
        """Return whether this GradFnCall has saved gradient payloads.

        Returns
        -------
        bool
            ``True`` when gradient inputs or outputs were retained by the
            owning Trace's gradient-save selection.
        """

        return self.grad_inputs is not None or self.grad_outputs is not None

    @property
    def backward_duration(self) -> Duration:
        """Return the measured backward duration for this call.

        Returns
        -------
        Duration
            Seconds elapsed between ``_time_started`` and ``_time_finished``.
        """

        if self._time_started is None or self._time_finished is None:
            return Duration(0)
        return Duration(max(0.0, self._time_finished - self._time_started))

    def to_pandas(self) -> "pd.DataFrame":
        """Export this pass as a one-row DataFrame.

        Returns
        -------
        pd.DataFrame
            One-row DataFrame ordered by ``GRAD_FN_PASS_LOG_FIELD_ORDER``.
        """
        try:
            import pandas as pd
        except ImportError as e:
            raise ImportError(
                "pandas is required for this feature. Install with `pip install torchlens[tabular]`."
            ) from e

        row = {field_name: getattr(self, field_name) for field_name in GRAD_FN_PASS_LOG_FIELD_ORDER}
        return pd.DataFrame([row], columns=GRAD_FN_PASS_LOG_FIELD_ORDER)
