"""Core data structures for representing a logged forward pass."""

from .buffer import BufferAccessor, Buffer
from .backward_pass import BackwardPass, BackwardPassAccessor
from .func_call_location import FuncCallLocation
from .grad_fn import GradFnAccessor, GradFn
from .grad_fn_call import GradFnCall
from .internal_types import FuncExecutionContext, VisualizationOverrides
from .module import ModuleAccessor, Module, ModuleCall
from .param import ParamAccessor, Param
from .prehook import ModuleInputSnapshot, PreHookEffect, TensorInputObservation

__all__ = [
    "BackwardPass",
    "BackwardPassAccessor",
    "Buffer",
    "BufferAccessor",
    "FuncCallLocation",
    "FuncExecutionContext",
    "GradFn",
    "GradFnAccessor",
    "GradFnCall",
    "Module",
    "ModuleAccessor",
    "ModuleCall",
    "ModuleInputSnapshot",
    "Param",
    "ParamAccessor",
    "PreHookEffect",
    "TensorInputObservation",
    "VisualizationOverrides",
]

# Trace, Layer, Op, and TensorLog are intentionally NOT
# re-exported here to avoid circular imports. Import them directly:
#   from .data_classes.trace import Trace
#   from .data_classes.layer import Layer
#   from .data_classes.op import Op, TensorLog
