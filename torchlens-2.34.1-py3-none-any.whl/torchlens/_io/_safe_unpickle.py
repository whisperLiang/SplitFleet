"""Restricted unpickler for TorchLens portable-bundle metadata.

A loaded ``.tlspec`` bundle is UNTRUSTED input. Its ``metadata.pkl`` payload was
historically read with an *unrestricted* :class:`pickle.Unpickler`, so a crafted
bundle whose ``metadata.pkl`` carried a ``__reduce__`` / ``os.system`` gadget
executed arbitrary code at ``pickle.load`` time -- BEFORE the resolver / callable
safety defenses (:mod:`torchlens.utils._callable_safety` and the runnable
resolver) could ever fire. That is a load-time RCE sitting in front of the entire
prior hardening effort.

This module closes that front door with the standard safe-unpickle defense: a
class allowlist (default-deny), mirroring the intent of ``torch.load(...,
weights_only=True)``. Only the exact set of classes / values that legitimately
appear in TorchLens ``Trace`` metadata is admitted; every other global -- and in
particular any ``os`` / ``sys`` / ``subprocess`` / ``posix`` / ``nt`` /
``builtins`` code-exec callable, ``importlib``, or ``torch.serialization``
loader -- raises :class:`pickle.UnpicklingError` and executes nothing.

Allowlist policy (fail-closed):

* Objects resolved from the ``torchlens`` package are admitted when they are a
  ``type`` ON THE POSITIVE ``_SAFE_TORCHLENS_TYPES`` ALLOWLIST (vetted-inert metadata
  dataclasses / enums / accessors), or a VETTED-INERT first-party callable: a PUBLIC,
  side-effect-free ``torchlens.*`` facet recipe / transform / helper (e.g.
  ``torchlens.utils.display.identity``), decided by
  ``torchlens.utils._callable_safety.is_inert_first_party_callable``. A torchlens
  ``type`` is NO LONGER admitted unconditionally: a pickle ``REDUCE`` INVOKES the
  admitted type (or its reconstructed instance) with attacker args, so an
  import-sink type such as ``torchlens.intervention.save.LazyImportRef`` (whose
  ``__call__`` resolves an arbitrary import path from its own pickled field) is a
  load-time RCE and is DENIED by the default-deny type allowlist. Trust is
  decided by the resolved object's real module, never the pickled path, so a key
  that walks attributes off a torchlens module to reach ``os.system`` (real module
  ``posix``) is denied. Crucially, a pickle ``REDUCE`` INVOKES the admitted callable
  with attacker args, so the pre-r21 blanket "any torchlens-owned callable" policy
  was a load-time RCE: it trusted the PRIVATE ``torchlens.utils._module_is_installed``
  (which ``importlib.import_module``s its argument). The narrowed gate is
  deterministic (public-name + side-effect-name guard, no live-registry lookup) and
  admits our vetted first-party code without admitting that gadget.
* A FOREIGN facet-recipe callable (a user/test ``@tl.facets.register`` recipe
  embedded by identity in a ``FacetRegistrySnapshot``) is handled DETERMINISTICALLY
  by the same trust model the resolver uses. Known-dangerous modules (``os`` /
  ``sys`` / ``subprocess`` / ``pickle`` / ``builtins`` / ``importlib`` / ...) are
  hard-denied unconditionally. Otherwise, under an explicit trust opt-in
  (``trust_custom_callables`` / ``allowed_custom_callable_modules``) the module is
  imported and the real callable resolved; by default it is LOAD-TOLERATED as an
  inert ``_DeferredForeignCallable`` placeholder -- the foreign module is NEVER
  imported at unpickle, the trace still loads structurally, and any attempt to CALL
  the recipe (facet computation, or a ``__reduce__`` gadget) fails closed. Admission
  depends only on ``(module, name)`` + trust flags, never on process state (an
  import-time / live-registry snapshot was the ordering-dependent load-failure bug).
* A curated set of safe stdlib data/value types (``collections.OrderedDict``, the
  pure-data builtin container types plus ``object``, and the NumPy numeric-array
  reconstruction helpers).
* Any object resolved from the ``torch`` package that is a DATA ``type`` (tensor /
  Module / storage classes) or a ``torch`` dtype / layout / memory_format
  *instance*, plus the pure ``torch._utils._rebuild_*`` reconstructors. Resolving
  a global only references it; constructing a torch data type executes no attacker
  code. Torch's I/O-capable types are the exception -- constructing
  ``torch._C.PyTorchFileReader`` / ``PyTorchFileWriter`` / ``FileCheck`` /
  ``torch.package.PackageImporter`` / ``torch.serialization.*`` / ``torch.jit.*``
  opens/reads/writes an attacker-named filesystem path (arbitrary file access +
  zip-bomb DoS) at unpickle time, so these TYPES are denied by a module-prefix +
  structural-name guard aligned with torch's own ``weights_only`` exclusions.
  Non-type torch callables (e.g. ``torch.serialization.load``) are denied.
* Preview-backend (MLX / Paddle / JAX) numeric array/dtype ``type`` objects and
  framework dtype-like instances.
* ``builtins.getattr`` is legitimately used to reconstruct references to torch C
  tensor methods (``getattr(TensorBase, "sum")``). It is admitted only through a
  *safe* wrapper that restricts the target object to the enumerated torch C
  callable-holder classes, which structurally blocks the classic
  ``getattr(obj, "__globals__")`` pivot to ``eval`` / ``exec``.
* ``torch.storage._load_from_bytes`` reconstructs tensors embedded by legacy
  metadata (current bundles route every tensor through manifest-bound blobs) but
  internally calls ``torch.load`` with the *unsafe* default, i.e. a nested
  unrestricted unpickler. It is admitted only through a wrapper that forces
  ``weights_only=True`` so the nested load routes through torch's own restricted
  unpickler.

If a future legitimate class is not yet covered, loading it fails closed with a
clear error; we NEVER admit a code-exec gadget to make a load succeed.

STRICT-SUBSET OF THE TORCH ``weights_only`` BASELINE (r49 storage, r63 tensor/ndarray).
This unpickler's effective admit+CONSTRUCT surface is a documented STRICT SUBSET of
torch's ``_weights_only_unpickler._get_allowed_globals()`` baseline. The invariant is
about CONSTRUCTION, NOT resolution: the tensor / storage / ndarray TYPE OBJECTS stay
RESOLVABLE at ``find_class`` (legit metadata references ``torch.Tensor`` /
``torch.FloatTensor`` / ``torch.nn.Parameter`` / ``numpy.ndarray`` as inert dtype /
module_type values -- resolving a global only references it), but their BARE
CONSTRUCTION from pickle-supplied args is DENIED. Two layers enforce it:
(1) torch STORAGE constructors are denied by IDENTITY at ``find_class``
(``_is_torch_storage_type`` -- including ``torch.storage.{Typed,Untyped}Storage``,
which torch's OWN baseline hands back as the real, constructable classes, and every
legacy ``torch.<dtype>Storage``). Constructing a storage allocates raw memory
(``UntypedStorage(N)`` -> a multi-GiB alloc DoS), and current ``.tlspec`` metadata
never needs one -- tensor payloads travel as ``BlobRef``s. A legacy embedded storage
routes through the wrapped ``("torch.storage", "_load_from_bytes")`` path (a separate
nested ``weights_only`` VM). (2) ``SafeBundleUnpickler`` is a pure-Python
``pickle._Unpickler`` whose rebuilt opcode ``dispatch`` gates BUILD / REDUCE / NEWOBJ /
NEWOBJ_EX to baseline discipline: a BUILD may not apply a ``__setstate__`` /
storage-rebind to a torch Tensor / Storage / Parameter (the ``find_class``-invisible
``Tensor.__setstate__`` / ``set_`` uninitialized-heap-tensor vector), and a
REDUCE/NEWOBJ/NEWOBJ_EX may not CONSTRUCT any attacker-sized ALLOCATION type
(``_is_alloc_constructor_type``: a torch storage, a ``torch.Tensor`` subclass or legacy
``torch.<dtype>Tensor``, or a ``numpy.ndarray`` subclass) even if that type reached the
stack by some means other than ``find_class`` -- ``torch.Tensor(N)`` /
``torch.FloatTensor(N)`` / ``numpy.ndarray((N,))`` each allocate an attacker-sized,
uninitialized-heap buffer at plain ``tl.load()`` time (r63 closes the r49 storage-only
gap). This is enforced by ``tests/test_r49_unpickler_weights_only_baseline.py`` and
``tests/test_r63_construct_deny.py``; the anti-drift invariant is that the set of
admitted ``(module, name)`` for which this unpickler CONSTRUCTS (does NOT refuse on a
REDUCE/NEWOBJ belt) a storage / tensor / ndarray object is EMPTY -- a
CONSTRUCTOR-SEMANTICS assertion, NOT a string-subset of ``_get_allowed_globals()``
(which is too weak, since the baseline set itself lists the two real storage classes and
the tensor classes by name; those TYPES resolve inertly here, and only their
construction is denied).
"""

from __future__ import annotations

import io
import pickle
import warnings
from collections.abc import Collection, Mapping
from dataclasses import dataclass
from types import ModuleType
from typing import Any, BinaryIO

import torch

from ..utils._callable_safety import (
    _ALLOWED_STDLIB_ROOTS as _CALLABLE_ALLOWED_STDLIB_ROOTS,
    _APPLIANCE_MODULES as _CALLABLE_APPLIANCE_MODULES,
    _DENIED_MODULES as _CALLABLE_DENIED_MODULES,
    _STDLIB_AND_BUILTIN_TOP_LEVEL as _CALLABLE_STDLIB_AND_BUILTIN_TOP_LEVEL,
    is_denied_stdlib_or_builtin_module,
)

__all__ = ["SafeBundleUnpickler"]


# The callable resolver owns the security vocabulary. This front door imports
# the SAME frozen object so a denylist addition cannot land on only one path.
_DENIED_FOREIGN_MODULES = _CALLABLE_DENIED_MODULES


def _module_denied(module: str) -> bool:
    """Return whether ``module`` is (nested under) a hard-denied dangerous module."""

    return any(
        module == denied or module.startswith(denied + ".") for denied in _DENIED_FOREIGN_MODULES
    )


# STRUCTURAL close of the denylist-completeness class (r31). The detector,
# carve-outs, and predicate are imported from ``utils._callable_safety`` so the
# unpickler and callable resolver make one decision from one authority. The explicit
# ``_DENIED_FOREIGN_MODULES`` alias stays as belt-and-suspenders; this positive rule
# closes the CLASS: any FOREIGN global whose real top-level module is a Python
# STANDARD-LIBRARY or BUILTIN module is denied EVEN under trust. The pure-forward
# ``operator`` / ``_operator`` root is carved out; non-stdlib torch / torchlens /
# numpy / user packages are naturally allowed (not in the detector set). NOTE: this is
# applied ONLY in the FOREIGN tail of ``find_class`` -- the ``torch`` / ``torchlens``
# / preview / ``_SAFE_EXPLICIT_GLOBALS`` branches (which legitimately resolve
# ``collections`` / ``builtins`` pure-data globals) return BEFORE the tail.
_ALLOWED_STDLIB_ROOTS = _CALLABLE_ALLOWED_STDLIB_ROOTS
_STDLIB_AND_BUILTIN_TOP_LEVEL = _CALLABLE_STDLIB_AND_BUILTIN_TOP_LEVEL
_stdlib_or_builtin_denied = is_denied_stdlib_or_builtin_module


def _name_has_dunder_walk(name: str) -> bool:
    """Return whether a dotted pickled ``name`` walks through a dunder attribute.

    Pickle protocol >= 4 attribute-walks a DOTTED ``name`` off the resolved module
    (``STACK_GLOBAL``). Every escape from a value/callable object into a module's
    globals / builtins / class / reduce machinery traverses a DUNDER attribute
    segment: ``<func>.__globals__`` returns a module-globals MAPPING,
    ``__builtins__`` the builtins, and ``__dict__`` / ``__class__`` / ``__reduce__``
    / ``__subclasses__`` / ``__mro__`` / ``__base__`` the reflective pivots. A
    LEGITIMATE pickled global name is a module-level class/function qualname -- at
    most an ``Outer.Inner`` nested-class dotted qualname -- so any dunder segment is
    a walk vector and is refused, EXCEPT a small allowlist of provably-inert
    introspection dunders (``__name__`` / ``__doc__`` / ``__qualname__``) that
    resolve to a plain ``str``/``None`` and cannot pivot into globals/builtins/reduce
    machinery. (A trusted appliance recipe legitimately reads e.g.
    ``torchlens.neuro.__name__``; the resolved-mapping backstop below still catches
    any dict/globals escape the name check does not.) Used to gate the trusted-foreign
    branch, where the resolved-real-module denylist recheck is defeated by a resolved
    module-globals mapping (a ``dict`` has no ``__module__``, so the recheck falls back
    to the non-denied pickled module).
    """

    inert_introspection_dunders = {"__name__", "__doc__", "__qualname__"}
    return any(
        segment.startswith("__") and segment not in inert_introspection_dunders
        for segment in name.split(".")
    )


# torch I/O / serialization / packaging / jit TYPE denylist.
#
# The torch-``type`` branch below admits any resolved ``torch.*`` ``type`` on the
# premise that "resolving/constructing a torch data type executes no attacker
# code". That premise HOLDS for the tensor / storage / Size / Parameter / dtype /
# nn-module classes legit metadata references, but it is FALSE for torch's
# I/O-capable types: constructing one opens/reads/writes a filesystem PATH taken
# from the pickle stream at ``tl.load`` time -- e.g.
# ``torch._C.PyTorchFileReader('/etc/passwd')`` (arbitrary-path read + zip-bomb
# DoS) or ``torch.package.PackageImporter(path)`` (directory traversal read).
# torch's own ``weights_only`` allowlist deliberately EXCLUDES these types; we
# align with that intent and deny them here so they are never constructed.
#
# Denial uses two independent signals, because ``__module__`` alone is
# insufficient: ``torch._C.PyTorchFileReader.__module__`` is ``"torch"`` -- the
# SAME module string as ``torch.Size`` / ``torch.Tensor`` -- so a module test
# cannot separate the file reader from a benign shape type. Hence:
#   (a) a MODULE-PREFIX denylist over the pickled path AND the resolved real
#       ``__module__`` (catches ``torch.serialization`` / ``torch.jit`` /
#       ``torch.package`` / ``torch.hub`` families), plus
#   (b) a STRUCTURAL TYPE-NAME guard (the load-bearing one) that denies any type
#       whose pickled name or real ``__qualname__`` contains a file / reader /
#       writer / package / directory / zip / (file)check / importer / pickler
#       token -- this is what stops ``PyTorchFileReader`` / ``PyTorchFileWriter``
#       / ``FileCheck`` / ``PackageImporter`` / ``DirectoryReader``.
#
# Residual (stated honestly): a positive allowlist of the torch DATA types is
# impractical because legit metadata may reference ANY ``nn.Module`` subclass
# (an open-ended set) as a ``module_type``. So this is a denylist: a
# hypothetical future torch type whose construction does I/O yet whose name
# contains none of the tokens and whose module is outside the denied families
# would still be admitted. The token + module families cover the entire known
# torch file-I/O / serialization / packaging / jit surface (audited against
# torch's ``weights_only`` exclusions), so the residual is bounded and small.
_DENIED_TORCH_TYPE_MODULE_PREFIXES: tuple[str, ...] = (
    "torch.serialization",
    "torch.jit",
    "torch.package",
    "torch.hub",
    "torch.utils.tensorboard",
    "torch.utils.cpp_extension",
    "torch.utils.bottleneck",
    "torch.distributed",
    "torch.multiprocessing",
)

_DENIED_TORCH_TYPE_NAME_TOKENS: tuple[str, ...] = (
    "file",  # PyTorchFileReader / PyTorchFileWriter / *FileStore
    "reader",  # DirectoryReader / *Reader
    "writer",  # *Writer
    "package",  # PackageImporter / PackageExporter
    "importer",
    "exporter",
    "directory",
    "zip",  # *ZipFile / zip archive helpers
    "check",  # FileCheck
    "pickler",  # Pickler / Unpickler
    "unpickler",
)


def _torch_type_denied(pickled_module: str, pickled_name: str, obj: type) -> bool:
    """Return whether a resolved torch ``type`` is an I/O / serialization gadget.

    Denies torch's file-reader / file-writer / packaging / serialization / jit
    types whose construction is NOT inert (opens/reads/writes a filesystem path
    from the pickle stream). See ``_DENIED_TORCH_TYPE_MODULE_PREFIXES`` /
    ``_DENIED_TORCH_TYPE_NAME_TOKENS`` for the policy rationale.

    Parameters
    ----------
    pickled_module:
        Attacker-controlled pickled module path (e.g. ``"torch._C"``).
    pickled_name:
        Attacker-controlled pickled global name (e.g. ``"PyTorchFileReader"``).
    obj:
        The resolved torch ``type`` object.

    Returns
    -------
    bool
        ``True`` if the type must be denied (never constructed).
    """

    real_module = str(getattr(obj, "__module__", "") or "")
    for candidate in (pickled_module, real_module):
        if any(
            candidate == prefix or candidate.startswith(prefix + ".")
            for prefix in _DENIED_TORCH_TYPE_MODULE_PREFIXES
        ):
            return True
    real_name = str(getattr(obj, "__qualname__", "") or getattr(obj, "__name__", "") or "")
    haystack = f"{pickled_name} {real_name}".lower()
    return any(token in haystack for token in _DENIED_TORCH_TYPE_NAME_TOKENS)


# STORAGE-CONSTRUCTOR identity denylist (r49, secA_1). The torch-``type`` branch of
# ``find_class`` admits any resolved torch DATA ``type`` on the premise that
# "constructing a torch data type executes no attacker code". That premise HOLDS for
# tensor / Size / Parameter / dtype / nn-module classes, but is FALSE for a torch
# STORAGE class: a pickle ``REDUCE`` of ``torch.UntypedStorage`` with an attacker
# integer -- ``UntypedStorage(6_000_000_000)`` -- allocates that many raw bytes at
# unpickle time (a multi-GiB out-of-memory DoS), and a constructed storage is the only
# source of an uninitialized-heap tensor that a following BUILD/``set_`` could rebind.
# torch's own ``weights_only`` baseline (``_weights_only_unpickler``) DOES list the
# real ``torch.storage.{Typed,Untyped}Storage`` classes, so denying them here makes
# this unpickler a documented STRICT SUBSET of that baseline. No legitimate ``.tlspec``
# metadata references a storage type in the outer stream: tensor payloads are
# ``BlobRef``s, and any embedded storage is reconstructed by the wrapped
# ``_safe_load_from_bytes`` path (a separate nested ``weights_only`` load), never by an
# outer storage global. The set is built from ``torch._storage_classes`` (all 31
# typed/untyped classes) plus the canonical ``TypedStorage`` / ``UntypedStorage``, and
# an ``issubclass`` belt covers any future storage subclass (e.g. a legacy typed
# ``FloatStorage`` is a ``TypedStorage`` subclass).
_TORCH_STORAGE_BASE_CLASSES: tuple[type, ...] = tuple(
    cls
    for cls in (
        getattr(torch.storage, "TypedStorage", None),
        getattr(torch, "UntypedStorage", None),
        getattr(torch.storage, "_StorageBase", None),
    )
    if isinstance(cls, type)
)

_TORCH_STORAGE_CLASSES: frozenset[type] = frozenset(
    set(getattr(torch, "_storage_classes", frozenset())) | set(_TORCH_STORAGE_BASE_CLASSES)
)


def _is_torch_storage_type(obj: Any) -> bool:
    """Return whether ``obj`` is a torch STORAGE *class* (its ctor allocates memory).

    Surface-complete + version-robust: an identity membership test over
    ``torch._storage_classes`` (plus ``TypedStorage`` / ``UntypedStorage`` /
    ``_StorageBase``) and an ``issubclass`` belt so any future storage subclass is
    also caught. Never raises (a non-type ``obj`` returns ``False``).
    """

    if not isinstance(obj, type):
        return False
    if obj in _TORCH_STORAGE_CLASSES:
        return True
    if not _TORCH_STORAGE_BASE_CLASSES:
        return False
    try:
        return issubclass(obj, _TORCH_STORAGE_BASE_CLASSES)
    except TypeError:  # pragma: no cover - defensive; issubclass on odd metaclasses.
        return False


def _is_torch_storage_instance(obj: Any) -> bool:
    """Return whether ``obj`` is a torch STORAGE *instance* (a BUILD/rebind target)."""

    if not _TORCH_STORAGE_BASE_CLASSES:
        return False
    try:
        return isinstance(obj, _TORCH_STORAGE_BASE_CLASSES)
    except TypeError:  # pragma: no cover - defensive.
        return False


# ALLOCATION-CONSTRUCTOR TYPE surface (r63, tensor/ndarray-construct regap). The r49
# belt denies only STORAGE construction, but a torch storage is NOT the only
# pickle-reachable attacker-sized allocator: a bare REDUCE/NEWOBJ of ``torch.Tensor(N)``
# / ``torch.FloatTensor(N)`` / ``numpy.ndarray((N,))`` with an attacker-supplied size
# allocates an attacker-sized, UNINITIALIZED-heap buffer at plain ``tl.load()`` time (no
# trust, no ``.run()``) -- the same alloc-DoS + uninitialized-heap-read class the
# storage deny closes, which the storage-only belt let through. The TYPE OBJECTS stay
# RESOLVABLE at ``find_class`` (legit metadata references these types as inert dtype /
# module_type values); ONLY their CONSTRUCTION on the three belts is refused.
#
# Legacy ``torch.<dtype>Tensor`` classes (``torch.FloatTensor``, the ``torch.cuda.*`` /
# ``torch.sparse.*`` families) are ``tensortype``-metaclass instances whose MRO is
# ``[FloatTensor, object]`` -- they are NOT ``torch.Tensor`` subclasses, so
# ``issubclass(obj, torch.Tensor)`` MISSES them, yet ``torch.FloatTensor(5)`` still
# allocates a 5-element uninitialized tensor. They are caught by identity membership over
# ``torch._tensor_classes`` (surface-complete over the 38 current classes) plus an
# ``isinstance``-of-metaclass belt so any future/variant ``tensortype`` class is caught
# too. numpy is a torch dependency and is imported by the time this module loads
# (``import torch`` above), so ``numpy.ndarray`` resolves in practice; the reference is
# guarded so this early-imported security front door never hard-fails if numpy is absent
# (the predicate then degrades to storage + tensor coverage). No ``np`` alias existed in
# this module (numpy globals are admitted by STRING pair in ``_SAFE_EXPLICIT_GLOBALS``,
# never by import), so a guarded reference is introduced here.
try:
    import numpy as _numpy

    _NUMPY_NDARRAY_TYPE: type | None = _numpy.ndarray
except Exception:  # pragma: no cover - numpy is a torch dependency in practice.
    _NUMPY_NDARRAY_TYPE = None


_TORCH_LEGACY_TENSOR_CLASSES: frozenset[type] = frozenset(
    cls for cls in getattr(torch, "_tensor_classes", frozenset()) if isinstance(cls, type)
)

# The ``tensortype`` metaclass(es) that build the legacy tensor classes (``type(...)`` of
# each), excluding plain ``type``. An ``isinstance`` belt over these catches any legacy /
# future tensor class the identity set above does not enumerate.
_TORCH_TENSORTYPE_METACLASSES: tuple[type, ...] = tuple(
    {
        metacls
        for metacls in (type(cls) for cls in _TORCH_LEGACY_TENSOR_CLASSES)
        if metacls is not type
    }
)


def _is_alloc_constructor_type(obj: Any) -> bool:
    """Return whether ``obj`` is a type whose bare construction allocates attacker-sized memory.

    Superset of ``_is_torch_storage_type`` (r49) that ALSO catches the two other
    pickle-reachable attacker-sized allocators (r63): a torch tensor type (a
    ``torch.Tensor`` subclass such as ``Parameter``, OR a legacy ``tensortype``-metaclass
    ``torch.<dtype>Tensor`` such as ``torch.FloatTensor``) and a ``numpy.ndarray``
    subclass. REDUCE/NEWOBJ-constructing any of these with a pickle-supplied size
    allocates an attacker-sized, UNINITIALIZED-heap buffer at plain ``tl.load()`` time.
    The type OBJECTS stay RESOLVABLE at ``find_class`` (legit metadata references
    ``torch.Tensor`` / ``numpy.ndarray`` as inert values); ONLY their CONSTRUCTION on the
    three belts is refused. Never raises (a non-type ``obj`` returns ``False``).

    ``torch.nn.Module`` subclasses are deliberately NOT listed here even though
    ``nn.Linear(65536, 65536)`` allocates ~16 GiB of parameters: that construction is only
    dangerous when the pickle SUPPLIES the sizes, and a real artifact legitimately
    NEWOBJ-constructs a zero-argument module (``torch.nn.modules.linear.Identity()`` from a
    ``splice_module`` intervention helper). An arg-blind belt here would refuse that honest
    artifact, so the module rule lives in the arg-aware ``_alloc_refusal_reason`` instead.
    """

    if _is_torch_storage_type(obj):
        return True
    if not isinstance(obj, type):
        return False
    try:
        if issubclass(obj, torch.Tensor):
            return True
    except TypeError:  # pragma: no cover - defensive; issubclass on odd metaclasses.
        pass
    if obj in _TORCH_LEGACY_TENSOR_CLASSES:
        return True
    if _TORCH_TENSORTYPE_METACLASSES and isinstance(obj, _TORCH_TENSORTYPE_METACLASSES):
        return True
    if _NUMPY_NDARRAY_TYPE is not None:
        try:
            if issubclass(obj, _NUMPY_NDARRAY_TYPE):
                return True
        except TypeError:  # pragma: no cover - defensive.
            pass
    return False


# Resolved IDENTITIES of the numpy array-reconstruction helper admitted by
# ``_SAFE_EXPLICIT_GLOBALS`` under both the legacy (<2.0) and modern (>=2.0) private
# module spellings. Matching on IDENTITY -- never on the attacker-supplied pickled
# ``(module, name)`` -- is the same rule the torch / torchlens branches of
# ``find_class`` already follow. Both spellings alias the SAME function object on every
# numpy that ships the compatibility shim; resolving both keeps the set correct if a
# future numpy splits them.
def _build_numpy_reconstruct_funcs() -> frozenset[Any]:
    """Resolve the numpy ``_reconstruct`` helpers admitted by the explicit allowlist.

    Returns
    -------
    frozenset[Any]
        Every resolvable ``numpy(.|._)core.multiarray._reconstruct`` function object.
        Empty when numpy is absent or the private module layout changed.
    """

    import importlib

    resolved: list[Any] = []
    for module_path in ("numpy.core.multiarray", "numpy._core.multiarray"):
        try:
            candidate = getattr(importlib.import_module(module_path), "_reconstruct", None)
        except Exception:  # pragma: no cover - numpy absent / private layout drift.
            continue
        if callable(candidate):
            resolved.append(candidate)
    return frozenset(resolved)


_NUMPY_RECONSTRUCT_FUNCS: frozenset[Any] = _build_numpy_reconstruct_funcs()


def _is_vetted_torch_reduce_callable(func: Any) -> bool:
    """Return whether a torch-owned callable may legitimately be INVOKED by a REDUCE.

    The ONLY torch-owned callables a legitimate ``.tlspec`` stream ever CALLS are the
    ``torch._utils._rebuild*`` reconstructors, which ``find_class`` already gates
    (undotted name + torch-owned non-type callable). Every other torch-owned callable
    reaches the stack as an inert VALUE -- a function-registry reference resolved through
    ``_safe_getattr`` -- and is never called by an honest stream.

    Parameters
    ----------
    func:
        Callable sitting on the pickle stack as a REDUCE target.

    Returns
    -------
    bool
        ``True`` only for the vetted ``torch._utils._rebuild*`` reconstructor family.
    """

    return str(getattr(func, "__module__", "") or "") == "torch._utils" and str(
        getattr(func, "__name__", "") or ""
    ).startswith("_rebuild")


def _is_torch_reachable_callable(func: Any) -> bool:
    """Return whether a REDUCE target is a torch callable reachable by this unpickler.

    Covers BOTH routes a torch callable can take onto the pickle stack:

    * ``find_class`` -- a torch-owned function (real ``__module__`` inside the torch
      package), e.g. the ``torch._utils._rebuild*`` reconstructors; and
    * ``_safe_getattr`` -- a method/function DESCRIPTOR fetched off one of the admitted
      torch C holder classes. Those descriptors carry ``__module__ is None``, so a
      ``__module__``-only test MISSES them, and they are the second half of the mediation
      class: ``getattr(torch._C.TensorBase, "new_empty")`` applied to a small tensor
      rebuilt from an embedded blob amplifies a ~1.7 KiB pickle into an arbitrarily large
      UNINITIALIZED tensor. Ownership is therefore read from ``__objclass__`` /
      ``__self__`` -- the descriptor's real owner -- as well as ``__module__``.

    Parameters
    ----------
    func:
        Callable sitting on the pickle stack as a REDUCE target.

    Returns
    -------
    bool
        ``True`` when the callable belongs to torch by module, owning class, or binding.
    """

    if _is_torch_owned(func):
        return True
    for owner in (getattr(func, "__objclass__", None), getattr(func, "__self__", None)):
        if owner is None:
            continue
        # IDENTITY, never ``in``: ``owner`` is attacker-reachable, and a value that is
        # UNHASHABLE (an ``ndarray``) or carries a broadcasting ``__eq__`` makes a
        # frozenset membership test RAISE instead of decide -- a security belt that
        # crashes is a belt that did not answer. Same rule the numpy/bytes branch of
        # ``_alloc_refusal_reason`` follows.
        if any(owner is allowed for allowed in _ALLOWED_GETATTR_OBJECTS):
            return True
        if _is_torch_owned(owner):
            return True
        if isinstance(owner, type) and _is_torch_owned(owner):
            return True
        if _is_torch_owned(type(owner)):
            return True
    return False


def _requests_integer_sized_buffer(args: Any) -> bool:
    """Return whether ``args`` asks a ``bytes``/``bytearray`` ctor for a SIZE, not data.

    ``bytes(b"...")`` / ``bytearray(b"...")`` copy a buffer already present in the stream
    (proportional, harmless). ``bytes(N)`` / ``bytearray(N)`` allocate N zero bytes from a
    handful of pickle bytes -- an out-of-memory DoS with no buffer to pay for it.

    Parameters
    ----------
    args:
        Argument tuple popped for the REDUCE / NEWOBJ opcode.

    Returns
    -------
    bool
        ``True`` when the sole argument is an integer size.
    """

    if not isinstance(args, tuple) or len(args) != 1:
        return False
    return isinstance(args[0], int) and not isinstance(args[0], bool)


def _is_sized_module_construction(func: Any, args: Any, kwargs: Any) -> bool:
    """Return whether a ``torch.nn.Module`` is being constructed WITH pickle-supplied sizes.

    Constructing a module runs its ``__init__``, which allocates PARAMETERS on the belt's
    behalf -- ``torch.nn.modules.linear.Linear(65536, 65536)`` is ~16 GiB from a 48-byte
    REDUCE, and the module class itself is an ordinary torch-owned data type that
    ``find_class`` admits as an inert ``module_type`` reference.

    The rule is ARGUMENT-BEARING construction only, and that boundary is load-bearing in
    both directions. A pickled module INSTANCE always arrives as ``cls.__new__(cls)`` with
    an EMPTY argument tuple followed by a BUILD (protocol >= 2 ``copyreg.__newobj__``), and
    real artifacts do exactly that -- a ``splice_module`` intervention helper round-trips
    ``torch.nn.modules.linear.Identity()``. A zero-argument construction also cannot be
    SCALED by the attacker: whatever it allocates is fixed by the class. Every amplifying
    construction, by contrast, must pass the sizes through the pickle.

    Parameters
    ----------
    func:
        Class the opcode is about to construct.
    args:
        Positional argument tuple popped for it.
    kwargs:
        Keyword argument mapping popped for it (NEWOBJ_EX only), or ``None``.

    Returns
    -------
    bool
        ``True`` for an argument-bearing ``nn.Module`` construction.
    """

    if not isinstance(func, type):
        return False
    try:
        if not issubclass(func, torch.nn.Module):
            return False
    except TypeError:  # pragma: no cover - defensive; issubclass on odd metaclasses.
        return False
    has_positional = bool(args) if isinstance(args, (tuple, list)) else args is not None
    has_keyword = bool(kwargs) if isinstance(kwargs, dict) else kwargs is not None
    return has_positional or has_keyword


def _alloc_refusal_reason(func: Any, args: Any, kwargs: Any = None) -> str | None:
    """Return why calling ``func(*args)`` would MEDIATE an attacker-sized allocation.

    ``_is_alloc_constructor_type`` inspects the TYPE BEING CONSTRUCTED, so it is blind to
    any admitted callable that constructs on that type's behalf: at REDUCE time the stack
    holds the MEDIATOR, not the allocating type. This closes that indirection CLASS.

    Enumerated mediators (r6; every ``_SAFE_EXPLICIT_GLOBALS`` entry and every other
    surface ``find_class`` admits was assessed -- see the audit ledger):

    * numpy ``_reconstruct`` -- ``_reconstruct(numpy.ndarray, (N,), b"b")`` runs
      ``ndarray.__new__`` and returns an N-element UNINITIALIZED array; the bare
      ``numpy.ndarray`` REDUCE the belt already refuses is reached through a plain
      allowlisted FUNCTION. An 88-byte pickle yielded a 2,000,000-element array; at
      N=2e9 roughly 16 GiB of uninitialized heap, allocated before any structural check.
      The mediated TYPE (``args[0]``) is run through the existing belt policy.
    * torch-owned callables reached as REDUCE targets -- ``_safe_getattr`` admits
      ``getattr(torch._C._VariableFunctionsClass, "empty")`` because a legit stream stores
      that reference as a VALUE, but a following REDUCE CALLS it:
      ``torch.empty(N)`` / ``empty_strided`` / ``zeros`` / ``rand`` allocate an
      attacker-sized tensor (``empty`` uninitialized) from a 73-byte pickle. The same
      surface reaches tensor-constructor METHOD DESCRIPTORS: a small tensor legitimately
      rebuilt from an embedded blob, fed to ``getattr(TensorBase, "new_empty")``, turned a
      1,681-byte pickle into a 16,000,000-byte uninitialized tensor. Only the vetted
      ``torch._utils._rebuild*`` reconstructors may be invoked.
    * ``bytes`` / ``bytearray`` given an integer SIZE rather than a buffer -- a direct
      zero-fill allocator the type-keyed belt never covered.
    * an ARGUMENT-BEARING ``torch.nn.Module`` construction, whose ``__init__`` allocates
      attacker-sized parameters (``_is_sized_module_construction``).

    Parameters
    ----------
    func:
        Callable / class the opcode is about to invoke.
    args:
        Argument tuple the opcode popped for it.
    kwargs:
        Keyword argument mapping the opcode popped (NEWOBJ_EX only), or ``None``.

    Returns
    -------
    str | None
        A refusal reason, or ``None`` when the call is not an allocation mediator.
    """

    if _NUMPY_RECONSTRUCT_FUNCS and any(func is helper for helper in _NUMPY_RECONSTRUCT_FUNCS):
        # Fail CLOSED on a malformed arg tuple: a security belt never admits a call it
        # cannot inspect.
        if not isinstance(args, tuple) or not args or _is_alloc_constructor_type(args[0]):
            mediated_type = args[0] if isinstance(args, tuple) and args else None
            return (
                "numpy _reconstruct mediating an allocation-constructor "
                f"({getattr(mediated_type, '__module__', '?')}."
                f"{getattr(mediated_type, '__qualname__', mediated_type)}) "
                "-- _reconstruct runs ndarray.__new__ on a pickle-supplied shape and "
                "returns attacker-sized, uninitialized-heap memory, reaching the same "
                "allocation the bare numpy.ndarray REDUCE is refused for"
            )
        return None
    if callable(func) and not isinstance(func, type) and _is_torch_reachable_callable(func):
        if not _is_vetted_torch_reduce_callable(func):
            return (
                "a torch callable "
                f"{getattr(func, '__module__', '') or getattr(func, '__objclass__', '')}."
                f"{getattr(func, '__name__', func)!r} invoked by a REDUCE -- torch tensor "
                "factories (empty / empty_strided / zeros / rand / ...) and tensor "
                "constructor METHODS (new_empty / new_zeros / ...) allocate attacker-sized "
                "tensors on the belt's behalf. A legit stream resolves torch callables as "
                "inert VALUES and only ever CALLS the vetted torch._utils._rebuild* "
                "reconstructors"
            )
        return None
    # IDENTITY, never ``in``/``==``: ``func`` is attacker-controlled and a resolved value
    # with a broadcasting ``__eq__`` (an ``ndarray``) would make a membership test raise
    # instead of decide.
    if (func is bytes or func is bytearray) and _requests_integer_sized_buffer(args):
        return (
            f"{getattr(func, '__name__', func)}(N) with an integer SIZE -- it allocates N "
            "zero bytes from a handful of pickle bytes (an out-of-memory DoS); a legit "
            "stream only ever copies a buffer already present in the stream"
        )
    if _is_sized_module_construction(func, args, kwargs):
        return (
            "an argument-bearing torch.nn.Module construction "
            f"{getattr(func, '__module__', '')}.{getattr(func, '__qualname__', func)} -- "
            "its __init__ allocates attacker-sized PARAMETERS on the belt's behalf "
            "(nn.Linear(65536, 65536) is ~16 GiB from a 48-byte pickle). A pickled module "
            "INSTANCE always arrives as a zero-argument cls.__new__(cls) plus a BUILD, so "
            "this refuses nothing a real artifact does"
        )
    return None


@dataclass(frozen=True)
class _DeferredForeignCallable:
    """Inert placeholder for a foreign recipe callable retained on an untrusted load.

    A saved ``FacetRegistrySnapshot`` may reference a user/test-registered facet
    recipe by identity (``@tl.facets.register``). Importing that foreign module at
    unpickle time would execute its top-level code -- exactly the load-time RCE
    surface this module closes. So under a default (untrusted) load the reference
    is LOAD-TOLERATED as this placeholder instead of imported: the trace loads
    structurally (the recipe reference is preserved for inspection / re-save), but
    the foreign module is NEVER imported and any attempt to CALL the recipe (facet
    computation, or a ``__reduce__`` construction gadget) fails closed.

    This mirrors the resolver's load-tolerate / execute-deny least-privilege split
    (``resolve_function_registry_key``): a foreign custom callable is retained as an
    unresolved reference on load and only imported+resolved under an explicit trust
    opt-in (``trust_custom_callables`` / ``allowed_custom_callable_modules``).

    Admission here is DETERMINISTIC: it depends only on the pickled ``(module,
    name)`` and the caller's trust flags -- never on process state (whether the
    module happens to be imported, or whether the recipe is currently in the live
    registry), which was the ordering-dependent load-failure bug.
    """

    module: str
    qualname: str

    def __call__(self, *args: Any, **kwargs: Any) -> Any:
        """Fail closed: an untrusted foreign recipe is never executed.

        Raises
        ------
        pickle.UnpicklingError
            Always. If invoked during unpickle (a ``__reduce__`` gadget) the load
            fails closed; if invoked later (facet computation) it signals that a
            trust opt-in is required to run the foreign recipe.
        """

        raise pickle.UnpicklingError(
            "Refusing to execute foreign custom callable "
            f"{self.module}:{self.qualname} resolved from an untrusted bundle. "
            "Pass trust_custom_callables=True or allowed_custom_callable_modules "
            "to import and run a trusted foreign recipe."
        )


def _is_torch_owned(obj: Any) -> bool:
    """Return whether a resolved object genuinely lives under the ``torch`` package.

    Trust in the torch branch of ``find_class`` is decided by the RESOLVED object's
    real ``__module__``, NEVER by the attacker-controlled pickled path. Pickle's
    ``STACK_GLOBAL`` / ``GLOBAL`` resolution attribute-walks a DOTTED name off the
    named module, so ``module="torch"`` with ``name="utils.collect_env.subprocess.Popen"``
    escapes the torch package into stdlib ``subprocess`` and returns
    ``subprocess.Popen`` (real module ``subprocess``) -- a ``type`` that a following
    pickle ``REDUCE`` would INVOKE to spawn a process (RCE). Requiring the resolved
    type's real module to be within ``torch`` denies that escape, mirroring the
    ``_is_torchlens_owned`` real-module check.
    """

    owner = str(getattr(obj, "__module__", "") or "")
    return owner == "torch" or owner.startswith("torch.")


def _is_torchlens_owned(obj: Any) -> bool:
    """Return whether a resolved object genuinely lives under the ``torchlens`` package.

    Trust for a callable is decided by the RESOLVED object's real ``__module__``,
    never by the pickled import path. This closes the "walk ``os.system`` off a
    torchlens module" pivot (``getattr(torchlens._io.tlspec, 'os').system`` has
    ``__module__ == 'posix'`` and is therefore denied) -- mirroring the resolver's
    identically-named check.
    """

    owner = str(getattr(obj, "__module__", "") or "")
    return owner == "torchlens" or owner.startswith("torchlens.")


# Extras-gated "appliance" subpackages whose ``__init__`` imports heavy FOREIGN
# third-party dependencies (rsatoolbox / brainscore_core for ``torchlens.neuro``,
# IPython / jupyter_client for ``torchlens.notebook``). Unlike the rest of the
# first-party ``torchlens.*`` namespace -- which is safe to import + inspect
# because it runs only our own already-installed code (see
# ``_is_torchlens_owned`` above) -- importing one of these two runs foreign
# top-level code with NO trust opt-in. A bundle-supplied global naming one of
# them (or a submodule) must therefore be EXCLUDED from the "torchlens is our
# own code" fast path below and instead fall through to receive the exact same
# deny-by-default / trust-opt-in / load-tolerate treatment already applied to a
# genuinely foreign module at the tail of ``find_class`` -- never passed to
# ``super().find_class`` (which imports the module) to make that determination.
_TORCHLENS_APPLIANCE_MODULES = _CALLABLE_APPLIANCE_MODULES


def _is_torchlens_appliance_module(module: str) -> bool:
    """Return whether ``module`` is (nested under) an extras-gated appliance package."""

    return any(
        module == appliance or module.startswith(appliance + ".")
        for appliance in _TORCHLENS_APPLIANCE_MODULES
    )


# Positive allowlist of VETTED-INERT first-party ``(module, qualname)`` DATA types
# (default-deny). The torchlens ``type`` branch of ``find_class`` historically
# admitted ANY resolved ``torchlens.*`` type unconditionally on the premise that a
# resolved type is "reconstructed via normal unpickling, never INVOKED with attacker
# args". That premise is FALSE: a pickle ``REDUCE`` may INVOKE any admitted type
# (its instance, or the type itself) with attacker-chosen arguments. The concrete
# load-time RCE (r23): ``torchlens.intervention.save.LazyImportRef`` is a frozen
# dataclass whose ``__call__(import_path, ...)`` resolves an ARBITRARY import path
# under a trust flag read from its OWN pickled field, so a crafted ``metadata.pkl``
# reconstructs ``LazyImportRef(import_path="os:system", trust_custom_callables=True)``
# and REDUCE-invokes it -> ``os.system`` on plain ``tl.load``.
#
# This closes that with the same default-deny discipline as the r22 callable gate: a
# torchlens type is admitted ONLY if it is on this frozen allowlist of pure DATA
# types -- dataclasses / enums / NamedTuples / plain accessor+value classes whose
# reconstruction runs no import / exec / filesystem / process side effect and which
# is NOT an import-sink / instance-callable gadget. Every other torchlens type --
# above all ``LazyImportRef`` and any callable/import-sink/exec type -- is DENIED.
#
# Derivation (default-deny): the set is the vetted-inert DATA-type inventory of the
# fixed set of first-party DATA modules that make up a scrubbed ``Trace``'s
# ``metadata.pkl`` (data_classes.* / ir.* / intervention.types / intervention._super
# / semantic.facets / quantities / capture.config+stop / _trace_state / _io.BlobRef /
# visualization.code_panel). It was materialized by enumerating those modules and
# admitting each class OWNED by the module (real ``__module__`` match, so no aliasing
# to a logic module) that (a) is NOT instance-callable and (b) carries NO custom
# ``__reduce__`` / ``__reduce_ex__``, then EXCLUDING live-view / error / exception
# classes (``Facet`` / ``FacetView`` / ``MissingFacet`` / ``*Error`` / ...) that never
# appear in scrubbed metadata. ``HelperSpec`` is the single vetted instance-callable
# exception (``__call__`` takes no attacker args; its ``factory`` is scrubbed to
# ``None`` before pickling, so it is not a reduce-invocable import sink). The result
# was cross-checked against the torchlens types the real unpickler resolves across the
# io / tlspec-runnable / semantic-facet / intervention / capture-oracle suites. The
# import-sink / logic modules -- above all ``torchlens.intervention.save`` (home of
# ``LazyImportRef``) -- are NOT data modules and are absent, so ``LazyImportRef`` is
# denied on both counts (module not curated; instance-callable import sink). A legit
# type not yet covered fails CLOSED (a load error surfacing in a test) and is added
# only after the same vetting -- never by re-admitting the blanket "any torchlens
# type" rule.
_SAFE_TORCHLENS_TYPES: frozenset[tuple[str, str]] = frozenset(
    {
        # Trace runtime-state enum + capture config / stop directives.
        ("torchlens._trace_state", "TraceState"),
        ("torchlens.capture.config", "InternalCaptureConfig"),
        ("torchlens.capture.stop", "StopDirective"),
        # Portable I/O blob reference (NamedTuple of ids).
        ("torchlens._io", "BlobRef"),
        # Buffer / grad / param / op / layer / module data records + accessors.
        ("torchlens.data_classes.buffer", "Buffer"),
        ("torchlens.data_classes.buffer", "BufferAccessor"),
        ("torchlens.data_classes.derived_grad", "DerivedGradAccessor"),
        ("torchlens.data_classes.derived_grad", "DerivedGradRecord"),
        ("torchlens.data_classes.derived_grad", "IntermediateDerivedGradAccessor"),
        ("torchlens.data_classes.derived_grad", "IntermediateDerivedGradRecord"),
        ("torchlens.data_classes.func_call_location", "FuncCallLocation"),
        ("torchlens.data_classes.grad_fn", "GradFn"),
        ("torchlens.data_classes.grad_fn", "GradFnAccessor"),
        ("torchlens.data_classes.grad_fn", "GradFnCallAccessor"),
        ("torchlens.data_classes.grad_fn_call", "GradFnCall"),  # locked rename target
        ("torchlens.data_classes.layer", "Layer"),
        ("torchlens.data_classes.layer", "LayerAccessor"),
        ("torchlens.data_classes.layer", "OpAccessor"),
        ("torchlens.data_classes.module", "HookInfo"),
        ("torchlens.data_classes.module", "Module"),
        ("torchlens.data_classes.module", "ModuleAccessor"),
        ("torchlens.data_classes.module", "ModuleCall"),
        ("torchlens.data_classes.module", "ModuleCallAccessor"),
        ("torchlens.data_classes.op", "GradientRecord"),
        ("torchlens.data_classes.op", "GradientRecordAccessor"),
        ("torchlens.data_classes.op", "Op"),
        ("torchlens.data_classes.op", "TensorLog"),  # locked rename-map alias of Op
        ("torchlens.data_classes.param", "Param"),
        ("torchlens.data_classes.param", "ParamAccessor"),
        # Prehook-provenance snapshots (frozen dataclasses, inert data).
        ("torchlens.data_classes.prehook", "TensorInputObservation"),
        ("torchlens.data_classes.prehook", "ModuleInputSnapshot"),
        ("torchlens.data_classes.prehook", "PreHookEffect"),
        # Backward-pass records. __setstate__ is the same inert version-compat
        # field-refill pattern Trace/Op use (default_fill_state); no side effects.
        ("torchlens.data_classes.backward_pass", "BackwardPass"),
        ("torchlens.data_classes.backward_pass", "BackwardPassAccessor"),
        # DROP-gated primitive-profile records (pre-release switch only).
        ("torchlens.data_classes.aten_op", "AtenOp"),
        ("torchlens.data_classes.aten_op", "OpRef"),
        ("torchlens.data_classes.aten_op", "_ModePausedInteriorGap"),
        ("torchlens.data_classes.aten_op", "_PrimitiveOpProfile"),
        ("torchlens.ir.events", "_AtenTensorFact"),
        ("torchlens.ir.events", "_AtenExecutionContext"),
        # Trace + conditional-control-flow data classes.
        ("torchlens.data_classes.trace", "Conditional"),
        ("torchlens.data_classes.trace", "ConditionalAccessor"),
        ("torchlens.data_classes.trace", "ConditionalArm"),
        ("torchlens.data_classes.trace", "ConditionalEvent"),
        ("torchlens.data_classes.trace", "ConditionalRoleRef"),
        ("torchlens.data_classes.trace", "ResolvedPostprocessing"),
        ("torchlens.data_classes.trace", "ResolvedPreprocessing"),
        ("torchlens.data_classes.trace", "Trace"),
        # Bundle Super* aligned-view wrappers (locked ``NodeView`` rename target).
        ("torchlens.intervention._super.super_op", "SuperLayer"),
        ("torchlens.intervention._super.super_op", "SuperLayerAccessor"),
        ("torchlens.intervention._super.super_op", "SuperOp"),  # locked rename target
        ("torchlens.intervention._super.super_op", "SuperOpAccessor"),
        ("torchlens.intervention._super.super_op", "TraceAccessor"),
        # Intervention-spec DATA types (portable recipe descriptors, not runtime
        # callables). ``HelperSpec`` is instance-callable but INERT: ``__call__``
        # takes no attacker args and its ``factory`` is scrubbed to ``None`` before
        # pickling, so it is not a reduce-invocable import sink.
        ("torchlens.intervention.types", "CapturedArgTemplate"),
        ("torchlens.intervention.types", "EdgeUseRecord"),
        ("torchlens.intervention.types", "FireRecord"),
        ("torchlens.intervention.types", "ForkFieldPolicy"),
        ("torchlens.intervention.types", "FrozenHookSpec"),
        ("torchlens.intervention.types", "FrozenInterventionSpec"),
        ("torchlens.intervention.types", "FrozenTargetSpec"),
        ("torchlens.intervention.types", "FrozenTargetValueSpec"),
        ("torchlens.intervention.types", "FunctionRegistryKey"),
        ("torchlens.intervention.types", "HelperSpec"),
        ("torchlens.intervention.types", "HookSpec"),
        ("torchlens.intervention.types", "InterventionDecision"),
        ("torchlens.intervention.types", "InterventionSpec"),
        ("torchlens.intervention.types", "LiteralTensor"),
        ("torchlens.intervention.types", "LiteralValue"),
        ("torchlens.intervention.types", "ParentRef"),
        ("torchlens.intervention.types", "Relationship"),
        ("torchlens.intervention.types", "TargetSpec"),
        ("torchlens.intervention.types", "TargetValueSpec"),
        ("torchlens.intervention.types", "TensorSliceSpec"),
        ("torchlens.intervention.types", "Unsupported"),
        # IR container / container-registry structural descriptors + enums.
        ("torchlens.ir.container", "ContainerSpec"),
        ("torchlens.ir.container", "DataclassField"),
        ("torchlens.ir.container", "DictKey"),
        ("torchlens.ir.container", "HFKey"),
        ("torchlens.ir.container", "NamedField"),
        ("torchlens.ir.container", "TupleIndex"),
        ("torchlens.ir.container_registry", "ContainerLeafOccurrence"),
        ("torchlens.ir.container_registry", "ContainerRecord"),
        ("torchlens.ir.container_registry", "ContainerRegistry"),
        ("torchlens.ir.container_registry", "ContainerSnapshot"),
        ("torchlens.ir.container_registry", "FuncSite"),
        ("torchlens.ir.container_registry", "IdentityEntry"),
        ("torchlens.ir.container_registry", "ModelSite"),
        ("torchlens.ir.container_registry", "ModuleSite"),
        ("torchlens.ir.container_registry", "Phase"),
        ("torchlens.ir.container_registry", "Role"),
        ("torchlens.ir.container_registry", "WalkResult"),
        # Device / dtype / tensor / param reference value types.
        ("torchlens.ir.refs", "DeferredRef"),
        ("torchlens.ir.refs", "DeviceRef"),
        ("torchlens.ir.refs", "DtypeRef"),
        ("torchlens.ir.refs", "ParamRef"),
        ("torchlens.ir.refs", "ReservedLabel"),
        ("torchlens.ir.refs", "TensorRef"),
        # Physical-quantity value types.
        ("torchlens.quantities", "Bytes"),
        ("torchlens.quantities", "Duration"),
        ("torchlens.quantities", "Flops"),
        ("torchlens.quantities", "Macs"),
        ("torchlens.quantities", "Quantity"),
        ("torchlens.quantities", "_FloatQuantity"),
        ("torchlens.quantities", "_IntQuantity"),
        # Semantic facet snapshot + recipe descriptor data types.
        ("torchlens.semantic.facets", "AbsenceReason"),
        ("torchlens.semantic.facets", "FacetCapabilityFlags"),
        ("torchlens.semantic.facets", "FacetContribution"),
        ("torchlens.semantic.facets", "FacetMenuItem"),
        ("torchlens.semantic.facets", "FacetRecipe"),
        ("torchlens.semantic.facets", "FacetRegistrySnapshot"),
        ("torchlens.semantic.facets", "FacetSpec"),
        ("torchlens.semantic.facets", "TransformPrimitive"),
        ("torchlens.semantic.facets", "_RegisteredRecipe"),
        # Visualization code-panel source text value type.
        ("torchlens.visualization.code_panel", "SourceText"),
    }
)


# Exact (module, name) globals resolved directly. Every entry is either a pure
# data container/value type or a pure tensor-reconstruction helper -- none can
# execute attacker code merely by being resolved or called on pickle-provided
# arguments.
_SAFE_EXPLICIT_GLOBALS: frozenset[tuple[str, str]] = frozenset(
    {
        ("collections", "OrderedDict"),
        ("collections", "defaultdict"),
        ("collections", "Counter"),
        # Pure-data builtin constructors / base type. Explicitly EXCLUDES getattr
        # / eval / exec / __import__ / compile / open and every other code-exec
        # builtin. ``object`` is the base type used by default ``__reduce_ex__``.
        ("builtins", "object"),
        ("builtins", "list"),
        ("builtins", "set"),
        ("builtins", "frozenset"),
        ("builtins", "dict"),
        ("builtins", "tuple"),
        ("builtins", "bytearray"),
        ("builtins", "bytes"),
        ("builtins", "complex"),
        ("builtins", "int"),
        ("builtins", "float"),
        ("builtins", "str"),
        ("builtins", "bool"),
        ("builtins", "slice"),
        # The ``Ellipsis`` singleton (``...``). Pickle resolves it as a bare
        # ``builtins.Ellipsis`` global (no dedicated opcode, unlike ``None``);
        # resolving the name just returns the existing singleton object, so this
        # is strictly inert -- no different in kind from admitting the ``slice``
        # constructor above.
        ("builtins", "Ellipsis"),
        # torch C callable-holder classes (used as getattr targets and, rarely,
        # as bare globals). They are types; returning them is inert -- the only
        # exploit path (getattr pivot) is closed by ``_safe_getattr``.
        ("torch._C", "TensorBase"),
        ("torch._C", "_TensorBase"),
        ("torch._C", "_VariableFunctionsClass"),
        # NumPy numeric-array reconstruction helpers (raw-input ndarrays and
        # preview-backend numeric payloads). These rebuild arrays from a raw
        # numeric buffer / dtype and execute no attacker code for numeric dtypes.
        # Both the legacy (<2.0) and new (>=2.0) private module paths are covered.
        ("numpy", "dtype"),
        ("numpy", "ndarray"),
        ("numpy.core.numeric", "_frombuffer"),
        ("numpy._core.numeric", "_frombuffer"),
        ("numpy.core.multiarray", "_reconstruct"),
        ("numpy._core.multiarray", "_reconstruct"),
    }
)

# Preview-backend array module roots whose resolved *types* / dtype instances are
# admitted (MLX / Paddle / JAX numeric array + dtype reconstruction). Only ``type``
# objects and framework dtype-like instances are admitted; callables are not.
_PREVIEW_ARRAY_MODULE_ROOTS: tuple[str, ...] = ("mlx.core",)


def _build_allowed_getattr_objects() -> frozenset[Any]:
    """Resolve the torch C callable-holder classes admitted as getattr targets.

    Returns
    -------
    frozenset[Any]
        The torch C classes off which ``getattr`` may legitimately fetch a
        tensor-method reference. Missing names (torch version drift) are skipped.
    """

    objects: list[Any] = []
    for name in ("TensorBase", "_TensorBase", "_VariableFunctionsClass"):
        holder = getattr(torch._C, name, None)
        if isinstance(holder, type):
            objects.append(holder)
    return frozenset(objects)


_ALLOWED_GETATTR_OBJECTS: frozenset[Any] = _build_allowed_getattr_objects()


def _safe_getattr(obj: Any, name: Any) -> Any:
    """Restricted ``getattr`` admitted in place of ``builtins.getattr``.

    Legitimate bundle metadata reconstructs torch C tensor-method references via
    ``getattr(torch._C.TensorBase, "sum")`` and similar. Admitting raw
    ``builtins.getattr`` would enable the classic pickle pivot
    ``getattr(<any function>, "__globals__")`` -> ``eval`` / ``exec``. This
    wrapper structurally blocks that pivot by restricting the target object to
    the enumerated torch C callable-holder classes; any other target -- including
    an already-resolved torchlens recipe function -- fails closed.

    Restricting the TARGET is not enough (round-5): the admitted
    ``_VariableFunctionsClass`` holder also exposes side-effecting file-I/O
    builtins -- notably ``torch.from_file`` -- so ``getattr(_VariableFunctionsClass,
    "from_file")`` would return a callable that CREATES/TRUNCATES or READS an
    arbitrary file when used as the callable of a following pickle ``REDUCE``. The
    resolved callable is therefore additionally gated through the shared
    callable-safety policy (``is_pure_forward_callable``): a pure tensor-method /
    factory reference (``sum`` / ``from_numpy`` / ``frombuffer``) is returned, while
    ``from_file`` and any other side-effecting builtin fail closed. The policy is
    imported lazily to keep this early-imported security front door free of
    import-order coupling.

    Parameters
    ----------
    obj:
        Attribute-access target supplied by the pickle stream.
    name:
        Attribute name supplied by the pickle stream.

    Returns
    -------
    Any
        ``getattr(obj, name)`` for an admitted torch C target and a non-side-effecting
        result.

    Raises
    ------
    pickle.UnpicklingError
        If ``obj`` is not an admitted torch C callable-holder class, ``name`` is not
        a string, or the resolved attribute is a side-effecting callable.
    """

    if not isinstance(name, str) or obj not in _ALLOWED_GETATTR_OBJECTS:
        raise pickle.UnpicklingError(
            f"Blocked getattr during bundle metadata unpickle: getattr on {obj!r} is not permitted."
        )
    resolved = getattr(obj, name)
    if callable(resolved):
        from ..utils._callable_safety import is_pure_forward_callable

        if not is_pure_forward_callable(resolved):
            raise pickle.UnpicklingError(
                "Blocked side-effecting torch callable during bundle metadata "
                f"unpickle: getattr(..., {name!r}) is not a pure forward/tensor op."
            )
    return resolved


def _safe_load_from_bytes(data: bytes) -> Any:
    """Restricted replacement for ``torch.storage._load_from_bytes``.

    The stock helper reconstructs an embedded tensor storage by calling
    ``torch.load`` with the *unsafe* legacy default (an unrestricted nested
    unpickler == RCE). This wrapper forces ``weights_only=True`` so the nested
    load routes through torch's own restricted unpickler; a malicious embedded
    payload therefore fails closed instead of executing.

    Parameters
    ----------
    data:
        Serialized tensor-storage bytes from the pickle stream.

    Returns
    -------
    Any
        The reconstructed storage/tensor from a weights-only nested load.

    Raises
    ------
    pickle.UnpicklingError
        If the running torch is affected by CVE-2025-32434 (so even
        ``weights_only=True`` is a working RCE), or if the nested weights-only load
        fails (including because it refused a disallowed global).
    """

    # CVE-2025-32434: on torch <= 2.5.1, ``torch.load(..., weights_only=True)`` is
    # ITSELF a remote-code-execution -- the pre-2.6 weights-only unpickler could be
    # bypassed -- so forwarding attacker bytes into it is not a safe restricted
    # load at all. Fail closed on any runtime that lacks the 2.6.0 fix (feature-
    # detected via the named ``HAS_SAFE_WEIGHTS_ONLY_LOAD`` capability, surfaced in
    # ``tl.compat.report()`` / ``doctor()``). Imported lazily to keep this early
    # security front door free of import-order coupling (mirrors ``_safe_getattr``).
    from ..utils._torch_compat import HAS_SAFE_WEIGHTS_ONLY_LOAD

    if not HAS_SAFE_WEIGHTS_ONLY_LOAD:
        raise pickle.UnpicklingError(
            "Refusing to reconstruct an embedded tensor during bundle metadata "
            "unpickle: the running torch is affected by CVE-2025-32434 "
            "(torch.load(weights_only=True) remote-code-execution, fixed in torch "
            "2.6.0). Upgrade torch to >= 2.6 to load bundles that embed tensor "
            "storages."
        )
    try:
        loaded = torch.load(io.BytesIO(data), weights_only=True)
    except Exception as exc:  # noqa: BLE001 -- fail closed, never re-exec unsafely
        raise pickle.UnpicklingError(
            "Blocked unsafe embedded-tensor load during bundle metadata unpickle."
        ) from exc
    return _freeze_embedded_storage(loaded)


def _frozen_untyped_storage(storage: Any) -> Any:
    """Return a NON-resizable ``UntypedStorage`` holding the same bytes as ``storage``.

    ``torch.frombuffer`` over a host ``bytearray`` produces a storage whose allocator
    cannot reallocate, so ``resizable()`` is ``False`` and torch's own ``set_`` refuses to
    grow it. The copy is bounded by ``storage`` -- itself bounded by the embedded blob
    already present in the pickle stream -- so it is strictly proportional.

    Parameters
    ----------
    storage:
        Host (CPU) untyped storage to copy.

    Returns
    -------
    Any
        A non-resizable untyped storage with identical bytes.
    """

    return torch.frombuffer(bytearray(bytes(storage)), dtype=torch.uint8).untyped_storage()


def _freeze_embedded_storage(loaded: Any) -> Any:
    """Make an embedded-blob result NON-RESIZABLE so it cannot be amplified (r6).

    The nested ``weights_only`` load bounds the embedded payload by the bytes present in
    the stream, but it does not bound what a LATER opcode may grow that payload into. When
    the embedded blob uses the LEGACY (non-zipfile) ``torch.save`` format the reconstructed
    storage is RESIZABLE, and the vetted ``torch._utils._rebuild*`` reconstructors -- which
    must stay REDUCE-invocable, they are the legitimate tensor path -- accept a
    pickle-supplied ``size``/``stride`` and call ``set_``, which RESIZES the storage
    upward. Measured: a 354-byte pickle chaining
    ``_rebuild_tensor_v2(_load_from_bytes(<4-byte legacy blob>), 0, (100_000_000,), (1,),
    False, None)`` yielded a 100 MB tensor -- roughly 282,000x amplification, unbounded in
    the requested size, and reached through a callable the belt deliberately allows.

    Bounding this at the CONSUMER would mean re-deriving the byte extent for every
    ``_rebuild*`` signature and keeping that in step with torch. Bounding it at the SOURCE
    is signature-independent and enforced by torch itself: a non-resizable storage makes
    ``set_`` raise ``RuntimeError("Trying to resize storage that is not resizable")`` for
    EVERY present and future consumer, while an exact-fit view -- the only thing an honest
    stream asks for -- still succeeds unchanged.

    A resizable storage on a non-CPU device cannot be frozen (torch exposes no
    same-device non-resizable allocation), so it fails closed. That refuses nothing real:
    a genuine torchlens bundle never emits ``_load_from_bytes`` at all (asserted by
    ``tests/test_r4_metadata_unpickle_rce.py``), and the modern zipfile ``torch.save``
    format -- what every current writer produces -- already yields a non-resizable storage
    and is returned untouched.

    Parameters
    ----------
    loaded:
        Object returned by the nested weights-only load.

    Returns
    -------
    Any
        ``loaded`` itself when already non-resizable, else a frozen equivalent.

    Raises
    ------
    pickle.UnpicklingError
        If a resizable storage cannot be frozen (non-CPU device, or a failed copy).
    """

    typed_storage_type = getattr(torch.storage, "TypedStorage", ())
    storage: Any
    if isinstance(loaded, torch.Tensor):
        storage = loaded.untyped_storage()
    elif isinstance(loaded, torch.UntypedStorage):
        storage = loaded
    elif typed_storage_type and isinstance(loaded, typed_storage_type):
        # ``TypedStorage.untyped()`` emits torch's TypedStorage-removal ``UserWarning``;
        # the private attribute it delegates to is the same object and stays quiet, so a
        # security load never spends a warning the caller cannot act on.
        storage = getattr(loaded, "_untyped_storage", None)
        if storage is None:  # pragma: no cover - torch layout drift.
            with warnings.catch_warnings():
                warnings.simplefilter("ignore", UserWarning)
                storage = loaded.untyped()
    else:
        # Not a storage-backed result; nothing a ``_rebuild*`` can grow.
        return loaded

    try:
        if not storage.resizable():
            return loaded
    except Exception:  # pragma: no cover - defensive; exotic storage without the predicate.
        pass

    if str(getattr(storage, "device", "cpu")) != "cpu":
        raise pickle.UnpicklingError(
            "Blocked a RESIZABLE non-CPU embedded tensor storage during bundle metadata "
            "unpickle: it can be grown by a following _rebuild* REDUCE into an "
            "attacker-sized allocation, and torch exposes no same-device non-resizable "
            "allocation to bound it. Re-save the artifact with the modern (zipfile) "
            "torch.save format, which yields a non-resizable storage."
        )

    try:
        frozen = _frozen_untyped_storage(storage)
        if isinstance(loaded, torch.Tensor):
            rebuilt = torch.empty(0, dtype=loaded.dtype, device=loaded.device)
            rebuilt.set_(frozen, loaded.storage_offset(), loaded.size(), loaded.stride())
            if loaded.requires_grad:
                rebuilt.requires_grad_(True)
            return rebuilt
        if isinstance(loaded, torch.UntypedStorage):
            return frozen
        return torch.storage.TypedStorage(wrap_storage=frozen, dtype=loaded.dtype, _internal=True)
    except Exception as exc:  # noqa: BLE001 -- fail closed, never hand back a growable storage
        raise pickle.UnpicklingError(
            "Blocked an embedded tensor storage during bundle metadata unpickle: it is "
            "RESIZABLE (legacy torch.save format) and could not be frozen, so a following "
            "_rebuild* REDUCE could grow it into an attacker-sized allocation."
        ) from exc


# Base pure-Python opcode handlers, captured from the dispatch table. typeshed does
# NOT expose ``load_build`` / ``load_reduce`` / ``load_newobj`` / ``load_newobj_ex`` as
# named methods on ``pickle._Unpickler``, so the Layer-2 overrides delegate to these
# captured unbound functions (each called with ``self``) rather than
# ``pickle._Unpickler.load_build(self)`` (which mypy cannot resolve).
_BASE_LOAD_BUILD = pickle._Unpickler.dispatch[pickle.BUILD[0]]
_BASE_LOAD_REDUCE = pickle._Unpickler.dispatch[pickle.REDUCE[0]]
_BASE_LOAD_NEWOBJ = pickle._Unpickler.dispatch[pickle.NEWOBJ[0]]
_BASE_LOAD_NEWOBJ_EX = pickle._Unpickler.dispatch[pickle.NEWOBJ_EX[0]]


def _exception_arose_outside_vm(exc: BaseException) -> bool:
    """Return whether any traceback frame of ``exc`` lies outside the unpickle VM.

    LOCUS discriminator for the ``SafeBundleUnpickler.load()`` boundary (r51
    secA_1, narrowed): a VM-internal corruption failure -- stack underflow
    (``IndexError``), truncated fixed-width read (``struct.error``), missing memo
    key (``KeyError``), bad utf-8 (``UnicodeDecodeError``), truncation
    (``EOFError``) -- is raised either by pure-Python VM code in stdlib
    ``pickle.py`` / this module, or by a C call (``struct.unpack`` / ``str``
    decode / dict lookup) that adds NO Python frame; its traceback never leaves
    the two VM files. An APPLICATION/reconstruction failure -- a REDUCE
    callable's body, a ``__setstate__``, a ``find_class`` module import
    (importlib frames), the ``_RenameAwareUnpickler`` rename hook (a bundle.py
    frame) -- necessarily executes at least one Python frame outside them.
    Classifying by WHERE the exception arose is version-robust where enumerating
    exception TYPES is fragile: both file names are derived from live code
    objects, so the comparison matches the code that actually runs under any
    install layout, and if a future Python relocated VM internals the secA
    corruption-corpus tests fail LOUD (a raw builtin escapes) rather than
    silently misclassifying.
    """

    tb = exc.__traceback__
    while tb is not None:
        if tb.tb_frame.f_code.co_filename not in _VM_INTERNAL_CODE_FILES:
            return True
        tb = tb.tb_next
    return False


_VM_INTERNAL_CODE_FILES: frozenset[str] = frozenset(
    {
        # The stdlib pure-Python VM (pickle.py), via the executing code object.
        pickle._Unpickler.load.__code__.co_filename,
        # This module: the Layer-1/Layer-2 overrides and the load() boundary.
        _exception_arose_outside_vm.__code__.co_filename,
    }
)


class _DenyMissingDispatch(dict):
    """Opcode dispatch table that raises ``UnpicklingError`` on an unknown opcode.

    The C ``pickle.Unpickler`` raises ``pickle.UnpicklingError`` ("invalid load key")
    on a corrupt / truncated / unknown opcode; the pure-Python ``pickle._Unpickler``
    instead raises a bare ``KeyError`` from its ``dispatch[key]`` lookup. Migrating the
    base class to pure-Python (r49, secA_1) must NOT change that observable failure mode
    -- callers (e.g. ``bundle.py::_load_trace_payload``) catch ``pickle.UnpicklingError``
    to translate a corrupt ``metadata.pkl`` into a clean ``TorchLensIOError``. A missing
    opcode here therefore surfaces as ``UnpicklingError``, matching the C VM.

    This hook covers ONLY the unknown-opcode facet. The OTHER corrupt-input facets the
    pure-Python VM leaks -- a stack underflow on a valid opcode (``IndexError``), a
    truncated fixed-width read (``struct.error``), a missing memo key (``KeyError``), a
    bad ``SHORT_BINUNICODE`` (``UnicodeDecodeError``), etc. -- are normalized to
    ``UnpicklingError`` by the ``SafeBundleUnpickler.load()`` boundary (r51, secA_1),
    which wraps the VM run and normalizes failures whose traceback stays INSIDE the VM
    (locus-classified); application/reconstruction failures keep their identity.
    """

    def __missing__(self, key: int) -> None:
        raise pickle.UnpicklingError(f"invalid load key, {chr(key)!r}.")


class SafeBundleUnpickler(pickle._Unpickler):
    """Default-deny unpickler for untrusted TorchLens bundle ``metadata.pkl``.

    Applies an optional rename map (for classes moved by locked renames) and then
    gates every resolved global through the module allowlist. Anything outside the
    allowlist raises :class:`pickle.UnpicklingError` without importing or calling
    attacker-chosen code.

    Base class (r49, secA_1): this is the PURE-PYTHON ``pickle._Unpickler``, NOT the C
    ``pickle.Unpickler``. The C VM runs REDUCE/BUILD entirely in C -- a subclass method
    override of ``load_build`` is *bypassed* -- so opcode-level policy (Layer 2 below)
    is impossible on the C base. The pure-Python VM dispatches each opcode through a
    CLASS-LEVEL ``dispatch`` dict of unbound functions bound at class-body time; merely
    ``def load_build`` on the subclass is INERT (the dict still points at the base
    function). We therefore REBUILD ``dispatch`` in the class body (see the block after
    ``find_class``) so the overrides are actually invoked. The one-time pure-Python cost
    at ``tl.load()`` (tens of ms on a realistic ``metadata.pkl``) is never a hot path.
    """

    def __init__(
        self,
        file: BinaryIO,
        *,
        rename_map: Mapping[tuple[str, str], tuple[str, str]] | None = None,
        trust_custom_callables: bool = False,
        allowed_custom_callable_modules: Collection[str] | None = None,
    ) -> None:
        """Initialize the restricted unpickler.

        Parameters
        ----------
        file:
            Binary file object positioned at the start of a pickle stream.
        rename_map:
            Optional ``(module, name) -> (module, name)`` remapping applied before
            allowlist resolution, preserving load of legitimately-renamed classes.
        trust_custom_callables:
            Whether to admit a foreign (non-torch/torchlens/numpy) callable by
            importing and resolving it. Mirrors the intervention-resolver contract:
            ``False`` (default) denies unless the callable is already registered in
            the live facet registry (a positive allowlist against trusted live
            state that never triggers a fresh import).
        allowed_custom_callable_modules:
            Optional narrow allowlist of foreign module names whose callables may be
            imported and resolved even when ``trust_custom_callables`` is ``False``.
        """

        super().__init__(file)
        self._rename_map: Mapping[tuple[str, str], tuple[str, str]] = rename_map or {}
        self._trust_custom_callables = trust_custom_callables
        self._allowed_custom_callable_modules = (
            frozenset(allowed_custom_callable_modules)
            if allowed_custom_callable_modules is not None
            else None
        )

    def load(self) -> Any:
        """Run the pure-Python VM, normalizing ONLY VM-internal corruption failures.

        The C ``pickle.Unpickler`` contract this preserves has TWO halves:
        (1) every corrupt / truncated / malformed STREAM failure surfaces as
        ``pickle.UnpicklingError`` -- which the load sites
        (``bundle.py::_load_trace_payload`` / ``_load_unified_bundle``) translate
        into a clean :class:`~torchlens._io._errors.TorchLensIOError`; and (2) an
        exception raised by APPLICATION code the stream invokes (a REDUCE
        callable, ``__setstate__``, a ``find_class`` module import) propagates RAW
        with its identity intact -- the C VM never relabeled those, and the load
        sites enumerate that family (``TypeError`` / ``ValueError`` /
        ``ImportError`` / ...) to attach the original exception as the DIRECT
        ``__cause__`` of ``TorchLensIOError`` (the legacy-bundle live-resource
        contract).

        The pure-Python base VM leaks half (1) as raw builtins (``IndexError`` /
        ``struct.error`` / ``KeyError`` / ``UnicodeDecodeError`` / ``EOFError``);
        ``_DenyMissingDispatch`` restores only the unknown-opcode facet. This
        boundary restores the WHOLE family, classified by LOCUS
        (``_exception_arose_outside_vm``), never by exception type: only a failure
        whose traceback stays inside the VM itself is stream corruption; a failure
        that executed application frames keeps its identity and direct cause.

        Nothing legitimate is masked: a valid stream returns normally, every
        deliberate refusal surface in this unpickler already raises ONLY
        ``pickle.UnpicklingError`` (which passes through unchanged), and
        ``except Exception`` (not ``BaseException``) preserves
        ``KeyboardInterrupt`` / ``SystemExit`` / ``GeneratorExit``. Residual,
        stated honestly: an interpreter-raised CALL-SITE failure on an admitted
        reconstructor (arity mismatch, or a C-implemented callable raising with
        no Python frame) executed ZERO application code, shows only VM frames,
        and is normalized as corrupt -- semantically true (the stream is
        inconsistent with the admitted callable) and unreachable for the
        live-resource contract, which by definition executes application code.
        """

        try:
            return super().load()
        except pickle.UnpicklingError:
            raise
        except Exception as exc:  # noqa: BLE001 -- locus-classified; see docstring
            if _exception_arose_outside_vm(exc):
                # Application/reconstruction failure on a well-formed stream: NOT
                # corruption; never labeled so. Propagate raw so load sites keep
                # the original type as the DIRECT __cause__ of TorchLensIOError.
                raise
            raise pickle.UnpicklingError(
                f"corrupt or malformed pickle stream: {type(exc).__name__}: {exc}"
            ) from exc

    def _custom_module_trusted(self, module: str) -> bool:
        """Return whether a foreign module may be imported+resolved via trust flags.

        Parameters
        ----------
        module:
            Foreign pickled module path.

        Returns
        -------
        bool
            ``True`` if the module is explicitly allowlisted, or broad trust is on.
        """

        if self._allowed_custom_callable_modules is not None:
            return module in self._allowed_custom_callable_modules
        return self._trust_custom_callables

    def find_class(self, module: str, name: str) -> Any:  # noqa: C901 -- explicit policy
        """Resolve a pickled global only if it is on the metadata allowlist.

        Parameters
        ----------
        module:
            Pickled module path.
        name:
            Pickled global name.

        Returns
        -------
        Any
            The resolved class / value / safe wrapper.

        Raises
        ------
        pickle.UnpicklingError
            If the (possibly renamed) global is not admitted by the allowlist.
        """

        module, name = self._rename_map.get((module, name), (module, name))

        # Safe wrappers for the two legitimately-needed but individually-dangerous
        # callables.
        if (module, name) == ("builtins", "getattr"):
            return _safe_getattr
        if (module, name) == ("torch.storage", "_load_from_bytes"):
            return _safe_load_from_bytes

        # Exact-pair allowlist of inert data/value types and tensor reconstructors.
        if (module, name) in _SAFE_EXPLICIT_GLOBALS:
            return super().find_class(module, name)

        # Pure torch tensor reconstruction helpers. ``_rebuild_*`` functions only
        # reassemble tensors from already-resolved (allowlisted) components; any
        # class they receive as an argument was itself gated through find_class.
        #
        # HARDENING (r28, A-R28-1 CRITICAL default-victim RCE): the prior fast-path
        # returned ``super().find_class`` for ANY ``name`` starting with ``_rebuild``
        # with NO further gate. Under pickle protocol >= 4 the pickled ``name`` is
        # attribute-walked, so a DOTTED name such as
        # ``_rebuild_tensor_v2.__globals__.get`` walks OFF the reconstructor function
        # into ``torch._utils`` module globals and returns a REDUCE-invocable bound
        # ``dict.get`` -> ``_import_dotted_name`` -> ``os.system`` -- a load-time RCE
        # (fires at metadata unpickle, no ``.run()`` needed). This is the SAME
        # dotted-walk escape class the r27 torch-type / preview branches close; the
        # ``_rebuild`` branch was MISSED. Legit ``_rebuild_*`` reconstructor names NEVER
        # contain a dot, so (a) refuse any DOTTED ``name`` BEFORE resolving (never
        # trigger the walk), and (b) after resolving, positively require a torch-owned,
        # non-type CALLABLE (the reconstructors are functions of ``torch._utils``).
        if module == "torch._utils" and name.startswith("_rebuild"):
            if "." in name:
                raise pickle.UnpicklingError(
                    "Blocked dotted torch._utils._rebuild name during bundle metadata "
                    f"unpickle: {module}.{name} (a dotted name attribute-walks off the "
                    "reconstructor into module globals; legit _rebuild_* names have no dot)."
                )
            obj = super().find_class(module, name)
            if not (callable(obj) and _is_torch_owned(obj) and not isinstance(obj, type)):
                raise pickle.UnpicklingError(
                    "Blocked non-torch-owned / non-callable torch._utils._rebuild "
                    f"resolution during bundle metadata unpickle: {module}.{name} "
                    f"(resolved to {str(getattr(obj, '__module__', '') or '')!r})."
                )
            return obj

        # torch package: admit value instances (dtype / layout / memory_format /
        # ``torch.Size`` etc.) and a resolved DATA ``type`` (tensor / Module /
        # storage classes, e.g. ``torch.nn.modules.linear.Identity``). Resolving a
        # global merely references it, and constructing a torch DATA type executes
        # no attacker code -- but constructing an I/O-capable torch type
        # (``PyTorchFileReader`` / ``PyTorchFileWriter`` / ``FileCheck`` /
        # ``PackageImporter`` / ``torch.serialization.*`` / ``torch.jit.*``) opens/
        # reads/writes an attacker-named filesystem path at unpickle time. Those
        # I/O / serialization / packaging / jit types are DENIED via
        # ``_torch_type_denied`` (module-prefix + structural name guard), aligning
        # with torch's own ``weights_only`` allowlist which excludes them. Non-type
        # callables (e.g. ``torch.serialization.load``) are denied; the two
        # individually-dangerous ones are wrapped above.
        if module == "torch" or module.startswith("torch."):
            obj = super().find_class(module, name)
            if isinstance(obj, (torch.dtype, torch.layout, torch.memory_format)):
                return obj
            if isinstance(obj, type):
                # POSITIVELY require the RESOLVED type's real module to be within the
                # torch package. A DOTTED pickled name attribute-walks OFF torch and
                # can escape into stdlib -- e.g. ``torch`` /
                # ``utils.collect_env.subprocess.Popen`` returns ``subprocess.Popen``
                # (real module ``subprocess``), which a following ``REDUCE`` would
                # INVOKE to spawn a process (RCE). ``_torch_type_denied`` (a name /
                # module-prefix denylist) would NOT catch it -- ``Popen`` matches no
                # token and ``subprocess`` no prefix -- so the escape is denied here
                # by the positive real-module gate BEFORE the I/O-type denylist runs.
                if not _is_torch_owned(obj):
                    raise pickle.UnpicklingError(
                        "Blocked non-torch-owned type resolved via the torch "
                        f"namespace during bundle metadata unpickle: {module}.{name} "
                        f"resolved to a type owned by "
                        f"{str(getattr(obj, '__module__', '') or '')!r} (a dotted "
                        "name that escapes the torch package is refused)."
                    )
                # STORAGE-CONSTRUCTOR deny (r49, secA_1). A torch STORAGE class is a
                # torch-owned DATA ``type`` and would otherwise pass here, but its
                # construction is NOT inert: a following ``REDUCE`` of
                # ``torch.UntypedStorage(N)`` allocates N raw bytes (a multi-GiB alloc
                # DoS) and is the sole source of an uninitialized-heap storage a BUILD
                # could rebind onto a tensor. torch's own ``weights_only`` baseline
                # lists the real ``torch.storage.{Typed,Untyped}Storage`` classes, so
                # denying them makes this unpickler a STRICT SUBSET of that baseline.
                # ``.tlspec`` never needs one (payloads are BlobRefs; embedded storages
                # route through the wrapped ``_safe_load_from_bytes`` nested load).
                if _is_torch_storage_type(obj):
                    raise pickle.UnpicklingError(
                        "Blocked torch storage constructor during bundle metadata "
                        f"unpickle: {module}.{name} (constructing a storage allocates "
                        "raw memory -- an UntypedStorage(N) out-of-memory DoS and the "
                        "source of an uninitialized-heap tensor; .tlspec tensor "
                        "payloads are BlobRefs and embedded storages load through the "
                        "wrapped weights_only _load_from_bytes path)."
                    )
                if _torch_type_denied(module, name, obj):
                    raise pickle.UnpicklingError(
                        "Blocked torch I/O / serialization type during bundle "
                        f"metadata unpickle: {module}.{name} (construction performs "
                        "filesystem access; not an inert data type)."
                    )
                return obj
            raise pickle.UnpicklingError(
                f"Blocked disallowed torch global during bundle metadata unpickle: {module}.{name}."
            )

        # Preview-backend numeric array/dtype reconstruction (MLX / Paddle / JAX):
        # admit resolved ``type`` objects and framework dtype-like instances only.
        if any(
            module == root or module.startswith(root + ".") for root in _PREVIEW_ARRAY_MODULE_ROOTS
        ):
            obj = super().find_class(module, name)
            if isinstance(obj, type):
                # As in the torch branch: a resolved TYPE is admitted only when its
                # OWN real module is within a preview-array root. A DOTTED pickled
                # name (e.g. ``mlx.core`` / ``...subprocess.Popen``) attribute-walks
                # OFF the preview package and would otherwise return an escaped,
                # unrelated (possibly code-exec) type unconditionally.
                type_module = str(getattr(obj, "__module__", "") or "")
                if any(
                    type_module == root or type_module.startswith(root + ".")
                    for root in _PREVIEW_ARRAY_MODULE_ROOTS
                ):
                    return obj
                raise pickle.UnpicklingError(
                    "Blocked non-preview-owned type resolved via a preview-backend "
                    f"namespace during bundle metadata unpickle: {module}.{name} "
                    f"resolved to a type owned by {type_module!r}."
                )
            resolved_module = getattr(type(obj), "__module__", "") or ""
            if any(
                resolved_module == root or resolved_module.startswith(root + ".")
                for root in _PREVIEW_ARRAY_MODULE_ROOTS
            ):
                return obj
            raise pickle.UnpicklingError(
                "Blocked disallowed preview-backend global during bundle metadata "
                f"unpickle: {module}.{name}."
            )

        # TorchLens-owned metadata: admit classes always, and a NARROW, vetted set
        # of first-party CALLABLES. Importing a torchlens submodule runs only
        # trusted first-party code, so it is safe to import + inspect the resolved
        # object's true owner. Trust is decided by the resolved ``__module__``,
        # NEVER by the pickled path: a key like ``torchlens._io.tlspec`` /
        # ``os.system`` walks attributes off a torchlens module to reach
        # ``os.system`` (real module ``posix``), which is NOT torchlens-owned and is
        # therefore denied.
        #
        # A resolved TYPE is admitted -- it is reconstructed via normal unpickling,
        # never INVOKED with attacker args. A resolved CALLABLE is admitted only if
        # it is a vetted-INERT first-party callable (public facet recipe / transform
        # / helper that cannot import/exec/open/spawn): a pickle ``REDUCE`` INVOKES
        # the admitted callable with attacker args, and the pre-r21 blanket
        # ``_is_torchlens_owned`` admission trusted EVERY torchlens-owned callable --
        # including the private import gadget ``torchlens.utils._module_is_installed``
        # (``importlib.import_module`` of attacker input == confirmed load-time RCE).
        # The gate is DETERMINISTIC (public-name + side-effect-name guard), never
        # keyed off the live facet registry (that ordering-dependent snapshot was a
        # prior load-failure bug).
        #
        # EXCLUDES the extras-gated appliance packages (``torchlens.neuro`` /
        # ``torchlens.notebook``): importing THOSE runs foreign third-party code,
        # so a global naming one of them must never reach ``super().find_class``
        # here -- it falls through to the foreign-global handling below instead.
        if (
            module == "torchlens" or module.startswith("torchlens.")
        ) and not _is_torchlens_appliance_module(module):
            obj = super().find_class(module, name)
            if isinstance(obj, type):
                # A resolved TYPE is NO LONGER admitted unconditionally: a pickle
                # ``REDUCE`` INVOKES the type (or its reconstructed instance) with
                # attacker args, so an import-sink type such as ``LazyImportRef``
                # would be a load-time RCE. Admit ONLY vetted-inert first-party DATA
                # types on the positive allowlist; deny every other torchlens type.
                if (module, name) in _SAFE_TORCHLENS_TYPES:
                    return obj
                raise pickle.UnpicklingError(
                    "Blocked non-allowlisted torchlens type during bundle metadata "
                    f"unpickle: {module}.{name}. Only vetted-inert first-party DATA "
                    "types are admitted; import-sink / instance-callable types such "
                    "as LazyImportRef are denied (a pickle REDUCE would INVOKE the "
                    "reconstructed object with attacker arguments)."
                )
            # Imported lazily to keep this early security front door free of
            # import-order coupling (mirrors ``_safe_getattr`` above).
            from ..utils._callable_safety import is_inert_first_party_callable

            if callable(obj) and _is_torchlens_owned(obj) and is_inert_first_party_callable(obj):
                return obj
            raise pickle.UnpicklingError(
                "Blocked disallowed torchlens global during bundle metadata "
                f"unpickle: {module}.{name}."
            )

        # Foreign global -- e.g. a user/test-registered ``@tl.facets.register``
        # recipe embedded by identity in a FacetRegistrySnapshot. Admission here is
        # DETERMINISTIC: it depends ONLY on the pickled ``(module, name)`` and the
        # caller's trust flags -- never on process state (whether the module is
        # already imported, or whether the recipe is in the live registry). Keying
        # off live state was the ordering-dependent load-failure bug.
        #
        # 1. Hard-deny known dangerous modules (os / sys / subprocess / pickle /
        #    builtins / importlib / ...) unconditionally -- they are never a
        #    legitimate metadata global and importing / resolving them is the RCE.
        if _module_denied(module):
            raise pickle.UnpicklingError(
                f"Blocked dangerous global during bundle metadata unpickle: {module}.{name}."
            )
        # 1b. STRUCTURAL close of the denylist-completeness class (r31): hard-deny any
        #     FOREIGN global whose pickled module is a Python STANDARD-LIBRARY /
        #     BUILTIN module (keyed on the top-level package), regardless of trust.
        #     This closes the whole class the explicit denylist kept chasing (io /
        #     _imp / zipimport / linecache / gc / mmap / ...). The pure-data stdlib
        #     globals that legit bundles need (``collections`` / ``builtins``) resolved
        #     via ``_SAFE_EXPLICIT_GLOBALS`` far above; only genuinely-foreign globals
        #     reach here, so a stdlib/builtin owner is never legitimate.
        if _stdlib_or_builtin_denied(module):
            raise pickle.UnpicklingError(
                "Blocked standard-library / builtin global during bundle metadata "
                f"unpickle: {module}.{name}. Stdlib/builtin modules are denied even "
                "under trust_custom_callables or an explicit module allowlist."
            )
        # 2. Explicit trust opt-in: import + resolve the real foreign callable,
        #    mirroring ``resolve_function_registry_key`` under trust. Importing the
        #    module executes its top-level code, so this is gated behind the flags.
        if self._custom_module_trusted(module):
            # DiD (r28, DiD-1): a DOTTED ``name`` under a TRUSTED module can
            # attribute-walk into a module-globals MAPPING
            # (``<trusted_mod>.<func>.__globals__``) whose real ``__module__`` is
            # undefined, so the resolved-real-module denylist recheck below falls back
            # to the (non-denied) pickled module and ADMITS it -- sidestepping the E2
            # denylist recheck. Every such escape traverses a dunder attribute segment;
            # legit foreign recipe names never do. Refuse a dunder-walk BEFORE resolving
            # (never trigger the walk).
            if _name_has_dunder_walk(name):
                raise pickle.UnpicklingError(
                    "Blocked dunder attribute-walk in a trusted foreign global during "
                    f"bundle metadata unpickle: {module}.{name} (a dotted name walking "
                    "into __globals__/__builtins__/__dict__ escapes the resolved-module "
                    "denylist recheck)."
                )
            obj = super().find_class(module, name)
            # A resolved MAPPING (e.g. a module's ``__globals__`` / ``__dict__`` reached
            # by a dotted walk that the dunder guard above did not already refuse) is
            # never a legitimate foreign recipe callable/type, and its real
            # ``__module__`` is undefined -- defeating the denylist recheck. Refuse it.
            if isinstance(obj, dict):
                raise pickle.UnpicklingError(
                    "Blocked mapping (module globals) resolved via a dotted name during "
                    f"trusted bundle metadata unpickle: {module}.{name}."
                )
            # A resolved MODULE object (A-R32-2): a bare module has no ``__module__``, so
            # the resolved-real-module denylist recheck below falls back to the (trusted,
            # non-stdlib) PICKLED module name and ADMITS it -- defeating
            # ``_stdlib_or_builtin_denied``. A bare module is never a legitimate foreign
            # recipe callable/type. Refuse it outright, mirroring the mapping refusal
            # above (``isinstance(obj, dict)`` misses modules).
            if isinstance(obj, ModuleType):
                raise pickle.UnpicklingError(
                    "Blocked module object resolved via a dotted name during trusted "
                    f"bundle metadata unpickle: {module}.{name}. A bare module is never a "
                    "legitimate foreign recipe callable/type."
                )
            # RE-ENFORCE the DENYLIST on the RESOLVED object's REAL module, NEVER the
            # pickled string. A DOTTED ``name`` attribute-walks off the trusted module
            # and can land on a callable from a DIFFERENT, denied module:
            # ``module="some_trusted_mod"`` / ``name="os.system"`` resolves
            # ``os.system`` (real module ``posix``) whenever the trusted module did
            # ``import os``. ``_module_denied`` on the pickled ``module`` alone (step
            # 1) never sees ``posix``; keying on resolved identity closes the walk. We
            # re-enforce the DENYLIST (never hand back a dangerous callable, even under
            # trust) but NOT the allowlist -- the allowlist governs which MODULE may be
            # IMPORTED (already enforced), and a resolved ``__module__`` may legitimately
            # differ from the imported module (e.g. a C-accelerator re-export).
            resolved_owner = str(getattr(obj, "__module__", "") or module)
            if _module_denied(resolved_owner):
                raise pickle.UnpicklingError(
                    "Blocked dangerous global (resolved real module "
                    f"{resolved_owner!r}) during trusted bundle metadata unpickle: "
                    f"{module}.{name}."
                )
            # STRUCTURAL stdlib/builtin close (r31): a dotted ``name`` can walk OFF a
            # trusted module and land on a stdlib/builtin callable (e.g. a trusted
            # ``mymod.io.open`` resolving ``io.open``, real module ``io``). Deny the
            # whole stdlib/builtin class on the resolved real module, even under trust.
            if _stdlib_or_builtin_denied(resolved_owner):
                raise pickle.UnpicklingError(
                    "Blocked standard-library / builtin global (resolved real module "
                    f"{resolved_owner!r}) reached via a dotted name during trusted "
                    f"bundle metadata unpickle: {module}.{name}."
                )
            # PURITY PARITY (secE-1 / secE-r36-1). A callable that walked back into the
            # torch namespace via a dotted name -- OR a module-less C tensor method
            # (``resize_`` / ``set_`` / ``apply_`` / ``map_``) -- must be a PURE forward
            # op: ``torch`` also hosts side-effecting builtins (``torch.from_file``) and
            # the tensor-method family rebinds/reallocates storage or runs an arbitrary
            # callable per element. This gate keys on the callable's REAL
            # (capture-unwrapped) module, NEVER ``resolved_owner``: that fallback string
            # is spoofed two ways -- it lands on the trusted pickled ``module`` for a
            # module-less tensor method (real ``__module__ is None``), and on
            # ``"torchlens.backends.torch.wrappers"`` for ANY torch op TorchLens has
            # capture-wrapped (the near-universal live state) -- so a raw string
            # torch/prefix check misses a wrapped ``resize_`` / ``torch.load`` (the r36
            # hole). Mirror the r35 torchlens-walk fix / the intervention resolver on the
            # REAL identity: when the real owner is module-less OR torch, hold it to
            # ``is_pure_forward_callable`` (which unwraps + covers the
            # tensor-method-descriptor case, the storage-unsafe / ``apply_`` / ``map_``
            # name guards, and torch name/purity). Legit foreign recipe callables/types
            # carry a real, non-torch ``__module__`` and are NOT subject to this gate.
            from ..utils._callable_safety import (
                is_pure_forward_callable,
                real_callable_module,
            )

            real_owner = real_callable_module(obj) if callable(obj) else ""
            if (
                callable(obj)
                and (real_owner == "" or real_owner == "torch" or real_owner.startswith("torch."))
                and not is_pure_forward_callable(obj)
            ):
                raise pickle.UnpicklingError(
                    "Blocked torch-namespace or module-less callable (chiefly a C-level "
                    "tensor method such as resize_/set_/apply_/map_ or a side-effecting "
                    f"torch builtin) reached via a dotted name during trusted bundle "
                    f"metadata unpickle: {module}.{name}. Only pure forward/tensor ops "
                    "resolve from the torch namespace or a module-less C callable, even "
                    "under trust."
                )
            # OPERATOR GADGET name-scope (r33, A-R32-1 / E-r32-1): the ``operator`` /
            # ``_operator`` root is carved out of the stdlib denial so ``operator.neg``
            # survives, but that carve-out must NOT re-admit the generic operator
            # gadgets (``attrgetter`` / ``methodcaller`` / ``call`` / ``getitem`` /
            # ``setitem`` / ``delitem`` / the in-place ``iadd`` / ``imul`` / ...
            # mutators) that enable an RCE chain (``attrgetter('__globals__')`` ->
            # ``__import__`` -> ``os.system``). Deny any resolved ``operator`` /
            # ``_operator`` callable whose terminal name is not a pure forward operator,
            # even under trust. Parity with the intervention resolver.
            if callable(obj):
                from ..utils._callable_safety import is_denied_operator_gadget

                if is_denied_operator_gadget(obj):
                    raise pickle.UnpicklingError(
                        "Blocked generic operator gadget (resolved real module "
                        f"{resolved_owner!r}) reached during trusted bundle metadata "
                        f"unpickle: {module}.{name}. Only pure arithmetic / comparison / "
                        "bitwise / index operators resolve from operator/_operator."
                    )
            return obj
        # 3. Default (untrusted): LOAD-TOLERATE as an inert deferred reference. The
        #    foreign module is NEVER imported here (import executes code); the recipe
        #    reference is preserved so the trace loads structurally, and any attempt
        #    to CALL it (facet computation, or a ``__reduce__`` gadget) fails closed.
        return _DeferredForeignCallable(module, name)

    # --- Layer 2: opcode-level policy (r49, secA_1) -------------------------------
    #
    # ``find_class`` gates which globals resolve, but several opcodes act on objects
    # ALREADY on the stack, INVISIBLE to ``find_class``:
    #   * BUILD applies a ``__setstate__`` / ``__dict__`` update to ``stack[-1]``. On a
    #     torch Tensor / Storage / Parameter this reaches ``Tensor.__setstate__`` /
    #     ``set_`` and can rebind the target onto an uninitialized or oversized storage
    #     (an uninitialized-heap tensor) -- a storage rebind that never passed through
    #     ``find_class``.
    #   * REDUCE / NEWOBJ / NEWOBJ_EX CALL / ``__new__`` a callable or class on the
    #     stack. That object normally arrives via ``find_class`` (Layer 1 already denies
    #     storage ctors there), but a defense-in-depth belt refuses constructing any
    #     attacker-sized ALLOCATION type -- a torch storage (r49), a ``torch.Tensor``
    #     subclass or legacy ``torch.<dtype>Tensor``, or a ``numpy.ndarray`` subclass
    #     (r63) -- even if that type reached the stack by some other route (a prior
    #     REDUCE result, a memoized object, a resolved inert type reference, ...).
    #     ``torch.Tensor(N)`` / ``torch.FloatTensor(N)`` / ``numpy.ndarray((N,))`` each
    #     allocate an attacker-sized, uninitialized-heap buffer (``_is_alloc_constructor_type``).
    #   * MEDIATED allocation (r6). The belt above keys on the TYPE being constructed, so
    #     it is BLIND to an admitted callable that constructs on that type's behalf: at
    #     REDUCE time the stack holds ``numpy._core.multiarray._reconstruct`` (an
    #     allowlisted plain FUNCTION), not ``numpy.ndarray``, so an 88-byte pickle
    #     allocated a 2,000,000-element uninitialized array end-to-end through
    #     ``tl.load()``. ``_alloc_refusal_reason`` closes that indirection CLASS -- numpy
    #     ``_reconstruct``, torch tensor factories reached as REDUCE targets via
    #     ``_safe_getattr`` (``torch.empty(N)``), tensor-constructor METHOD DESCRIPTORS off
    #     ``TensorBase`` applied to a tensor rebuilt from an embedded blob
    #     (``new_empty``: 1.7 KiB -> 16 MB uninitialized, and invisible to a
    #     ``__module__``-only ownership test), ``bytes``/``bytearray`` handed an integer
    #     SIZE, and an ARGUMENT-BEARING ``nn.Module`` construction (whose ``__init__``
    #     allocates attacker-sized parameters). The module rule is arg-aware ON PURPOSE:
    #     a real artifact NEWOBJ-constructs a zero-argument ``nn.Identity()``.
    #   * INST / OBJ (SEC-H1) are the LEGACY protocol-0/1 constructing opcodes. Unlike
    #     REDUCE/NEWOBJ they CALL ``klass(*args)`` through the shared ``_instantiate``
    #     primitive rather than an inline dispatch handler, so they bypassed the four
    #     dispatch overrides entirely: a ~30-byte ``INST numpy.ndarray`` / ``OBJ
    #     numpy.ndarray`` / ``INST torch.FloatTensor`` stream allocated an attacker-sized
    #     uninitialized buffer BEFORE any structural check. The ``_instantiate`` override
    #     below runs the SAME belt (``_alloc_refusal_reason`` + ``_is_alloc_constructor_type``)
    #     and, because ``load_inst`` / ``load_obj`` reach it via ``self._instantiate``
    #     (normal MRO), it closes BOTH opcodes in one place -- CONSTRUCTION-scoped, not
    #     opcode-scoped. With it the FULL constructing-opcode set (REDUCE, NEWOBJ,
    #     NEWOBJ_EX, INST, OBJ) is belt-gated and BUILD is state-gated; no construction
    #     opcode reaches an unbounded allocation.
    # Legit ``.tlspec`` metadata never BUILDs a torch tensor/storage/parameter, never
    # bare-constructs a storage/tensor/ndarray in the outer stream (payloads travel as
    # BlobRefs and reconstruct through the wrapped ``_rebuild_*`` helpers), and -- written
    # at pickle protocol >= 2 -- never emits the legacy INST/OBJ opcodes at all, so these
    # gates refuse nothing legit.

    def load_build(self) -> None:
        """Refuse a BUILD (``__setstate__`` / storage-rebind) on a torch tensor/storage."""

        # Base ``load_build`` is ``state = stack.pop(); inst = stack[-1]`` -- so before
        # it runs, the target instance is ``stack[-2]`` (``state`` is ``stack[-1]``).
        inst = self.stack[-2]  # type: ignore[attr-defined]
        if isinstance(inst, torch.Tensor) or _is_torch_storage_instance(inst):
            raise pickle.UnpicklingError(
                "Blocked BUILD applied to a torch "
                f"{type(inst).__module__}.{type(inst).__qualname__} during bundle "
                "metadata unpickle: a pickle BUILD invokes __setstate__ / storage "
                "rebind (Tensor.set_) on the target, which can rebind it onto an "
                "uninitialized or oversized storage. .tlspec metadata never BUILDs a "
                "torch tensor/storage/parameter (payloads are BlobRefs)."
            )
        return _BASE_LOAD_BUILD(self)  # type: ignore[arg-type]

    def load_reduce(self) -> None:
        """Refuse a REDUCE that constructs -- or MEDIATES -- an attacker-sized allocation."""

        # Base ``load_reduce`` is ``args = stack.pop(); func = stack[-1]; ...`` -- so
        # before it runs, ``func`` is ``stack[-2]`` (``args`` is ``stack[-1]``).
        func = self.stack[-2]  # type: ignore[attr-defined]
        mediated = _alloc_refusal_reason(func, self.stack[-1])  # type: ignore[attr-defined]
        if mediated is not None:
            raise pickle.UnpicklingError(
                "Blocked mediated allocation via REDUCE during bundle metadata "
                f"unpickle: {mediated}. The allocation-constructor belt inspects the TYPE "
                "being constructed, so an admitted callable that constructs on its behalf "
                "must be refused here; .tlspec payloads travel as BlobRefs."
            )
        if _is_alloc_constructor_type(func):
            raise pickle.UnpicklingError(
                "Blocked allocation-constructor (torch storage/tensor or numpy ndarray) "
                "via REDUCE during bundle metadata unpickle: "
                f"{getattr(func, '__module__', '')}."
                f"{getattr(func, '__qualname__', func)!r} (constructing it from "
                "pickle-supplied args allocates attacker-sized, uninitialized-heap "
                "memory -- an out-of-memory DoS and the source of an uninitialized-heap "
                "tensor; .tlspec payloads travel as BlobRefs and reconstruct through the "
                "wrapped _rebuild/_frombuffer helpers, which are functions, not types)."
            )
        return _BASE_LOAD_REDUCE(self)  # type: ignore[arg-type]

    def load_newobj(self) -> None:
        """Refuse a NEWOBJ (``cls.__new__``) that would allocate a storage/tensor/ndarray."""

        # Base ``load_newobj`` is ``args = stack.pop(); cls = stack.pop(); ...`` -- so
        # ``cls`` is ``stack[-2]`` (``args`` is ``stack[-1]``).
        cls = self.stack[-2]  # type: ignore[attr-defined]
        mediated = _alloc_refusal_reason(cls, self.stack[-1])  # type: ignore[attr-defined]
        if mediated is not None:
            raise pickle.UnpicklingError(
                f"Blocked mediated allocation via NEWOBJ during bundle metadata unpickle: {mediated}."
            )
        if _is_alloc_constructor_type(cls):
            raise pickle.UnpicklingError(
                "Blocked allocation-constructor (torch storage/tensor or numpy ndarray) "
                "via NEWOBJ during bundle metadata unpickle: "
                f"{getattr(cls, '__module__', '')}."
                f"{getattr(cls, '__qualname__', cls)!r}."
            )
        return _BASE_LOAD_NEWOBJ(self)  # type: ignore[arg-type]

    def load_newobj_ex(self) -> None:
        """Refuse a NEWOBJ_EX (``cls.__new__``) that would allocate a storage/tensor/ndarray."""

        # Base ``load_newobj_ex`` is ``kwargs = stack.pop(); args = stack.pop();
        # cls = stack.pop()`` -- so ``cls`` is ``stack[-3]``.
        cls = self.stack[-3]  # type: ignore[attr-defined]
        mediated = _alloc_refusal_reason(
            cls,
            self.stack[-2],  # type: ignore[attr-defined]
            self.stack[-1],  # type: ignore[attr-defined]
        )
        if mediated is not None:
            raise pickle.UnpicklingError(
                "Blocked mediated allocation via NEWOBJ_EX during bundle metadata "
                f"unpickle: {mediated}."
            )
        if _is_alloc_constructor_type(cls):
            raise pickle.UnpicklingError(
                "Blocked allocation-constructor (torch storage/tensor or numpy ndarray) "
                "via NEWOBJ_EX during bundle metadata unpickle: "
                f"{getattr(cls, '__module__', '')}."
                f"{getattr(cls, '__qualname__', cls)!r}."
            )
        return _BASE_LOAD_NEWOBJ_EX(self)  # type: ignore[arg-type]

    def _instantiate(self, klass: Any, args: Any) -> None:
        """Refuse an INST / OBJ construction that would allocate attacker-sized memory.

        CLOSES THE LAST CONSTRUCTION OPCODES (SEC-H1). The dispatch overrides above cover
        only REDUCE / NEWOBJ / NEWOBJ_EX, but the pure-Python VM has TWO more constructing
        opcodes -- the legacy protocol-0/1 ``INST`` (``b'i'``, ``load_inst``) and ``OBJ``
        (``b'o'``, ``load_obj``) -- and BOTH funnel through this single ``_instantiate``
        primitive, which calls ``klass(*args)`` directly. Because ``load_inst`` /
        ``load_obj`` invoke ``self._instantiate(...)`` (normal MRO, not the dispatch
        table), overriding this ONE method here makes the allocation check fire regardless
        of which of those opcodes reached construction -- CONSTRUCTION-scoped, not
        opcode-scoped, so a future opcode routed through the shared primitive is covered
        for free. Without it a ~30-byte ``metadata.pkl`` using INST/OBJ constructs
        ``numpy.ndarray(N)`` / ``torch.FloatTensor(N)`` -- an attacker-sized, uninitialized
        heap buffer (OOM DoS + uninitialized-heap read on a public object) -- at plain
        ``tl.load()`` time, sidestepping the belt the four dispatch overrides enforce.

        The refusal reuses the EXACT belt helpers the REDUCE / NEWOBJ overrides use
        (``_alloc_refusal_reason`` + ``_is_alloc_constructor_type``) -- ONE source of
        truth, so the INST/OBJ path can never drift from the rest of the belt. Legit
        ``.tlspec`` metadata is written with pickle protocol >= 2 (``DEFAULT_PROTOCOL``
        >= 4), which NEVER emits INST/OBJ (they are protocol-0/1 opcodes), and never
        bare-constructs a storage/tensor/ndarray in the outer stream anyway (payloads are
        BlobRefs), so this refuses nothing a real bundle does; a benign small object still
        instantiates unchanged.
        """

        # ``load_inst`` / ``load_obj`` hand ``args`` as a LIST (from ``pop_mark()``); the
        # belt helpers gate on a TUPLE (``_requests_integer_sized_buffer`` /
        # ``_alloc_refusal_reason`` test ``isinstance(args, tuple)``). Normalize so a
        # security belt never silently no-ops on a container-type mismatch. A non-list/
        # non-tuple ``args`` is passed through verbatim for the helpers to reject/ignore.
        arg_tuple = tuple(args) if isinstance(args, (list, tuple)) else args
        mediated = _alloc_refusal_reason(klass, arg_tuple)
        if mediated is not None:
            raise pickle.UnpicklingError(
                "Blocked mediated allocation via INST/OBJ during bundle metadata "
                f"unpickle: {mediated}. The legacy INST/OBJ construction opcodes route "
                "through the same allocation belt as REDUCE/NEWOBJ; .tlspec payloads "
                "travel as BlobRefs."
            )
        if _is_alloc_constructor_type(klass):
            raise pickle.UnpicklingError(
                "Blocked allocation-constructor (torch storage/tensor or numpy ndarray) "
                "via INST/OBJ during bundle metadata unpickle: "
                f"{getattr(klass, '__module__', '')}."
                f"{getattr(klass, '__qualname__', klass)!r} (constructing it from "
                "pickle-supplied args allocates attacker-sized, uninitialized-heap "
                "memory -- an out-of-memory DoS and the source of an uninitialized-heap "
                "tensor. .tlspec metadata is protocol >= 2 and never emits the legacy "
                "INST/OBJ opcodes; payloads travel as BlobRefs)."
            )
        return super()._instantiate(klass, args)  # type: ignore[misc]

    # REBUILD the pure-Python opcode dispatch table so the overrides above are actually
    # invoked (proven: ``def load_build`` alone is INERT -- ``pickle._Unpickler.load``
    # reads ``self.dispatch``, a class-level dict of unbound base functions bound at
    # class-body time; the subclass method is not consulted unless the dict is
    # repointed). This is the single load-bearing detail of the C->pure-Python
    # migration. ``_RenameAwareUnpickler`` inherits this ``dispatch`` unchanged.
    dispatch = _DenyMissingDispatch(pickle._Unpickler.dispatch)
    dispatch[pickle.BUILD[0]] = load_build
    dispatch[pickle.REDUCE[0]] = load_reduce
    dispatch[pickle.NEWOBJ[0]] = load_newobj
    dispatch[pickle.NEWOBJ_EX[0]] = load_newobj_ex
