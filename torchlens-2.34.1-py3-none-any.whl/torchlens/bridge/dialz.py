"""dialz bridge helpers."""

from __future__ import annotations

import inspect
from collections.abc import Iterable
from typing import Any

from ._utils import tensor_layers


def analyze(
    log: Any,
    *,
    sites: Iterable[Any] | None = None,
    analyzer: Any | None = None,
    **kwargs: Any,
) -> dict[str, Any]:
    """Run a dialz analyzer over saved TorchLens outs.

    Parameters
    ----------
    log:
        TorchLens ``Trace``.
    sites:
        Optional sites to include. Defaults to all non-input tensor layers.
    analyzer:
        Optional analyzer callable or object exposing ``analyze``.
    **kwargs:
        Additional keyword arguments forwarded to the analyzer.

    Returns
    -------
    dict[str, Any]
        Contract payload containing labels, outs, and downstream result.

    Raises
    ------
    ImportError
        If dialz is unavailable.
    RuntimeError
        If no supported analyzer is exposed.
    """

    try:
        import dialz as dialz_module
    except ImportError as exc:
        raise ImportError(
            "dialz bridge requires the `dialz` extra: install torchlens[dialz]."
        ) from exc

    layers = tensor_layers(log, sites)
    labels = [str(getattr(layer, "layer_label", "layer")) for layer in layers]
    outs = [getattr(layer, "out") for layer in layers]
    runner = _resolve_analyzer(dialz_module, analyzer)
    result = _call_analyzer(runner, outs=outs, labels=labels, **kwargs)
    return {
        "schema": "torchlens.dialz.v1",
        "labels": labels,
        "outs": outs,
        "result": result,
    }


def _resolve_analyzer(module: Any, analyzer: Any | None) -> Any:
    """Return a dialz analyzer callable.

    Parameters
    ----------
    module:
        Imported ``dialz`` module.
    analyzer:
        Optional explicit analyzer.

    Returns
    -------
    Any
        Analyzer callable or object.

    Raises
    ------
    RuntimeError
        If no analyzer is available.
    """

    if analyzer is not None:
        return analyzer
    for attr_name in ("analyze", "Analyzer", "Dialz"):
        candidate = getattr(module, attr_name, None)
        if candidate is None:
            continue
        # An analyzer CLASS must be instantiated: passing the class straight to
        # ``_call_analyzer`` would invoke ``Class.analyze(outs, ...)`` as an unbound
        # method and misbind ``self`` to the outs list (a crash, or silent wrong
        # results when ``analyze`` has defaulted parameters).
        if inspect.isclass(candidate):
            return candidate()
        if callable(candidate):
            return candidate
    raise RuntimeError("Installed dialz does not expose analyze, Analyzer, or Dialz.")


def _call_analyzer(runner: Any, *, outs: list[Any], labels: list[str], **kwargs: Any) -> Any:
    """Call a dialz analyzer in function or object form.

    Parameters
    ----------
    runner:
        Analyzer callable or object exposing ``analyze``.
    outs:
        Saved outs.
    labels:
        TorchLens layer labels.
    **kwargs:
        Additional analyzer keyword arguments.

    Returns
    -------
    Any
        Downstream analyzer result.
    """

    if hasattr(runner, "analyze"):
        return runner.analyze(outs, labels=labels, **kwargs)
    return runner(outs, labels=labels, **kwargs)


__all__ = ["analyze"]
