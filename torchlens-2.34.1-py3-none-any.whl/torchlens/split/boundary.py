"""Replay boundary container and ABI validation."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from .adapters.base import SplitBackendAdapter
from .errors import SplitBoundaryError, SplitErrorContext
from .ir import BoundarySchema
from .shape import validate_tensor_against_symbolic_shape

_COLLATE_METADATA_KEYS = (
    "split_id",
    "graph_shape_hash",
    "batch_symbol",
    "runtime_batch_size",
    "shape_program_hash",
    "device_policy",
    "profile_hash",
)


@dataclass(frozen=True)
class ReplayBoundary:
    """Split/graph/schema/shape ABI payload, independent of model parameter values."""

    backend: str
    tensors: dict[str, Any]
    spec: dict[str, BoundarySchema]
    metadata: dict[str, Any]

    def __post_init__(self) -> None:
        """Drop value-state fields from callers constructing old cached boundaries."""

        if "state_fingerprint" in self.metadata or "state_prefix_kind" in self.metadata:
            object.__setattr__(
                self,
                "metadata",
                {
                    key: value
                    for key, value in self.metadata.items()
                    if key not in {"state_fingerprint", "state_prefix_kind"}
                },
            )

    @staticmethod
    def _collate_metadata_abi(boundary: ReplayBoundary) -> tuple[Any, ...]:
        """Return metadata fields that identify a compatible boundary ABI."""

        return tuple(boundary.metadata.get(key) for key in _COLLATE_METADATA_KEYS)

    def _adapter(self, adapter: SplitBackendAdapter | None) -> SplitBackendAdapter:
        """Resolve an adapter for boundary tensor operations."""

        from .adapters import resolve_split_adapter

        return adapter if adapter is not None else resolve_split_adapter(self.backend)

    def validate(
        self,
        expected: dict[str, BoundarySchema] | None = None,
        *,
        split_id: str | None = None,
        graph_hash: str | None = None,
        profile_hash: str | None = None,
        shape_program_hash: str | None = None,
        shape_program: Any | None = None,
        adapter: SplitBackendAdapter | None = None,
    ) -> None:
        """Validate this boundary against its ABI spec.

        Parameters
        ----------
        expected:
            Expected runtime boundary spec. Defaults to ``self.spec``.
        split_id:
            Optional expected split ID.
        adapter:
            Optional split backend adapter.
        """

        resolved_adapter = self._adapter(adapter)
        expected_spec = self.spec if expected is None else expected
        if split_id is not None and self.metadata.get("split_id") != split_id:
            raise SplitBoundaryError(
                "Replay boundary split_id does not match this runtime.",
                context=SplitErrorContext(
                    backend=self.backend,
                    split_point=str(split_id),
                    reason="split_id mismatch",
                ),
            )
        expected_metadata = (
            ("graph_shape_hash", graph_hash),
            ("profile_hash", profile_hash),
            ("shape_program_hash", shape_program_hash),
        )
        for field_name, expected_value in expected_metadata:
            if expected_value is None or field_name not in self.metadata:
                continue
            if self.metadata[field_name] != expected_value:
                raise SplitBoundaryError(
                    f"Replay boundary {field_name} does not match this runtime.",
                    context=SplitErrorContext(
                        backend=self.backend,
                        split_point=str(split_id or self.metadata.get("split_id", "")),
                        reason=f"{field_name} mismatch",
                    ),
                )
        if set(self.tensors) != set(expected_spec):
            raise SplitBoundaryError(
                "Replay boundary tensor IDs do not match the boundary spec.",
                context=SplitErrorContext(
                    backend=self.backend,
                    split_point=str(split_id or self.metadata.get("split_id", "")),
                    reason="tensor id set mismatch",
                ),
            )
        if set(self.spec) != set(expected_spec):
            raise SplitBoundaryError(
                "Replay boundary spec IDs do not match the expected spec.",
                context=SplitErrorContext(
                    backend=self.backend,
                    split_point=str(split_id or self.metadata.get("split_id", "")),
                    reason="spec id set mismatch",
                ),
            )
        for key, expected_item in expected_spec.items():
            _validate_schema_identity(key, self.spec[key], expected_item)
            value = self.tensors[key]
            dtype = resolved_adapter.dtype_name(value)
            if (
                expected_item.dtype is not None
                and dtype is not None
                and dtype != expected_item.dtype
            ):
                raise SplitBoundaryError(
                    f"Boundary tensor {key!r} dtype is {dtype}, expected {expected_item.dtype}.",
                    context=SplitErrorContext(
                        backend=self.backend,
                        split_point=str(split_id or self.metadata.get("split_id", "")),
                        module_path=expected_item.module_path,
                        op_type=expected_item.op_type,
                        layer_label=expected_item.label,
                        reason="dtype mismatch",
                        dtype=dtype,
                    ),
                )
            if shape_program is None:
                validate_tensor_against_symbolic_shape(
                    value,
                    expected_item.shape,
                    adapter=resolved_adapter,
                    batch_symbol=self.metadata.get("batch_symbol", "B"),
                    backend=self.backend,
                    split_point=str(split_id or self.metadata.get("split_id", "")),
                    label=expected_item.label,
                )
            else:
                self._validate_solved_shape(
                    key, value, expected_item, shape_program, resolved_adapter
                )

    def _validate_solved_shape(
        self,
        key: str,
        value: Any,
        expected_item: BoundarySchema,
        shape_program: Any,
        adapter: SplitBackendAdapter,
    ) -> None:
        """Check a boundary value against an available runtime shape solution."""

        value_shape = shape_program.value_shapes.get(expected_item.canonical_id)
        runtime_batch = self.metadata.get("runtime_batch_size")
        if value_shape is not None and runtime_batch is not None:
            expected_runtime_shape = value_shape.evaluate(
                shape_program.binding_from_batch(int(runtime_batch))
            )
            actual_runtime_shape = adapter.shape(value)
            if actual_runtime_shape is not None and tuple(actual_runtime_shape) != tuple(
                expected_runtime_shape
            ):
                raise SplitBoundaryError(
                    f"Boundary tensor {key!r} shape is {actual_runtime_shape}, "
                    f"expected solved shape {expected_runtime_shape}."
                )

    def detach(self, adapter: SplitBackendAdapter | None = None) -> ReplayBoundary:
        """Return a boundary with detached tensor values."""

        resolved_adapter = self._adapter(adapter)
        return ReplayBoundary(
            backend=self.backend,
            tensors={key: resolved_adapter.detach(value) for key, value in self.tensors.items()},
            spec=self.spec,
            metadata=dict(self.metadata),
        )

    def clone(self, adapter: SplitBackendAdapter | None = None) -> ReplayBoundary:
        """Return a boundary with cloned tensor values."""

        resolved_adapter = self._adapter(adapter)
        return ReplayBoundary(
            backend=self.backend,
            tensors={key: resolved_adapter.clone(value) for key, value in self.tensors.items()},
            spec=self.spec,
            metadata=dict(self.metadata),
        )

    def to(self, device: Any, adapter: SplitBackendAdapter | None = None) -> ReplayBoundary:
        """Return a boundary with tensors moved to ``device``."""

        resolved_adapter = self._adapter(adapter)
        return ReplayBoundary(
            backend=self.backend,
            tensors={
                key: resolved_adapter.to_device(value, device)
                for key, value in self.tensors.items()
            },
            spec=self.spec,
            metadata=dict(self.metadata),
        )

    def cpu(self, adapter: SplitBackendAdapter | None = None) -> ReplayBoundary:
        """Return a CPU boundary."""

        return self.to("cpu", adapter=adapter)

    def cuda(self, adapter: SplitBackendAdapter | None = None) -> ReplayBoundary:
        """Return a CUDA boundary."""

        return self.to("cuda", adapter=adapter)

    @classmethod
    def collate(
        cls,
        boundaries: list[ReplayBoundary],
        adapter: SplitBackendAdapter | None = None,
    ) -> ReplayBoundary:
        """Collate a list of same-spec boundaries by tensor key."""

        if not boundaries:
            raise SplitBoundaryError("ReplayBoundary.collate requires at least one boundary.")
        first = boundaries[0]
        resolved_adapter = first._adapter(adapter)
        first_metadata_abi = cls._collate_metadata_abi(first)
        for boundary in boundaries[1:]:
            if (
                boundary.backend != first.backend
                or set(boundary.tensors) != set(first.tensors)
                or boundary.spec != first.spec
                or cls._collate_metadata_abi(boundary) != first_metadata_abi
            ):
                raise SplitBoundaryError("Cannot collate boundaries with different ABI IDs.")
        return cls(
            backend=first.backend,
            tensors={
                key: resolved_adapter.collate([boundary.tensors[key] for boundary in boundaries])
                for key in first.tensors
            },
            spec=first.spec,
            metadata={
                **first.metadata,
                "collated": True,
                "batch_size": len(boundaries),
            },
        )


def _validate_schema_identity(key: str, actual: BoundarySchema, expected: BoundarySchema) -> None:
    """Check the ordered identity fields of one boundary ABI entry."""

    if actual.canonical_id != expected.canonical_id:
        raise SplitBoundaryError(f"Boundary canonical ID mismatch for {key!r}.")
    if actual.role != expected.role:
        raise SplitBoundaryError(f"Boundary role mismatch for {key!r}.")
    if actual.output_index != expected.output_index:
        raise SplitBoundaryError(f"Boundary output index mismatch for {key!r}.")
    if tuple(actual.container_path) != tuple(expected.container_path):
        raise SplitBoundaryError(f"Boundary container path mismatch for {key!r}.")


__all__ = ["ReplayBoundary"]
