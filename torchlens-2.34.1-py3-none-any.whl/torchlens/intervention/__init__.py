"""Import surface for TorchLens intervention selectors, hooks, reruns, and bundles.

Two of this package's public names are resolved LAZILY through the module
``__getattr__`` below rather than imported eagerly, because their modules import
BACK into modules whose own import pulls in ``torchlens.intervention``:

* ``Bundle`` lives in :mod:`torchlens.bundle`, which imports
  ``torchlens.intervention._metrics`` / ``._super`` / ``._topology``; importing any
  of those first executes THIS ``__init__``, so an eager ``from .bundle import
  Bundle`` here made ``import torchlens.bundle`` -- a PUBLIC module -- fail with a
  partially-initialized-module ``ImportError``.
* ``rerun`` / ``run`` live in :mod:`torchlens.intervention.rerun`, which imports
  ``torchlens._chunking``; ``_chunking`` imports ``.intervention.errors``, so an
  eager ``from .rerun import ...`` here made ``import torchlens._chunking`` fail
  the same way.

Deferring exactly these three names keeps every module in the package standalone
importable (gated by ``tests/test_module_import_isolation.py``) while leaving the
public surface, ``__all__``, and static types unchanged.
"""

from typing import TYPE_CHECKING, Any

from ._metrics import (
    METRIC_REGISTRY,
    cosine_distance,
    pearson_correlation_distance,
    relative_l1_scalar,
    relative_l2,
    resolve_metric,
)
from ._super.super_op import (
    SuperAtenOp,
    SuperLayer,
    SuperLayerAccessor,
    SuperOp,
    SuperOpAccessor,
    TraceAccessor,
)
from ._topology.topology import (
    Supergraph,
    SupergraphNode,
    TopologyDiff,
    build_supergraph,
    compare_topology,
)
from .errors import (
    AppendBatchDependenceError,
    AppendMismatchError,
    AppendStateValidationWarning,
    AppendStreamingNotSupportedError,
    AxisAmbiguityError,
    BaselineUndeterminedError,
    BatchNormTrainModeWarning,
    BundleMemberError,
    BundleRelationshipError,
    ControlFlowDivergenceError,
    ControlFlowDivergenceWarning,
    DeadParentError,
    DirectActivationWriteWarning,
    DirectWriteInExecutableSaveError,
    EngineDispatchError,
    GraphShapeMismatchError,
    HelperMountError,
    HookSignatureError,
    HookSiteCoverageError,
    HookValueError,
    InterventionReadyConflictError,
    LiveModeLabelError,
    ModelMismatchError,
    MultiMatchWarning,
    MultiOutputModuleError,
    MutateInPlaceWarning,
    NoParentError,
    OpaqueCallableInExecutableSaveError,
    RecursiveTracingError,
    ReplayPreconditionError,
    SelectionError,
    SelectorCompositionError,
    SiteAmbiguityError,
    SiteResolutionError,
    SpecMutationError,
    SpecPortabilityError,
    SpliceModuleDeviceError,
    SpliceModuleDtypeError,
    UnclassifiedSelectorError,
    UntrustedCallableError,
)
from .handles import HookHandle
from .helpers import (
    bwd_hook,
    clamp,
    grad_clamp,
    grad_clip,
    grad_noise,
    grad_scale,
    grad_zero,
    mean_ablate,
    noise,
    patch_from,
    project_off,
    project_onto,
    resample_ablate,
    scale,
    splice_module,
    steer,
    swap_with,
    zero_ablate,
)
from .hooks import (
    HookContext,
    NormalizedHookEntry,
    make_hook_context,
    normalize_hook,
    normalize_hook_plan,
)
from .predicates import add, replace_with, when
from .replay import push, push_from, replay, replay_from
from .resolver import SiteTable, resolve_sites
from .runtime import do
from .save import (
    SaveLevel,
    SpecCompat,
    TargetManifestDiff,
    check_spec_compat,
    load_intervention_spec,
    save_intervention,
)
from .selectors import (
    contains,
    facet,
    followed_by,
    func,
    func_transform,
    grad_fn,
    grad_fn_label,
    grad_input,
    grad_output,
    head,
    in_backward_pass,
    in_module,
    input_at,
    intervening,
    label,
    module,
    output,
    output_at,
    preceded_by,
    regex,
    where,
    without_op,
)
from .sites import SiteCollection, SiteSpec, sites
from .types import (
    ArgComponent,
    CapturedArgTemplate,
    ContainerSpec,
    DataclassField,
    DictKey,
    EdgeUseRecord,
    Edit,
    FireRecord,
    ForkFieldPolicy,
    FrozenInterventionSpec,
    FrozenTargetSpec,
    FunctionRegistryKey,
    HelperSpec,
    HFKey,
    InterventionDecision,
    InterventionSpec,
    LiteralTensor,
    LiteralValue,
    NamedField,
    ParentRef,
    Relationship,
    TargetSpec,
    TensorSliceSpec,
    TupleIndex,
    Unsupported,
    rebuild_container_from_spec,
)

if TYPE_CHECKING:  # typing-only mirror of the lazy names below
    from .bundle import Bundle
    from .rerun import rerun, run

__all__ = [
    "AppendBatchDependenceError",
    "AppendMismatchError",
    "AppendStateValidationWarning",
    "AppendStreamingNotSupportedError",
    "add",
    "ArgComponent",
    "AxisAmbiguityError",
    "BaselineUndeterminedError",
    "BatchNormTrainModeWarning",
    "Bundle",
    "BundleMemberError",
    "BundleRelationshipError",
    "CapturedArgTemplate",
    "ContainerSpec",
    "ControlFlowDivergenceError",
    "ControlFlowDivergenceWarning",
    "DataclassField",
    "DeadParentError",
    "DictKey",
    "DirectActivationWriteWarning",
    "DirectWriteInExecutableSaveError",
    "EdgeUseRecord",
    "EngineDispatchError",
    "FireRecord",
    "ForkFieldPolicy",
    "FrozenInterventionSpec",
    "FrozenTargetSpec",
    "FunctionRegistryKey",
    "GraphShapeMismatchError",
    "HFKey",
    "Edit",
    "HelperSpec",
    "InterventionDecision",
    "HookSignatureError",
    "HelperMountError",
    "HookHandle",
    "HookContext",
    "HookSiteCoverageError",
    "HookValueError",
    "InterventionSpec",
    "InterventionReadyConflictError",
    "LiveModeLabelError",
    "LiteralTensor",
    "LiteralValue",
    "METRIC_REGISTRY",
    "ModelMismatchError",
    "MultiMatchWarning",
    "MultiOutputModuleError",
    "MutateInPlaceWarning",
    "NamedField",
    "NoParentError",
    "OpaqueCallableInExecutableSaveError",
    "Relationship",
    "RecursiveTracingError",
    "ReplayPreconditionError",
    "SaveLevel",
    "ParentRef",
    "SiteAmbiguityError",
    "SiteCollection",
    "SelectionError",
    "SiteResolutionError",
    "SiteSpec",
    "SelectorCompositionError",
    "SpecCompat",
    "SpecMutationError",
    "SpecPortabilityError",
    "SuperAtenOp",
    "SiteTable",
    "SpliceModuleDeviceError",
    "SpliceModuleDtypeError",
    "SuperLayer",
    "SuperLayerAccessor",
    "SuperOp",
    "SuperOpAccessor",
    "Supergraph",
    "SupergraphNode",
    "TargetManifestDiff",
    "TargetSpec",
    "TensorSliceSpec",
    "TopologyDiff",
    "TraceAccessor",
    "TupleIndex",
    "Unsupported",
    "bwd_hook",
    "build_supergraph",
    "clamp",
    "check_spec_compat",
    "compare_topology",
    "contains",
    "cosine_distance",
    "do",
    "facet",
    "func",
    "func_transform",
    "followed_by",
    "grad_clamp",
    "grad_clip",
    "grad_fn",
    "grad_fn_label",
    "grad_input",
    "head",
    "label",
    "grad_noise",
    "grad_output",
    "grad_scale",
    "grad_zero",
    "input_at",
    "in_backward_pass",
    "in_module",
    "intervening",
    "label",
    "regex",
    "load_intervention_spec",
    "make_hook_context",
    "mean_ablate",
    "module",
    "noise",
    "normalize_hook",
    "normalize_hook_plan",
    "NormalizedHookEntry",
    "output",
    "output_at",
    "preceded_by",
    "pearson_correlation_distance",
    "project_off",
    "project_onto",
    "replace_with",
    "push",
    "push_from",
    "replay",
    "replay_from",
    "rerun",
    "run",
    "resample_ablate",
    "relative_l1_scalar",
    "relative_l2",
    "resolve_metric",
    "resolve_sites",
    "save_intervention",
    "scale",
    "splice_module",
    "sites",
    "steer",
    "swap_with",
    "where",
    "when",
    "without_op",
    "UnclassifiedSelectorError",
    "UntrustedCallableError",
    "patch_from",
    "zero_ablate",
    "rebuild_container_from_spec",
]

# Names whose defining module imports back into a module that imports this
# package; see the module docstring. Resolved on first attribute access, after
# this ``__init__`` has finished executing, so no partially-initialized module is
# ever observed.
_LAZY_NAMES: dict[str, str] = {
    "Bundle": ".bundle",
    "rerun": ".rerun",
    "run": ".rerun",
}


def __getattr__(name: str) -> Any:
    """Resolve the cycle-deferred public names on first access.

    Parameters
    ----------
    name:
        Attribute name being looked up on ``torchlens.intervention``.

    Returns
    -------
    Any
        The resolved attribute.

    Raises
    ------
    AttributeError
        For any name this package does not define.
    """

    module_name = _LAZY_NAMES.get(name)
    if module_name is None:
        raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
    from importlib import import_module

    value = getattr(import_module(module_name, __name__), name)
    globals()[name] = value  # memoize; subsequent lookups skip __getattr__
    return value


def __dir__() -> list[str]:
    """Return the public surface including the lazily-resolved names."""

    return sorted(set(__all__) | set(globals()))
