"""Exception types for receptive-field queries and validation."""

from __future__ import annotations

from ..backends.registry import BackendUnsupportedError
from ..errors import TorchLensError


class ReceptiveFieldError(TorchLensError):
    """Base class for receptive-field failures."""


class ReceptiveFieldConfigurationError(ReceptiveFieldError, ValueError):
    """Raised when a receptive-field call is misconfigured by its caller.

    Covers invalid public arguments and rule-registration mistakes (bad
    tolerances, unknown table levels, malformed rule names, out-of-range
    display options). Subclasses :class:`ValueError` so existing callers
    catching the historical raw errors keep working (SF-07 typed stratum).
    """


class AmbiguousInputError(ReceptiveFieldError, ValueError):
    """Raised when a query has more than one reachable model input."""


class NoInfluencePathError(ReceptiveFieldError, ValueError):
    """Raised when two graph points have no directed influence path."""


class AmbiguousTargetError(ReceptiveFieldError, ValueError):
    """Raised when a projective query has more than one reachable target."""


class AmbiguousPassError(ReceptiveFieldError, ValueError):
    """Raised when a layer-level query has multiple executed passes."""


class AmbiguousCallError(ReceptiveFieldError, ValueError):
    """Raised when a module-level query has multiple executed calls."""


class ReceptiveFieldUnavailableError(ReceptiveFieldError, RuntimeError):
    """Raised when a receptive-field result requires unavailable capture state."""


class ReceptiveFieldValidationError(ReceptiveFieldError, AssertionError):
    """Raised when receptive-field cross-validation detects a violation."""


__all__ = [
    "AmbiguousCallError",
    "AmbiguousInputError",
    "AmbiguousTargetError",
    "AmbiguousPassError",
    "BackendUnsupportedError",
    "NoInfluencePathError",
    "ReceptiveFieldConfigurationError",
    "ReceptiveFieldError",
    "ReceptiveFieldUnavailableError",
    "ReceptiveFieldValidationError",
]
