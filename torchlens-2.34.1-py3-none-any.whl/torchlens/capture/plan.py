"""Compiled, backend-neutral capture intent for the unification spine.

The Stage 2 compatibility adapter compiles these plans beside the legacy
``Trace`` configuration.  Producers still follow their existing paths; later
stages will consume the plan directly from the capture kernel.
"""

from __future__ import annotations

from collections.abc import Iterable, Mapping
from dataclasses import dataclass, field
from enum import Enum
from types import MappingProxyType
from typing import Any


class EnrichmentLevel(str, Enum):
    """Execution-cost tier requested for an operation observation.

    ``SHELL`` retains only the topology/correctness minimum, ``METADATA``
    additionally requests descriptive operation facts, and ``PAYLOAD``
    requests a retained value lease.  Levels are demands rather than schemas.
    """

    SHELL = "shell"
    METADATA = "metadata"
    PAYLOAD = "payload"


class RetentionKind(str, Enum):
    """Payload kind held while a structure-dependent selector resolves."""

    NONE = "none"
    ACTIVATION = "activation"
    GRADIENT_REFERENCE = "gradient_reference"


@dataclass(frozen=True, slots=True)
class RetentionProfile:
    """Precompiled deferred-retention bounds for a capture request.

    Parameters
    ----------
    activation_kind
        Whether detached activation values are retained.
    activation_window
        Maximum rolling-window size, or ``None`` for a candidate-class escrow.
    gradient_kind
        Whether live tensor references are retained for deferred grad hooks.
    gradient_window
        Maximum reference window, or ``None`` when the selector is unwindowable.
    spillable
        Whether retained values may be moved to temporary disk storage.
    activation_ram_budget_bytes
        Maximum detached activation bytes retained in memory before temp spill.
    gradient_warning_threshold_bytes
        Logical tensor-byte threshold for warning about unwindowable live references.
    """

    activation_kind: RetentionKind = RetentionKind.NONE
    activation_window: int | None = 0
    gradient_kind: RetentionKind = RetentionKind.NONE
    gradient_window: int | None = 0
    spillable: bool = False
    activation_ram_budget_bytes: int = 64 * 1024 * 1024
    gradient_warning_threshold_bytes: int = 512 * 1024 * 1024


def _freeze_intent(value: Any) -> Any:
    """Recursively freeze standard intent containers.

    Parameters
    ----------
    value
        Compiled-intent value to make read-only where possible.

    Returns
    -------
    Any
        Immutable container equivalent, or the original opaque value.
    """

    if isinstance(value, Mapping):
        return MappingProxyType({key: _freeze_intent(item) for key, item in value.items()})
    if isinstance(value, (list, tuple)):
        return tuple(_freeze_intent(item) for item in value)
    if isinstance(value, (set, frozenset)):
        return frozenset(_freeze_intent(item) for item in value)
    return value


@dataclass(frozen=True, slots=True)
class CapturePlan:
    """Immutable compiled intent for a single capture run.

    Parameters
    ----------
    projection_target
        Internal projection selected for this run, such as ``"trace"`` or
        ``"recording"``.
    default_enrichment
        Demand used by operations without a more-specific entry.
    enrichment_by_operation
        Immutable operation-key to demanded enrichment mapping.
    selectors
        Normalized immediate selector intent.
    deferred_candidates
        Selector candidates that must be resolved after the forward pass.
    interventions
        Compiled intervention intent.
    storage
        Payload storage intent.
    history
        History/lookback intent.
    backward
        Backward capture intent.
    execution_context
        Execution and random-state intent.
    stop_policy
        Compiled halt/non-finite/forward-error policy.
    backend_name
        Backend against which the plan was compiled.
    """

    projection_target: str
    default_enrichment: EnrichmentLevel = EnrichmentLevel.SHELL
    enrichment_by_operation: Mapping[str, EnrichmentLevel] = field(
        default_factory=lambda: MappingProxyType({})
    )
    selectors: Any = None
    deferred_candidates: tuple[Any, ...] = ()
    interventions: Any = None
    storage: Any = None
    history: Any = None
    backward: Any = None
    execution_context: Any = None
    stop_policy: Any = None
    backend_name: str = "torch"
    retention_profile: RetentionProfile = field(default_factory=RetentionProfile)

    def __post_init__(self) -> None:
        """Freeze collection fields so compiled intent cannot change mid-run."""

        object.__setattr__(self, "deferred_candidates", tuple(self.deferred_candidates))
        object.__setattr__(
            self,
            "enrichment_by_operation",
            MappingProxyType(dict(self.enrichment_by_operation)),
        )
        for field_name in (
            "selectors",
            "interventions",
            "storage",
            "history",
            "backward",
            "execution_context",
            "stop_policy",
        ):
            object.__setattr__(self, field_name, _freeze_intent(getattr(self, field_name)))

    @classmethod
    def compile(
        cls,
        *,
        projection_target: str,
        default_enrichment: EnrichmentLevel = EnrichmentLevel.SHELL,
        enrichment_by_operation: Mapping[str, EnrichmentLevel] | None = None,
        selectors: Any = None,
        deferred_candidates: Iterable[Any] = (),
        interventions: Any = None,
        storage: Any = None,
        history: Any = None,
        backward: Any = None,
        execution_context: Any = None,
        stop_policy: Any = None,
        backend_name: str = "torch",
        retention_profile: RetentionProfile | None = None,
    ) -> CapturePlan:
        """Compile immutable capture intent.

        Parameters
        ----------
        projection_target
            Requested internal projection.
        default_enrichment
            Default demanded enrichment level.
        enrichment_by_operation
            Per-operation enrichment overrides.
        selectors, deferred_candidates, interventions, storage, history, backward
            Normalized capture intent retained for later kernel stages.
        execution_context
            Execution-context intent.
        stop_policy
            Compiled stop/error policy.
        backend_name
            Name of the backend being compiled.

        Returns
        -------
        CapturePlan
            Frozen compiled request.

        """

        return cls(
            projection_target=projection_target,
            default_enrichment=default_enrichment,
            enrichment_by_operation=enrichment_by_operation or {},
            selectors=selectors,
            deferred_candidates=tuple(deferred_candidates),
            interventions=interventions,
            storage=storage,
            history=history,
            backward=backward,
            execution_context=execution_context,
            stop_policy=stop_policy,
            backend_name=backend_name,
            retention_profile=retention_profile or RetentionProfile(),
        )

    def enrichment_for(self, operation_key: str) -> EnrichmentLevel:
        """Return the precompiled enrichment demand for one operation key.

        Parameters
        ----------
        operation_key
            Backend-normalized operation identifier.

        Returns
        -------
        EnrichmentLevel
            Specific override when present, otherwise the default demand.
        """

        return self.enrichment_by_operation.get(operation_key, self.default_enrichment)
