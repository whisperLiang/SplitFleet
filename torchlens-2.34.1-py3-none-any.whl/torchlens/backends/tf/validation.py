"""Non-vacuous replay validation for the TensorFlow eager backend."""

from __future__ import annotations

from collections import Counter
from collections.abc import Callable, Mapping, Sequence
from dataclasses import dataclass
from typing import Any, Literal

import numpy as np

from ... import _state
from ...validation.status import ValidationReplaySource, ValidationReplayStatus
from .._validation_shared import float_replay_tolerances, ops_by_label as _ops_by_label
from .op_callback_capture import TFOpCapture

TFOpClass = Literal[
    "value",
    "source",
    "pure-resource-read",
    "structural-value",
    "annotation",
    "effect-denied",
    "control-region",
]

_INIT_OP_TYPES = frozenset(
    {
        "StatelessRandomUniformV2",
        "RandomUniform",
        "Fill",
        "VarHandleOp",
        "AssignVariableOp",
    }
)
_PURE_REPLAY_ALLOWLIST = frozenset(
    {
        "AddV2",
        "AvgPool",
        "BatchMatMulV2",
        "BiasAdd",
        "Cast",
        "ConcatV2",
        "Conv2D",
        "DepthwiseConv2dNative",
        "Einsum",
        "MatMul",
        "MaxPool",
        "Mean",
        "Mul",
        "Neg",
        "RealDiv",
        "Relu",
        "Relu6",
        "Reshape",
        "Rsqrt",
        "Split",
        "Softmax",
        "Sqrt",
        "SquaredDifference",
        "Sub",
        "Squeeze",
        "Tanh",
        "Transpose",
    }
)
_VALUE_OPS = _PURE_REPLAY_ALLOWLIST | frozenset(
    {
        "Elu",
        "Erf",
        "Exp",
        "ExpandDims",
        "GatherV2",
        "Gelu",
        "Greater",
        "Less",
        "Log",
        "Maximum",
        "Minimum",
        "Pack",
        "Pad",
        "Pow",
        "Prod",
        "Sigmoid",
        "Sin",
        "Slice",
        "Split",
        "Squeeze",
        "Sum",
        "Tile",
    }
)
_STRUCTURAL_VALUE_OPS = frozenset({"Shape", "Size", "Rank", "StridedSlice"})
_ANNOTATION_OPS = frozenset({"Identity", "StopGradient"})
_PURE_RESOURCE_READ_OPS = frozenset({"ReadVariableOp"})
_SOURCE_OPS = frozenset({"Const", "Placeholder"})
_EFFECT_DENIED_OPS = frozenset(
    {
        "Assert",
        "AssignAddVariableOp",
        "AssignSubVariableOp",
        "DestroyResourceOp",
        "NoOp",
        "PrintV2",
        "RandomStandardNormal",
        "StatefulPartitionedCall",
    }
)
_CONTROL_REGION_OPS = frozenset(
    {"If", "StatelessIf", "While", "StatelessWhile", "Case", "Switch", "Merge"}
    | {"StatefulPartitionedCall"}
)


@dataclass(frozen=True)
class TFValidationCounts:
    """TensorFlow validation outcome counts.

    Parameters
    ----------
    replayed_node_count
        Number of pure nodes replayed and perturbation-checked.
    pure_unverified_node_count
        Number of cleanly classified pure value nodes outside the replay
        allowlist or missing replayable payloads.
    effect_region_node_count
        Number of stateful, resource-read, control, structural, or annotation
        nodes excluded from pure per-op replay.
    failed_node_count
        Number of validation failures.
    """

    replayed_node_count: int = 0
    pure_unverified_node_count: int = 0
    effect_region_node_count: int = 0
    failed_node_count: int = 0


@dataclass(frozen=True)
class TFValidationResult:
    """Detailed TensorFlow validation result.

    Parameters
    ----------
    counts
        Replay and failure counts.
    failures
        Stable failure reason strings.
    classes
        Per-op class assignment keyed by raw label.
    replayed_histogram
        Replayed op-type histogram.
    pure_unverified_histogram
        Pure but non-replayed op-type histogram.
    effect_region_histogram
        Effect or non-value op-type histogram.
    """

    counts: TFValidationCounts
    failures: tuple[str, ...]
    classes: dict[str, TFOpClass]
    replayed_histogram: Counter[str]
    pure_unverified_histogram: Counter[str]
    effect_region_histogram: Counter[str]


def validate_tf_trace(trace: Any, *, validate_metadata: bool = True) -> ValidationReplayStatus:
    """Validate a TensorFlow trace with the P4 non-vacuous tripwire.

    Parameters
    ----------
    trace
        TensorFlow trace produced by the eager op-callback backend.
    validate_metadata
        Whether backend-neutral metadata invariants should also run.

    Returns
    -------
    ValidationReplayStatus
        Failed, passed, or honestly unverified replay-validation status.
    """

    del validate_metadata
    result = validate_tf_trace_detailed(trace)
    source: ValidationReplaySource = (
        "loaded" if getattr(trace, "_loaded_from_bundle", False) else "live"
    )
    if _annotation_only_validation_passes(result):
        annotation_count = sum(op_class == "annotation" for op_class in result.classes.values())
        status = ValidationReplayStatus.result(
            passed=True,
            backend="tf",
            source=source,
            replayed_node_count=0,
            payload_load_status=getattr(trace, "payload_load_status", None),
            exempted_reason_counts={"annotation_passthrough": annotation_count},
        )
    else:
        status = ValidationReplayStatus.from_replay_counts(
            backend="tf",
            source=source,
            replayed_node_count=result.counts.replayed_node_count,
            unverified_node_count=0,
            pure_unverified_node_count=result.counts.pure_unverified_node_count,
            effect_region_node_count=result.counts.effect_region_node_count,
            failed_node_count=result.counts.failed_node_count,
            payload_load_status=getattr(trace, "payload_load_status", None),
        )
    setattr(trace, "_tf_validation_result", result)
    setattr(trace, "_validation_replay_status", status)
    return status


def _annotation_only_validation_passes(result: TFValidationResult) -> bool:
    """Return whether validation covered only source and passthrough nodes.

    An identity or stop-gradient op is intentionally classified as an
    annotation rather than a value-producing op.  Its callback lineage and
    saved output are still checked by ``validate_tf_trace_detailed``; counting
    it as a raw-op replay would overstate replay coverage.  A trace containing
    only these annotations therefore passes with an explicit exemption rather
    than becoming the misleading ``no_nodes_replay_validated`` status.

    Parameters
    ----------
    result
        Detailed validation result.

    Returns
    -------
    bool
        True for a clean source/annotation-only validation result.
    """

    if result.counts.failed_node_count:
        return False
    if result.counts.replayed_node_count:
        return False
    if result.counts.pure_unverified_node_count or result.counts.effect_region_node_count:
        return False
    classes = tuple(result.classes.values())
    return (
        bool(classes)
        and "annotation" in classes
        and all(op_class in {"source", "annotation"} for op_class in classes)
    )


def validate_tf_trace_detailed(trace: Any) -> TFValidationResult:
    """Run TensorFlow validation and return detailed counts and diagnostics.

    Parameters
    ----------
    trace
        TensorFlow trace produced by the eager op-callback backend.

    Returns
    -------
    TFValidationResult
        Detailed validation outcome.
    """

    failures: list[str] = []
    classes: dict[str, TFOpClass] = {}
    replayed_histogram: Counter[str] = Counter()
    pure_unverified_histogram: Counter[str] = Counter()
    effect_region_histogram: Counter[str] = Counter()

    ops_by_label = _ops_by_label(trace)
    captures_by_label = _captures_by_label(trace)
    init_labels = set(getattr(trace, "_tf_init_op_labels", ()))
    _validate_classification(
        ops_by_label=ops_by_label,
        init_labels=init_labels,
        classes=classes,
        failures=failures,
    )
    _validate_self_consistency(
        trace=trace,
        ops_by_label=ops_by_label,
        captures_by_label=captures_by_label,
        failures=failures,
    )
    if failures:
        return TFValidationResult(
            counts=TFValidationCounts(failed_node_count=len(failures)),
            failures=tuple(failures),
            classes=classes,
            replayed_histogram=replayed_histogram,
            pure_unverified_histogram=pure_unverified_histogram,
            effect_region_histogram=effect_region_histogram,
        )

    replayed_count = 0
    pure_unverified_count = 0
    effect_region_count = 0
    for label, op in ops_by_label.items():
        if label != getattr(op, "_label_raw", None):
            continue
        op_class = classes[label]
        op_type = str(getattr(op, "func_name", ""))
        if op_class != "value":
            if op_class in {"pure-resource-read", "effect-denied", "control-region"}:
                effect_region_count += 1
                effect_region_histogram[op_type] += 1
            continue
        capture = captures_by_label.get(label)
        if op_type not in _PURE_REPLAY_ALLOWLIST or capture is None:
            pure_unverified_count += 1
            pure_unverified_histogram[op_type] += 1
            continue
        if _replay_and_perturb_op(op=op, capture=capture, ops_by_label=ops_by_label):
            replayed_count += 1
            replayed_histogram[op_type] += 1
        else:
            failures.append(f"replay_or_perturbation_failed:{label}:{op_type}")

    return TFValidationResult(
        counts=TFValidationCounts(
            replayed_node_count=replayed_count,
            pure_unverified_node_count=pure_unverified_count,
            effect_region_node_count=effect_region_count,
            failed_node_count=len(failures),
        ),
        failures=tuple(failures),
        classes=classes,
        replayed_histogram=replayed_histogram,
        pure_unverified_histogram=pure_unverified_histogram,
        effect_region_histogram=effect_region_histogram,
    )


def replay_allowlist() -> tuple[str, ...]:
    """Return the TensorFlow pure-op raw replay allowlist.

    Returns
    -------
    tuple[str, ...]
        Sorted replayable TensorFlow op types.
    """

    return tuple(sorted(_PURE_REPLAY_ALLOWLIST))


def _validate_classification(
    *,
    ops_by_label: Mapping[str, Any],
    init_labels: set[str],
    classes: dict[str, TFOpClass],
    failures: list[str],
) -> None:
    """Classify every materialized op exactly once and fail closed.

    Parameters
    ----------
    ops_by_label
        Materialized ops keyed by raw and public labels.
    init_labels
        Raw labels marked as initializer contamination during capture.
    classes
        Mutable class mapping to populate.
    failures
        Mutable failure list.

    Returns
    -------
    None
        Mutates ``classes`` and ``failures``.
    """

    for label, op in ops_by_label.items():
        if label != getattr(op, "_label_raw", None):
            continue
        op_type = str(getattr(op, "func_name", ""))
        if label in init_labels or op_type in _INIT_OP_TYPES and label in init_labels:
            failures.append(f"initializer_contamination:{label}:{op_type}")
            continue
        op_class = _classify_op(op)
        if op_class is None:
            failures.append(f"unclassified_op:{label}:{op_type}")
            continue
        classes[label] = op_class
    _propagate_control_region_classes(ops_by_label=ops_by_label, classes=classes)


def _propagate_control_region_classes(
    *,
    ops_by_label: Mapping[str, Any],
    classes: dict[str, TFOpClass],
) -> None:
    """Mark ops downstream of control regions as unverified regions.

    Parameters
    ----------
    ops_by_label
        Materialized ops keyed by raw and public labels.
    classes
        Mutable class mapping to update.

    Returns
    -------
    None
        Mutates ``classes`` in place.
    """

    def _raw_parent_labels(op: Any) -> tuple[str, ...]:
        """Return the op's parents resolved to raw label space.

        Classes are keyed by RAW labels while grouped edges hold final
        pass-qualified labels, so parents resolve through the op index back
        to their raw capture identity before region membership tests.
        """

        resolved: list[str] = []
        for parent in getattr(op, "parents", ()):
            parent_text = str(parent)
            parent_op = ops_by_label.get(parent_text)
            parent_raw = getattr(parent_op, "_label_raw", None) if parent_op is not None else None
            resolved.append(parent_raw if isinstance(parent_raw, str) else parent_text)
        return tuple(resolved)

    changed = True
    while changed:
        changed = False
        region_labels = {
            label for label, op_class in classes.items() if op_class == "control-region"
        }
        for label, op in ops_by_label.items():
            if label != getattr(op, "_label_raw", None):
                continue
            if classes.get(label) in {"source", "control-region"}:
                continue
            if any(parent in region_labels for parent in _raw_parent_labels(op)):
                classes[label] = "control-region"
                changed = True


def _classify_op(op: Any) -> TFOpClass | None:
    """Classify one TensorFlow op for validation accounting.

    Parameters
    ----------
    op
        Materialized TorchLens op.

    Returns
    -------
    TFOpClass | None
        Exactly one validation class, or ``None`` for fail-closed unknown ops.
    """

    op_type = str(getattr(op, "func_name", ""))
    if bool(getattr(op, "is_input", False)) or op_type == "input":
        return "source"
    if op_type in _SOURCE_OPS:
        return "source"
    if op_type in _PURE_RESOURCE_READ_OPS:
        return "pure-resource-read"
    if op_type in _STRUCTURAL_VALUE_OPS:
        return "structural-value"
    if op_type in _ANNOTATION_OPS:
        return "annotation"
    if op_type.startswith("__inference_") or op_type.startswith("region:"):
        return "control-region"
    if op_type in _CONTROL_REGION_OPS:
        return "control-region"
    if op_type in _EFFECT_DENIED_OPS:
        return "effect-denied"
    if op_type in _VALUE_OPS:
        return "value"
    return None


def _validate_self_consistency(
    *,
    trace: Any,
    ops_by_label: Mapping[str, Any],
    captures_by_label: Mapping[str, TFOpCapture],
    failures: list[str],
) -> None:
    """Validate callback output and consumed-input producer consistency.

    Parameters
    ----------
    trace
        TensorFlow trace with side-channel records.
    ops_by_label
        Materialized ops keyed by raw and public labels.
    captures_by_label
        Callback captures keyed by raw label.
    failures
        Mutable failure list.

    Returns
    -------
    None
        Mutates ``failures`` on coverage gaps.
    """

    unresolved = tuple(getattr(trace, "_tf_unresolved_producers", ()))
    if unresolved:
        failures.extend(
            f"unresolved_producer:{item.consumer_op_type}:{item.input_index}" for item in unresolved
        )
    produced_labels: set[str] = set()
    source_labels: set[str] = set()
    for label, op in ops_by_label.items():
        if label != getattr(op, "_label_raw", None):
            continue
        if bool(getattr(op, "is_input", False)) or getattr(op, "func_name", None) == "input":
            source_labels.add(label)
    for capture in captures_by_label.values():
        if capture.label_raw not in ops_by_label:
            failures.append(f"captured_output_missing_materialized_op:{capture.label_raw}")
        produced_labels.add(capture.label_raw)
    for label, op in ops_by_label.items():
        if label != getattr(op, "_label_raw", None):
            continue
        if bool(getattr(op, "is_input", False)):
            continue
        if label not in captures_by_label:
            failures.append(f"materialized_op_missing_capture:{label}")
    for capture in captures_by_label.values():
        expected_graph_parents: set[str] = set()
        for input_record in capture.inputs:
            graph_parent = input_record.producer_label_raw or input_record.source_label_raw
            if graph_parent is not None:
                expected_graph_parents.add(graph_parent)
        for input_record in capture.inputs:
            producer_label = input_record.producer_label_raw
            source_label = input_record.source_label_raw
            if producer_label is not None and producer_label not in produced_labels:
                failures.append(
                    "input_producer_missing_prior_callback_output:"
                    f"{capture.label_raw}:{producer_label}:{input_record.input_index}"
                )
            if producer_label is None and source_label is None and input_record.source_kind is None:
                failures.append(
                    f"input_missing_producer_or_source:{capture.label_raw}:"
                    f"{input_record.input_index}"
                )
            if source_label is not None and source_label not in source_labels:
                failures.append(
                    f"input_source_label_missing:{capture.label_raw}:{source_label}:"
                    f"{input_record.input_index}"
                )
        op = ops_by_label.get(capture.label_raw)
        if op is None:
            continue
        # Capture records speak RAW label space. Recurrence grouping rewrites
        # graph edges to final pass-qualified labels, so parents are resolved
        # back to raw space before the conservation comparison; an
        # unresolvable parent keeps its literal label and fails closed.
        graph_parents: set[str] = set()
        for parent in getattr(op, "parents", ()):
            parent_text = str(parent)
            parent_op = ops_by_label.get(parent_text)
            parent_raw = getattr(parent_op, "_label_raw", None) if parent_op is not None else None
            graph_parents.add(parent_raw if isinstance(parent_raw, str) else parent_text)
        if expected_graph_parents != graph_parents:
            failures.append(
                f"graph_parent_edges_not_conserved:{capture.label_raw}:"
                f"{sorted(expected_graph_parents)!r}:{sorted(graph_parents)!r}"
            )


def _replay_and_perturb_op(
    *,
    op: Any,
    capture: TFOpCapture,
    ops_by_label: Mapping[str, Any],
) -> bool:
    """Replay one pure TensorFlow op and run the parent perturbation tripwire.

    Parameters
    ----------
    op
        Materialized TorchLens op.
    capture
        Callback capture for ``op``.
    ops_by_label
        Materialized ops keyed by raw and public labels.

    Returns
    -------
    bool
        True when replay matches and at least one parent perturbation changes
        the output when value parents exist.
    """

    try:
        inputs = _rebuild_inputs(capture, ops_by_label, replacements={})
        replayed = _replay_raw_op(capture, inputs)
        saved = _saved_payload(op)
        if not _payloads_close(replayed, saved):
            return False
        return _parent_perturbations_change_output(
            capture=capture,
            ops_by_label=ops_by_label,
            saved_output=saved,
        )
    except Exception:
        return False


def _rebuild_inputs(
    capture: TFOpCapture,
    ops_by_label: Mapping[str, Any],
    replacements: Mapping[str, Any],
) -> list[Any]:
    """Rebuild callback inputs from recorded parents and typed sources.

    Parameters
    ----------
    capture
        Callback capture to rebuild.
    ops_by_label
        Materialized ops keyed by raw and public labels.
    replacements
        Optional replacement tensors keyed by raw producer/source label.

    Returns
    -------
    list[Any]
        TensorFlow tensors in callback input order.
    """

    tf = _import_tensorflow()
    inputs: list[Any] = []
    for input_record in sorted(capture.inputs, key=lambda item: item.input_index):
        label = input_record.producer_label_raw or input_record.source_label_raw
        if label is not None and label in replacements:
            inputs.append(replacements[label])
            continue
        if input_record.producer_label_raw is not None:
            parent = ops_by_label.get(input_record.producer_label_raw)
            if parent is None:
                raise LookupError(input_record.producer_label_raw)
            inputs.append(_to_tf_tensor(tf, _saved_payload(parent)))
            continue
        if input_record.source_label_raw is not None:
            source = ops_by_label.get(input_record.source_label_raw)
            if source is None:
                raise LookupError(input_record.source_label_raw)
            inputs.append(_to_tf_tensor(tf, _saved_payload(source)))
            continue
        if input_record.source_kind is not None:
            inputs.append(_to_tf_tensor(tf, _tensor_to_numpy(input_record.tensor)))
            continue
        raise LookupError(f"unresolved input {capture.label_raw}:{input_record.input_index}")
    return inputs


def _replay_raw_op(capture: TFOpCapture, inputs: Sequence[Any]) -> Any:
    """Replay one TensorFlow raw op from rebuilt callback inputs.

    Parameters
    ----------
    capture
        Callback capture containing op type and attrs.
    inputs
        Rebuilt TensorFlow inputs.

    Returns
    -------
    Any
        Replayed TensorFlow output tensor.
    """

    dispatch: dict[str, Callable[[TFOpCapture, Sequence[Any]], Any]] = {
        "AddV2": lambda item, args: _raw(item).AddV2(x=args[0], y=args[1]),
        "AvgPool": _replay_pool,
        "BatchMatMulV2": _replay_batch_matmul_v2,
        "BiasAdd": _replay_bias_add,
        "Cast": _replay_cast,
        "ConcatV2": _replay_concat_v2,
        "Conv2D": _replay_conv2d,
        "DepthwiseConv2dNative": _replay_depthwise_conv2d_native,
        "Einsum": _replay_einsum,
        "Identity": lambda item, args: _raw(item).Identity(input=args[0]),
        "MatMul": _replay_matmul,
        "MaxPool": _replay_pool,
        "Mean": _replay_mean,
        "Maximum": lambda item, args: _raw(item).Maximum(x=args[0], y=args[1]),
        "Minimum": lambda item, args: _raw(item).Minimum(x=args[0], y=args[1]),
        "Mul": lambda item, args: _raw(item).Mul(x=args[0], y=args[1]),
        "Neg": lambda item, args: _raw(item).Neg(x=args[0]),
        "Pack": _replay_pack,
        "Pad": lambda item, args: _raw(item).Pad(input=args[0], paddings=args[1]),
        "RealDiv": lambda item, args: _raw(item).RealDiv(x=args[0], y=args[1]),
        "ReadVariableOp": lambda item, args: _raw(item).ReadVariableOp(
            resource=args[0],
            dtype=item.attrs["dtype"],
        ),
        "Relu": lambda item, args: _raw(item).Relu(features=args[0]),
        "Relu6": lambda item, args: _raw(item).Relu6(features=args[0]),
        "Reshape": lambda item, args: _raw(item).Reshape(tensor=args[0], shape=args[1]),
        "Rsqrt": lambda item, args: _raw(item).Rsqrt(x=args[0]),
        "Shape": _replay_shape,
        "Sigmoid": lambda item, args: _raw(item).Sigmoid(x=args[0]),
        "Softmax": lambda item, args: _raw(item).Softmax(logits=args[0]),
        "Sqrt": lambda item, args: _raw(item).Sqrt(x=args[0]),
        "SquaredDifference": lambda item, args: _raw(item).SquaredDifference(
            x=args[0],
            y=args[1],
        ),
        "Fill": lambda item, args: _raw(item).Fill(dims=args[0], value=args[1]),
        "StopGradient": lambda item, args: _raw(item).StopGradient(input=args[0]),
        "StridedSlice": _replay_strided_slice,
        "Sub": lambda item, args: _raw(item).Sub(x=args[0], y=args[1]),
        "Squeeze": lambda item, args: _raw(item).Squeeze(
            input=args[0],
            axis=_optional_int_list(item.attrs.get("squeeze_dims")),
        ),
        "Tanh": lambda item, args: _raw(item).Tanh(x=args[0]),
        "Transpose": lambda item, args: _raw(item).Transpose(x=args[0], perm=args[1]),
        "ExpandDims": lambda item, args: _raw(item).ExpandDims(input=args[0], axis=args[1]),
        "Split": lambda item, args: _raw(item).Split(
            axis=args[0], value=args[1], num_split=int(item.attrs["num_split"])
        ),
        "Tile": lambda item, args: _raw(item).Tile(input=args[0], multiples=args[1]),
    }
    replay = dispatch.get(capture.op_type)
    if replay is None:
        raise ValueError(f"op is not raw-op replayable: {capture.op_type}")
    with _state.pause_logging():
        return replay(capture, inputs)


def _raw(_capture: TFOpCapture) -> Any:
    """Return TensorFlow raw ops module.

    Parameters
    ----------
    _capture
        Unused capture, accepted for dispatch lambdas.

    Returns
    -------
    Any
        ``tf.raw_ops``.
    """

    return _import_tensorflow().raw_ops


def _replay_batch_matmul_v2(capture: TFOpCapture, inputs: Sequence[Any]) -> Any:
    """Replay ``BatchMatMulV2``.

    Parameters
    ----------
    capture
        Callback capture.
    inputs
        Rebuilt inputs.

    Returns
    -------
    Any
        Replayed output.
    """

    return _raw(capture).BatchMatMulV2(
        x=inputs[0],
        y=inputs[1],
        adj_x=bool(capture.attrs.get("adj_x", False)),
        adj_y=bool(capture.attrs.get("adj_y", False)),
    )


def _replay_bias_add(capture: TFOpCapture, inputs: Sequence[Any]) -> Any:
    """Replay ``BiasAdd``.

    Parameters
    ----------
    capture
        Callback capture.
    inputs
        Rebuilt inputs.

    Returns
    -------
    Any
        Replayed output.
    """

    data_format = capture.attrs.get("data_format")
    kwargs = {} if data_format is None else {"data_format": _attr_str(data_format)}
    return _raw(capture).BiasAdd(value=inputs[0], bias=inputs[1], **kwargs)


def _replay_cast(capture: TFOpCapture, inputs: Sequence[Any]) -> Any:
    """Replay ``Cast``.

    Parameters
    ----------
    capture
        Callback capture.
    inputs
        Rebuilt inputs.

    Returns
    -------
    Any
        Replayed output.
    """

    return _raw(capture).Cast(
        x=inputs[0],
        DstT=capture.attrs["DstT"],
        Truncate=bool(capture.attrs.get("Truncate", False)),
    )


def _replay_concat_v2(capture: TFOpCapture, inputs: Sequence[Any]) -> Any:
    """Replay ``ConcatV2``.

    Parameters
    ----------
    capture
        Callback capture.
    inputs
        Rebuilt inputs.

    Returns
    -------
    Any
        Replayed output.
    """

    del capture
    return _import_tensorflow().raw_ops.ConcatV2(values=list(inputs[:-1]), axis=inputs[-1])


def _replay_conv2d(capture: TFOpCapture, inputs: Sequence[Any]) -> Any:
    """Replay ``Conv2D``.

    Parameters
    ----------
    capture
        Callback capture.
    inputs
        Rebuilt inputs.

    Returns
    -------
    Any
        Replayed output.
    """

    return _raw(capture).Conv2D(
        input=inputs[0],
        filter=inputs[1],
        strides=list(capture.attrs["strides"]),
        padding=_attr_str(capture.attrs["padding"]),
        explicit_paddings=list(capture.attrs.get("explicit_paddings", [])),
        data_format=_attr_str(capture.attrs.get("data_format", "NHWC")),
        dilations=list(capture.attrs.get("dilations", [1, 1, 1, 1])),
        use_cudnn_on_gpu=bool(capture.attrs.get("use_cudnn_on_gpu", True)),
    )


def _replay_depthwise_conv2d_native(capture: TFOpCapture, inputs: Sequence[Any]) -> Any:
    """Replay ``DepthwiseConv2dNative``."""

    return _raw(capture).DepthwiseConv2dNative(
        input=inputs[0],
        filter=inputs[1],
        strides=list(capture.attrs["strides"]),
        padding=_attr_str(capture.attrs["padding"]),
        explicit_paddings=list(capture.attrs.get("explicit_paddings", [])),
        data_format=_attr_str(capture.attrs.get("data_format", "NHWC")),
        dilations=list(capture.attrs.get("dilations", [1, 1, 1, 1])),
    )


def _replay_einsum(capture: TFOpCapture, inputs: Sequence[Any]) -> Any:
    """Replay ``Einsum``.

    Parameters
    ----------
    capture
        Callback capture.
    inputs
        Rebuilt inputs.

    Returns
    -------
    Any
        Replayed output.
    """

    return _raw(capture).Einsum(
        inputs=list(inputs),
        equation=_attr_str(capture.attrs["equation"]),
    )


def _replay_matmul(capture: TFOpCapture, inputs: Sequence[Any]) -> Any:
    """Replay ``MatMul``.

    Parameters
    ----------
    capture
        Callback capture.
    inputs
        Rebuilt inputs.

    Returns
    -------
    Any
        Replayed output.
    """

    return _raw(capture).MatMul(
        a=inputs[0],
        b=inputs[1],
        transpose_a=bool(capture.attrs.get("transpose_a", False)),
        transpose_b=bool(capture.attrs.get("transpose_b", False)),
    )


def _replay_mean(capture: TFOpCapture, inputs: Sequence[Any]) -> Any:
    """Replay ``Mean``.

    Parameters
    ----------
    capture
        Callback capture.
    inputs
        Rebuilt inputs.

    Returns
    -------
    Any
        Replayed output.
    """

    return _raw(capture).Mean(
        input=inputs[0],
        axis=inputs[1],
        keep_dims=bool(capture.attrs.get("keep_dims", False)),
    )


def _replay_pool(capture: TFOpCapture, inputs: Sequence[Any]) -> Any:
    """Replay ``MaxPool`` or ``AvgPool``.

    Parameters
    ----------
    capture
        Callback capture.
    inputs
        Rebuilt inputs.

    Returns
    -------
    Any
        Replayed output.
    """

    raw_op = getattr(_raw(capture), capture.op_type)
    kwargs = {
        "ksize": list(capture.attrs["ksize"]),
        "strides": list(capture.attrs["strides"]),
        "padding": _attr_str(capture.attrs["padding"]),
        "data_format": _attr_str(capture.attrs.get("data_format", "NHWC")),
    }
    if capture.op_type == "AvgPool":
        kwargs["value"] = inputs[0]
    else:
        kwargs["input"] = inputs[0]
        kwargs["explicit_paddings"] = list(capture.attrs.get("explicit_paddings", []))
    return raw_op(**kwargs)


def _replay_pack(capture: TFOpCapture, inputs: Sequence[Any]) -> Any:
    """Replay ``Pack``."""

    return _raw(capture).Pack(
        values=list(inputs),
        axis=int(capture.attrs.get("axis", 0)),
    )


def _replay_shape(capture: TFOpCapture, inputs: Sequence[Any]) -> Any:
    """Replay ``Shape``."""

    attrs = capture.attrs
    kwargs = {}
    if "out_type" in attrs:
        kwargs["out_type"] = attrs["out_type"]
    if "out_type_enum" in attrs:
        kwargs["out_type"] = attrs["out_type_enum"]
    return _raw(capture).Shape(input=inputs[0], **kwargs)


def _replay_strided_slice(capture: TFOpCapture, inputs: Sequence[Any]) -> Any:
    """Replay ``StridedSlice``."""

    return _raw(capture).StridedSlice(
        input=inputs[0],
        begin=inputs[1],
        end=inputs[2],
        strides=inputs[3],
        begin_mask=int(capture.attrs.get("begin_mask", 0)),
        end_mask=int(capture.attrs.get("end_mask", 0)),
        ellipsis_mask=int(capture.attrs.get("ellipsis_mask", 0)),
        new_axis_mask=int(capture.attrs.get("new_axis_mask", 0)),
        shrink_axis_mask=int(capture.attrs.get("shrink_axis_mask", 0)),
    )


def _attr_str(value: Any) -> str:
    """Return a TensorFlow string attr as text.

    Parameters
    ----------
    value
        TensorFlow callback attr value.

    Returns
    -------
    str
        Decoded text attr.
    """

    if isinstance(value, bytes):
        return value.decode("utf-8", errors="replace")
    return str(value)


def _optional_int_list(value: Any) -> list[int]:
    """Return a TensorFlow optional int-list attr.

    Parameters
    ----------
    value
        Callback attr value.

    Returns
    -------
    list[int]
        Empty list for omitted attrs, otherwise the integer list.
    """

    if value is None:
        return []
    return [int(item) for item in value]


def _parent_perturbations_change_output(
    *,
    capture: TFOpCapture,
    ops_by_label: Mapping[str, Any],
    saved_output: Any,
) -> bool:
    """Return whether parent perturbation changes a replayed output.

    Parameters
    ----------
    capture
        Callback capture to perturb.
    ops_by_label
        Materialized ops keyed by raw and public labels.
    saved_output
        Recorded output payload.

    Returns
    -------
    bool
        True when at least one value parent perturbation changes output. Ops
        with no recorded value parents are accepted only when no perturbation is
        possible by construction.
    """

    parent_labels = tuple(
        dict.fromkeys(
            label
            for item in capture.inputs
            if (label := (item.producer_label_raw or item.source_label_raw)) is not None
        )
    )
    if not parent_labels:
        return True
    attempted = False
    tf = _import_tensorflow()
    for label in parent_labels:
        parent = ops_by_label.get(label)
        if parent is None:
            return False
        original = _to_tf_tensor(tf, _saved_payload(parent))
        for candidate in _perturb_candidates(tf, original):
            attempted = True
            try:
                replayed = _replay_raw_op(
                    capture,
                    _rebuild_inputs(capture, ops_by_label, replacements={label: candidate}),
                )
            except Exception:
                continue
            if not _payloads_close(replayed, saved_output):
                return True
    return not attempted


def _perturb_candidates(tf: Any, tensor: Any) -> tuple[Any, ...]:
    """Return deterministic TensorFlow perturbation candidates.

    Parameters
    ----------
    tf
        Imported TensorFlow module.
    tensor
        TensorFlow tensor to perturb.

    Returns
    -------
    tuple[Any, ...]
        Candidate tensors with matching dtype.
    """

    array = _tensor_to_numpy(tensor)
    dtype = getattr(tensor, "dtype", None)
    candidates: tuple[Any, ...]
    if np.issubdtype(array.dtype, np.bool_):
        candidates = (np.logical_not(array),)
    elif np.issubdtype(array.dtype, np.integer):
        candidates = (array + 1, np.zeros_like(array))
    elif np.issubdtype(array.dtype, np.floating):
        magnitude = np.max(np.abs(array)).item() + 1.0 if array.size else 1.0
        ramp = np.arange(array.size, dtype=np.float64).reshape(array.shape)
        ramp = (ramp + 1.0) * (magnitude / max(array.size, 1))
        candidates = (array + magnitude, array - magnitude, np.zeros_like(array))
        candidates = (*candidates, array + ramp.astype(array.dtype, copy=False))
    else:
        return ()
    return tuple(tf.convert_to_tensor(candidate, dtype=dtype) for candidate in candidates)


def _payloads_close(left: Any, right: Any) -> bool:
    """Return whether two TensorFlow payloads match within backend tolerance.

    Parameters
    ----------
    left
        Left payload or TensorFlow tensor.
    right
        Right payload or TensorFlow tensor.

    Returns
    -------
    bool
        True when shape, dtype, and values match.
    """

    left_array = _tensor_to_numpy(left)
    right_array = _tensor_to_numpy(right)
    if left_array.shape != right_array.shape or left_array.dtype != right_array.dtype:
        return False
    if np.issubdtype(left_array.dtype, np.bool_) or np.issubdtype(left_array.dtype, np.integer):
        return bool(np.array_equal(left_array, right_array))
    if np.issubdtype(left_array.dtype, np.floating) or np.issubdtype(
        left_array.dtype,
        np.complexfloating,
    ):
        # equal_nan matches the jax/mlx/paddle sibling oracles and torch's
        # tensor_nanequal doctrine: an identical NaN pattern is agreement,
        # NaN-vs-number still fails elementwise. Omitting it false-FAILED
        # every legitimately NaN-bearing TF payload. Complex payloads take
        # the same component-eps band as mlx/jax (R17 consistency sweep:
        # bit-exact complex here false-failed legitimate replay jitter);
        # ``np.finfo`` reports component precision for complex dtypes.
        rtol, atol = float_replay_tolerances(np.finfo(left_array.dtype))
        return bool(np.allclose(left_array, right_array, rtol=rtol, atol=atol, equal_nan=True))
    return bool(np.array_equal(left_array, right_array))


def _tensor_to_numpy(value: Any) -> np.ndarray:
    """Convert a TensorFlow tensor or payload to a NumPy array.

    Parameters
    ----------
    value
        TensorFlow tensor, NumPy array, or scalar payload.

    Returns
    -------
    np.ndarray
        NumPy representation.
    """

    numpy_method = getattr(value, "numpy", None)
    if callable(numpy_method):
        value = numpy_method()
    return np.asarray(value)


def _to_tf_tensor(tf: Any, value: Any) -> Any:
    """Convert a payload to a TensorFlow tensor.

    Parameters
    ----------
    tf
        Imported TensorFlow module.
    value
        Payload value.

    Returns
    -------
    Any
        TensorFlow tensor.
    """

    return tf.convert_to_tensor(value)


def _saved_payload(op: Any) -> Any:
    """Return an op's saved output payload or raise on missing data.

    Parameters
    ----------
    op
        Materialized TorchLens op.

    Returns
    -------
    Any
        Saved output payload.
    """

    if not bool(getattr(op, "has_saved_activation", False)):
        raise ValueError(f"op has no saved activation: {getattr(op, 'label', op)!r}")
    return getattr(op, "out")


def _captures_by_label(trace: Any) -> dict[str, TFOpCapture]:
    """Return TensorFlow callback captures keyed by raw labels.

    Parameters
    ----------
    trace
        Materialized TensorFlow trace.

    Returns
    -------
    dict[str, TFOpCapture]
        Captures keyed by raw output label.
    """

    return {
        capture.label_raw: capture
        for capture in getattr(trace, "_tf_op_captures", ())
        if isinstance(capture, TFOpCapture)
    }


def _import_tensorflow() -> Any:
    """Import TensorFlow lazily.

    Returns
    -------
    Any
        Imported TensorFlow module.
    """

    import tensorflow as tf

    return tf


__all__ = [
    "TFValidationCounts",
    "TFValidationResult",
    "replay_allowlist",
    "validate_tf_trace",
    "validate_tf_trace_detailed",
]
