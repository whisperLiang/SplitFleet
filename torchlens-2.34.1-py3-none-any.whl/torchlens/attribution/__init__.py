"""Input-attribution methods for TorchLens."""

from torchlens.attribution._core import (
    AttributionError,
    AttributionResult,
    input_x_grad,
    integrated_gradients,
    saliency,
    smoothgrad,
)
from torchlens.attribution._layer import (
    grad_cam,
    layer_attribution,
    layer_conductance,
    layer_integrated_gradients,
)
from torchlens.attribution._occlusion import occlusion
from torchlens.attribution._viz import overlay

__all__ = [
    "AttributionError",
    "AttributionResult",
    "grad_cam",
    "input_x_grad",
    "integrated_gradients",
    "layer_attribution",
    "layer_conductance",
    "layer_integrated_gradients",
    "occlusion",
    "overlay",
    "saliency",
    "smoothgrad",
]
